import fs from 'fs';
import path from 'path';
import {
  Institute,
  Branch,
  AcademicSession,
  ClassItem,
  Batch,
  Teacher,
  AdmissionForm,
  Student,
  AttendanceRecord,
  FeeRecord,
  FeePayment,
  NoticeNotification,
  SystemAuditLog,
  User,
} from '../src/types.js';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'edurecord_db.json');

export interface DatabaseSchema {
  users: User[];
  institutes: Institute[];
  branches: Branch[];
  academicSessions: AcademicSession[];
  classes: ClassItem[];
  batches: Batch[];
  teachers: Teacher[];
  forms: AdmissionForm[];
  students: Student[];
  attendance: AttendanceRecord[];
  feeRecords: FeeRecord[];
  feePayments: FeePayment[];
  notices: NoticeNotification[];
  auditLogs: SystemAuditLog[];
  rollSequences: Record<string, number>;
  studentIdSequence: number;
}

// Initial seed data with "Akashdeep Math Class"
const getInitialData = (): DatabaseSchema => {
  const instituteId = 'inst-akashdeep-01';
  const branchBurdwanId = 'br-burdwan-01';
  const branchDurgapurId = 'br-durgapur-02';
  const branchKolkataId = 'br-kolkata-03';
  const sessionId = 'session-2026-27';

  const institutes: Institute[] = [
    {
      id: instituteId,
      name: 'Akashdeep Math Class',
      code: 'AKM',
      logo: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=160&auto=format&fit=crop&q=80',
      teacherName: 'Prof. Akashdeep Banerjee, M.Sc.',
      directorName: 'Akashdeep Banerjee',
      address: '24/B College Road, Near Court Compound, Burdwan - 713101',
      phone: '+91 98321 45678',
      whatsapp: '+91 98321 45678',
      email: 'admissions@akashdeepmaths.edu',
      website: 'https://akashdeepmaths.edu',
      socialLinks: {
        facebook: 'https://facebook.com/akashdeepmaths',
        youtube: 'https://youtube.com/@akashdeepmaths',
      },
      brandingColor: '#2563EB',
      currency: '₹',
      timezone: 'Asia/Kolkata',
      createdAt: '2026-01-10T09:00:00Z',
    },
    {
      id: 'inst-apex-science-02',
      name: 'Apex Science Academy',
      code: 'ASA',
      logo: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=160&auto=format&fit=crop&q=80',
      teacherName: 'Dr. Debabrata Roy, Ph.D.',
      directorName: 'Dr. Debabrata Roy',
      address: '14 Station Road, Durgapur - 713216',
      phone: '+91 94341 87654',
      whatsapp: '+91 94341 87654',
      email: 'info@apexscience.edu',
      website: 'https://apexscience.edu',
      brandingColor: '#059669',
      currency: '₹',
      timezone: 'Asia/Kolkata',
      createdAt: '2026-02-01T10:00:00Z',
    },
  ];

  const branches: Branch[] = [
    {
      id: branchBurdwanId,
      instituteId,
      name: 'Burdwan Main Campus',
      code: 'BWN',
      city: 'Burdwan',
      address: '24/B College Road, Near Court Compound, Burdwan - 713101',
      phone: '+91 98321 45678',
      inchargeName: 'Suman Mukherjee',
      isMain: true,
    },
    {
      id: branchDurgapurId,
      instituteId,
      name: 'Durgapur City Centre Branch',
      code: 'DGP',
      city: 'Durgapur',
      address: 'Plot 5A, Commercial Hub, City Centre, Durgapur - 713216',
      phone: '+91 98321 45679',
      inchargeName: 'Tanmoy Sen',
      isMain: false,
    },
    {
      id: branchKolkataId,
      instituteId,
      name: 'Kolkata Salt Lake Extension',
      code: 'KOL',
      city: 'Kolkata',
      address: 'Sector 1, Salt Lake City, Kolkata - 700064',
      phone: '+91 98321 45680',
      inchargeName: 'Priyanka Das',
      isMain: false,
    },
  ];

  const academicSessions: AcademicSession[] = [
    {
      id: sessionId,
      instituteId,
      name: '2026–27',
      isCurrent: true,
      startDate: '2026-04-01',
      endDate: '2027-03-31',
    },
    {
      id: 'session-2025-26',
      instituteId,
      name: '2025–26',
      isCurrent: false,
      startDate: '2025-04-01',
      endDate: '2026-03-31',
    },
  ];

  const classes: ClassItem[] = [
    { id: 'cls-ix', instituteId, branchId: branchBurdwanId, name: 'Class IX (Foundation Math)', code: 'IX' },
    { id: 'cls-x', instituteId, branchId: branchBurdwanId, name: 'Class X (Board Special)', code: 'X' },
    { id: 'cls-xi', instituteId, branchId: branchBurdwanId, name: 'Class XI (Higher Secondary & JEE)', code: 'XI' },
    { id: 'cls-xii', instituteId, branchId: branchBurdwanId, name: 'Class XII (WBCHSE / CBSE & JEE Main/Adv)', code: 'XII' },
  ];

  const batches: Batch[] = [
    {
      id: 'batch-xii-morning',
      instituteId,
      branchId: branchBurdwanId,
      classId: 'cls-xii',
      name: 'Class XII Morning Batch (Tues/Thu/Sat)',
      timeSlot: '06:30 AM - 08:30 AM',
      days: ['Tue', 'Thu', 'Sat'],
      maxSeats: 45,
      enrolledSeats: 32,
      teacherId: 'teacher-akashdeep-01',
      monthlyFee: 1800,
    },
    {
      id: 'batch-xii-evening',
      instituteId,
      branchId: branchBurdwanId,
      classId: 'cls-xii',
      name: 'Class XII Evening Batch (Mon/Wed/Fri)',
      timeSlot: '05:00 PM - 07:00 PM',
      days: ['Mon', 'Wed', 'Fri'],
      maxSeats: 50,
      enrolledSeats: 38,
      teacherId: 'teacher-akashdeep-01',
      monthlyFee: 1800,
    },
    {
      id: 'batch-xi-morning',
      instituteId,
      branchId: branchBurdwanId,
      classId: 'cls-xi',
      name: 'Class XI Weekend Special',
      timeSlot: '08:30 AM - 11:30 AM',
      days: ['Sat', 'Sun'],
      maxSeats: 40,
      enrolledSeats: 26,
      teacherId: 'teacher-akashdeep-01',
      monthlyFee: 1600,
    },
    {
      id: 'batch-x-foundation',
      instituteId,
      branchId: branchDurgapurId,
      classId: 'cls-x',
      name: 'Class X Durgapur Batch (Mon/Wed)',
      timeSlot: '04:30 PM - 06:30 PM',
      days: ['Mon', 'Wed'],
      maxSeats: 35,
      enrolledSeats: 19,
      teacherId: 'teacher-subhash-02',
      monthlyFee: 1400,
    },
  ];

  const teachers: Teacher[] = [
    {
      id: 'teacher-akashdeep-01',
      instituteId,
      name: 'Akashdeep Banerjee',
      phone: '+91 98321 45678',
      email: 'akashdeep@maths.edu',
      subject: 'Higher Mathematics & JEE Calculus',
      photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80',
      branchIds: [branchBurdwanId, branchDurgapurId],
      assignedClassIds: ['cls-xi', 'cls-xii'],
      assignedBatchIds: ['batch-xii-morning', 'batch-xii-evening', 'batch-xi-morning'],
      permissions: {
        canViewStudents: true,
        canEditStudents: true,
        canDeleteStudents: false,
        canMarkAttendance: true,
        canManageFees: true,
        canViewReports: true,
        canGeneratePdf: true,
      },
    },
    {
      id: 'teacher-subhash-02',
      instituteId,
      name: 'Subhash Roy',
      phone: '+91 98321 99887',
      email: 'subhash@maths.edu',
      subject: 'Algebra, Trigonometry & Geometry',
      photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80',
      branchIds: [branchBurdwanId, branchDurgapurId],
      assignedClassIds: ['cls-ix', 'cls-x'],
      assignedBatchIds: ['batch-x-foundation'],
      permissions: {
        canViewStudents: true,
        canEditStudents: false,
        canDeleteStudents: false,
        canMarkAttendance: true,
        canManageFees: false,
        canViewReports: true,
        canGeneratePdf: true,
      },
    },
  ];

  const forms: AdmissionForm[] = [
    {
      id: 'form-xii-2026',
      instituteId,
      branchId: branchBurdwanId,
      classId: 'cls-xii',
      batchId: 'batch-xii-morning',
      title: 'Class XII Mathematics & JEE Admission Form 2026-27',
      slug: 'AKM-XII-MORNING-2026',
      description: 'Official registration form for Akashdeep Sir’s Mathematics Guidance Program (Board + WBJEE / JEE Main 2027).',
      status: 'published',
      viewsCount: 142,
      submissionsCount: 28,
      rollNumberConfig: {
        prefix: 'AKM-2026-',
        startingNumber: 1,
        length: 3,
        resetScope: 'class',
      },
      sections: [
        { id: 'sec-personal', title: 'Personal Information', description: 'Student basic identity details', order: 1 },
        { id: 'sec-parent', title: 'Parent / Guardian Details', description: 'Contact details for communication and fee notifications', order: 2 },
        { id: 'sec-academic', title: 'Academic Background', description: 'School, previous score & stream', order: 3 },
        { id: 'sec-transport', title: 'Transportation & Logistics', description: 'Batch timing and optional transportation', order: 4 },
      ],
      fields: [
        { id: 'fld-name', type: 'text', label: 'Student Full Name', placeholder: 'e.g. Sourav Ghosh', required: true, order: 1, sectionId: 'sec-personal' },
        { id: 'fld-gender', type: 'radio', label: 'Gender', options: ['Male', 'Female', 'Other'], required: true, order: 2, sectionId: 'sec-personal' },
        { id: 'fld-dob', type: 'date', label: 'Date of Birth', required: true, order: 3, sectionId: 'sec-personal' },
        { id: 'fld-blood', type: 'dropdown', label: 'Blood Group', options: ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'], required: false, order: 4, sectionId: 'sec-personal' },
        { id: 'fld-phone', type: 'phone', label: 'Student WhatsApp / Mobile', placeholder: '10-digit mobile number', required: true, order: 5, sectionId: 'sec-personal' },
        { id: 'fld-email', type: 'email', label: 'Student Email Address', placeholder: 'student@gmail.com', required: false, order: 6, sectionId: 'sec-personal' },
        { id: 'fld-address', type: 'textarea', label: 'Residential Address', placeholder: 'Full address with landmark & PIN code', required: true, order: 7, sectionId: 'sec-personal' },

        { id: 'fld-father-name', type: 'text', label: 'Father / Guardian Name', placeholder: 'e.g. Bikas Ghosh', required: true, order: 8, sectionId: 'sec-parent' },
        { id: 'fld-parent-phone', type: 'phone', label: 'Parent Calling Mobile', placeholder: 'Primary parent mobile number', required: true, order: 9, sectionId: 'sec-parent' },
        { id: 'fld-parent-occ', type: 'text', label: 'Parent Occupation', placeholder: 'e.g. Government Service / Business', required: false, order: 10, sectionId: 'sec-parent' },

        { id: 'fld-is-school', type: 'yes_no', label: 'Are you currently enrolled in a school?', defaultValue: 'Yes', required: true, order: 11, sectionId: 'sec-academic' },
        {
          id: 'fld-school-name',
          type: 'text',
          label: 'Current School Name',
          placeholder: 'e.g. Burdwan Municipal High School',
          required: true,
          order: 12,
          sectionId: 'sec-academic',
          condition: { dependsOnFieldId: 'fld-is-school', operator: 'equals', value: 'Yes' },
        },
        {
          id: 'fld-class-xi-marks',
          type: 'number',
          label: 'Class XI Math Marks (out of 100 or %)',
          placeholder: 'e.g. 88',
          required: false,
          order: 13,
          sectionId: 'sec-academic',
          condition: { dependsOnFieldId: 'fld-is-school', operator: 'equals', value: 'Yes' },
        },
        { id: 'fld-target-exam', type: 'multi_select', label: 'Target Competitive Exams', options: ['WBCHSE Board Exam', 'CBSE Board Exam', 'WBJEE', 'JEE Main', 'JEE Advanced'], required: true, order: 14, sectionId: 'sec-academic' },

        { id: 'fld-need-bus', type: 'yes_no', label: 'Need Institute Van / Pick-up Support?', defaultValue: 'No', required: true, order: 15, sectionId: 'sec-transport' },
        {
          id: 'fld-bus-stop',
          type: 'text',
          label: 'Preferred Pick-up Stop',
          placeholder: 'e.g. Curzon Gate or Birhata',
          required: true,
          order: 16,
          sectionId: 'sec-transport',
          condition: { dependsOnFieldId: 'fld-need-bus', operator: 'equals', value: 'Yes' },
        },
      ],
      pdfConfig: {
        template: 'modern',
        showWatermark: true,
        watermarkText: 'AKASHDEEP MATH CLASS • OFFICIAL RECORD',
        accentColor: '#2563EB',
        showPhoto: true,
        showSignature: true,
        headerText: 'AKASHDEEP MATHEMATICS COACHING INSTITUTE',
        footerText: 'This is a computer generated official student enrollment confirmation document.',
        showInstituteLogo: true,
      },
      successConfig: {
        title: 'Admission Application Submitted Successfully!',
        message: 'Your registration with Akashdeep Math Class has been confirmed. Please save or print your official admission slip below.',
        showRollNo: true,
        showStudentId: true,
        showPdfDownload: true,
        showPrint: true,
        instructions: 'Please bring a printed copy of this Admission Slip along with 2 passport photos to the first class on Tuesday.',
      },
      duplicateCheckFields: ['phone', 'email'],
      createdAt: '2026-03-01T10:00:00Z',
      updatedAt: '2026-03-05T12:00:00Z',
    },
  ];

  const students: Student[] = [
    {
      id: 'STU-2026-00001',
      instituteId,
      branchId: branchBurdwanId,
      sessionId,
      classId: 'cls-xii',
      batchId: 'batch-xii-morning',
      rollNumber: 'AKM-2026-001',
      admissionFormId: 'form-xii-2026',
      admissionDate: '2026-03-02',
      name: 'Sourav Ghosh',
      gender: 'Male',
      dob: '2009-08-14',
      bloodGroup: 'B+',
      phone: '9832111223',
      email: 'sourav.ghosh09@gmail.com',
      address: '42 B.C. Road, Radhanagar, Burdwan - 713101',
      city: 'Burdwan',
      pincode: '713101',
      fatherName: 'Bikas Chandra Ghosh',
      motherName: 'Anindita Ghosh',
      parentPhone: '9434155667',
      parentEmail: 'bikas.ghosh@gov.in',
      parentOccupation: 'High School Teacher',
      previousSchool: 'Burdwan Town School',
      currentSchool: 'Burdwan CMS High School',
      stream: 'Pure Science',
      subjects: ['Mathematics', 'Physics', 'Chemistry'],
      photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80',
      status: 'active',
      customData: {
        'fld-is-school': 'Yes',
        'fld-class-xi-marks': '94',
        'fld-target-exam': ['WBCHSE Board Exam', 'WBJEE', 'JEE Main'],
        'fld-need-bus': 'No',
      },
      documents: [
        { id: 'doc-1', name: 'Class X Board Marksheet.pdf', type: 'Marksheet', url: '#', uploadDate: '2026-03-02', fileSize: '1.2 MB' },
        { id: 'doc-2', name: 'Aadhaar Card Copy.pdf', type: 'Identity Proof', url: '#', uploadDate: '2026-03-02', fileSize: '850 KB' },
      ],
      notes: [
        { id: 'note-1', author: 'Akashdeep Banerjee', text: 'Exceptional aptitude in coordinate geometry and trigonometric identities. Recommended for JEE Advanced practice module.', createdAt: '2026-03-04T11:20:00Z' },
      ],
      activityLogs: [
        { id: 'act-1', action: 'Admission Form Submitted', timestamp: '2026-03-02T09:15:00Z', details: 'Submitted via public form AKM-XII-MORNING-2026' },
        { id: 'act-2', action: 'Roll Number Assigned', timestamp: '2026-03-02T09:15:01Z', details: 'Assigned AKM-2026-001' },
        { id: 'act-3', action: 'Admission Fee Received', timestamp: '2026-03-02T09:30:00Z', details: 'Paid ₹1,800 via UPI (Ref: 6062881921)' },
      ],
      createdAt: '2026-03-02T09:15:00Z',
      updatedAt: '2026-03-04T11:20:00Z',
    },
    {
      id: 'STU-2026-00002',
      instituteId,
      branchId: branchBurdwanId,
      sessionId,
      classId: 'cls-xii',
      batchId: 'batch-xii-morning',
      rollNumber: 'AKM-2026-002',
      admissionFormId: 'form-xii-2026',
      admissionDate: '2026-03-03',
      name: 'Pooja Bhattacharya',
      gender: 'Female',
      dob: '2009-04-20',
      bloodGroup: 'O+',
      phone: '9832223344',
      email: 'pooja.bhatt@gmail.com',
      address: '15 Vivekananda Pally, Near Big Bazaar, Burdwan',
      city: 'Burdwan',
      pincode: '713104',
      fatherName: 'Prabir Bhattacharya',
      motherName: 'Soma Bhattacharya',
      parentPhone: '9434221100',
      parentOccupation: 'Civil Engineer',
      currentSchool: 'Burdwan Municipal Girls High School',
      stream: 'Science',
      subjects: ['Mathematics', 'Computer Science'],
      photoUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
      status: 'active',
      customData: {
        'fld-is-school': 'Yes',
        'fld-class-xi-marks': '91',
        'fld-target-exam': ['CBSE Board Exam', 'JEE Main'],
        'fld-need-bus': 'Yes',
        'fld-bus-stop': 'Curzon Gate',
      },
      documents: [
        { id: 'doc-3', name: 'School Identity Card.jpg', type: 'School ID', url: '#', uploadDate: '2026-03-03', fileSize: '420 KB' },
      ],
      notes: [],
      activityLogs: [
        { id: 'act-4', action: 'Admission Form Submitted', timestamp: '2026-03-03T14:10:00Z' },
      ],
      createdAt: '2026-03-03T14:10:00Z',
      updatedAt: '2026-03-03T14:10:00Z',
    },
    {
      id: 'STU-2026-00003',
      instituteId,
      branchId: branchBurdwanId,
      sessionId,
      classId: 'cls-xii',
      batchId: 'batch-xii-evening',
      rollNumber: 'AKM-2026-003',
      admissionFormId: 'form-xii-2026',
      admissionDate: '2026-03-04',
      name: 'Rohan Karmakar',
      gender: 'Male',
      dob: '2009-11-05',
      bloodGroup: 'A+',
      phone: '9832334455',
      email: 'rohan.karmakar@outlook.com',
      address: '77 G.T. Road, Shaktigarh, Burdwan',
      city: 'Burdwan',
      pincode: '713149',
      fatherName: 'Dipankar Karmakar',
      parentPhone: '9434332211',
      parentOccupation: 'Business Owner',
      currentSchool: 'Shaktigarh National High School',
      stream: 'Pure Science',
      photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      status: 'active',
      customData: {
        'fld-is-school': 'Yes',
        'fld-class-xi-marks': '86',
        'fld-target-exam': ['WBCHSE Board Exam', 'WBJEE'],
      },
      documents: [],
      notes: [],
      activityLogs: [],
      createdAt: '2026-03-04T16:00:00Z',
      updatedAt: '2026-03-04T16:00:00Z',
    },
  ];

  const attendance: AttendanceRecord[] = [
    { id: 'att-1', instituteId, branchId: branchBurdwanId, classId: 'cls-xii', batchId: 'batch-xii-morning', date: '2026-09-08', studentId: 'STU-2026-00001', status: 'present', markedBy: 'Akashdeep Banerjee' },
    { id: 'att-2', instituteId, branchId: branchBurdwanId, classId: 'cls-xii', batchId: 'batch-xii-morning', date: '2026-09-08', studentId: 'STU-2026-00002', status: 'present', markedBy: 'Akashdeep Banerjee' },
    { id: 'att-3', instituteId, branchId: branchBurdwanId, classId: 'cls-xii', batchId: 'batch-xii-evening', date: '2026-09-08', studentId: 'STU-2026-00003', status: 'present', markedBy: 'Akashdeep Banerjee' },
    { id: 'att-4', instituteId, branchId: branchBurdwanId, classId: 'cls-xii', batchId: 'batch-xii-morning', date: '2026-09-10', studentId: 'STU-2026-00001', status: 'present', markedBy: 'Akashdeep Banerjee' },
    { id: 'att-5', instituteId, branchId: branchBurdwanId, classId: 'cls-xii', batchId: 'batch-xii-morning', date: '2026-09-10', studentId: 'STU-2026-00002', status: 'late', remarks: 'Bus delay 15 mins', markedBy: 'Akashdeep Banerjee' },
  ];

  const feeRecords: FeeRecord[] = [
    {
      id: 'fee-rec-001',
      instituteId,
      branchId: branchBurdwanId,
      studentId: 'STU-2026-00001',
      title: 'Monthly Tuition Fee - September 2026',
      feeType: 'monthly',
      month: 'September 2026',
      totalAmount: 1800,
      paidAmount: 1800,
      dueAmount: 0,
      dueDate: '2026-09-10',
      status: 'paid',
      createdAt: '2026-09-01T08:00:00Z',
    },
    {
      id: 'fee-rec-002',
      instituteId,
      branchId: branchBurdwanId,
      studentId: 'STU-2026-00002',
      title: 'Monthly Tuition Fee - September 2026',
      feeType: 'monthly',
      month: 'September 2026',
      totalAmount: 1800,
      paidAmount: 1000,
      dueAmount: 800,
      dueDate: '2026-09-10',
      status: 'partial',
      createdAt: '2026-09-01T08:00:00Z',
    },
    {
      id: 'fee-rec-003',
      instituteId,
      branchId: branchBurdwanId,
      studentId: 'STU-2026-00003',
      title: 'Monthly Tuition Fee - September 2026',
      feeType: 'monthly',
      month: 'September 2026',
      totalAmount: 1800,
      paidAmount: 0,
      dueAmount: 1800,
      dueDate: '2026-09-10',
      status: 'due',
      createdAt: '2026-09-01T08:00:00Z',
    },
  ];

  const feePayments: FeePayment[] = [
    {
      id: 'pay-001',
      feeRecordId: 'fee-rec-001',
      studentId: 'STU-2026-00001',
      instituteId,
      amount: 1800,
      paymentDate: '2026-09-02',
      paymentMethod: 'upi',
      receiptNumber: 'RCPT-AKM-2026-0081',
      transactionRef: 'UPI/6062881921/HDFC',
      notes: 'Monthly tuition cleared for September 2026',
      collectedBy: 'Akashdeep Banerjee',
    },
    {
      id: 'pay-002',
      feeRecordId: 'fee-rec-002',
      studentId: 'STU-2026-00002',
      instituteId,
      amount: 1000,
      paymentDate: '2026-09-03',
      paymentMethod: 'cash',
      receiptNumber: 'RCPT-AKM-2026-0082',
      notes: 'Partial payment received in cash',
      collectedBy: 'Akashdeep Banerjee',
    },
  ];

  const notices: NoticeNotification[] = [
    {
      id: 'notice-1',
      instituteId,
      title: 'Calculus Mock Test Series - Class XII',
      message: 'Comprehensive 100-marks Mock Test on Differential Calculus & Integral Calculus will be conducted this Sunday from 9:00 AM to 12:00 PM at Burdwan Main Campus. Attendance is mandatory for all students.',
      targetType: 'class',
      targetId: 'cls-xii',
      type: 'exam',
      createdAt: '2026-09-08T10:00:00Z',
      date: '2026-09-08',
      author: 'Akashdeep Sir',
    },
    {
      id: 'notice-2',
      instituteId,
      title: 'Fee Payment Reminder for September 2026',
      message: 'Dear parents and students, please clear the tuition fees for September before 12th September to avoid late processing.',
      targetType: 'all',
      type: 'fee',
      createdAt: '2026-09-05T09:30:00Z',
      date: '2026-09-05',
      author: 'Office Administration',
    },
  ];

  const auditLogs: SystemAuditLog[] = [
    {
      id: 'log-1',
      instituteId,
      userId: 'user-admin-01',
      userName: 'Akashdeep Banerjee',
      action: 'System Bootstrapped',
      details: 'EduRecord multi-tenant cluster initialized with Burdwan & Durgapur branches.',
      timestamp: '2026-09-01T08:00:00Z',
      ipAddress: '127.0.0.1',
    },
    {
      id: 'log-2',
      instituteId,
      userId: 'user-admin-01',
      userName: 'Akashdeep Banerjee',
      action: 'Admission Form Published',
      details: 'Form "Class XII Mathematics & JEE Admission Form 2026-27" published with public slug AKM-XII-MORNING-2026.',
      timestamp: '2026-09-01T10:00:00Z',
      ipAddress: '127.0.0.1',
    },
    {
      id: 'log-3',
      instituteId,
      userId: 'user-admin-01',
      userName: 'Akashdeep Banerjee',
      action: 'Fee Payment Recorded',
      details: 'Payment of ₹1,800 recorded for student Sourav Ghosh (STU-2026-00001). Receipt: RCPT-AKM-2026-0081.',
      timestamp: '2026-09-02T10:30:00Z',
      ipAddress: '127.0.0.1',
    },
  ];

  const users: User[] = [
    {
      id: 'user-admin-01',
      name: 'Akashdeep Banerjee',
      email: 'admin@akashdeepmaths.edu',
      role: 'institute_admin',
      instituteId,
      branchId: branchBurdwanId,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80',
      phone: '+91 98321 45678',
    },
    {
      id: 'user-superadmin-00',
      name: 'Super Administrator',
      email: 'superadmin@edurecord.com',
      role: 'super_admin',
      instituteId,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=160&auto=format&fit=crop&q=80',
      phone: '+91 98000 00000',
    },
    {
      id: 'user-teacher-02',
      name: 'Subhash Roy',
      email: 'subhash@maths.edu',
      role: 'teacher',
      instituteId,
      branchId: branchDurgapurId,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80',
      phone: '+91 98321 99887',
    },
  ];

  return {
    users,
    institutes,
    branches,
    academicSessions,
    classes,
    batches,
    teachers,
    forms,
    students,
    attendance,
    feeRecords,
    feePayments,
    notices,
    auditLogs,
    rollSequences: {
      'cls-xii': 3,
    },
    studentIdSequence: 3,
  };
};

class DatabaseManager {
  private data: DatabaseSchema;
  private isLoaded = false;

  constructor() {
    this.ensureDataDir();
    this.data = this.loadDatabase();
  }

  private ensureDataDir() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadDatabase(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        this.isLoaded = true;
        return parsed;
      }
    } catch (err) {
      console.error('Error reading database file, resetting to initial seed:', err);
    }

    const initial = getInitialData();
    this.saveDatabase(initial);
    this.isLoaded = true;
    return initial;
  }

  public saveDatabase(dataToSave?: DatabaseSchema) {
    const payload = dataToSave || this.data;
    try {
      this.ensureDataDir();
      const tmpFile = `${DB_FILE}.tmp`;
      fs.writeFileSync(tmpFile, JSON.stringify(payload, null, 2), 'utf-8');
      fs.renameSync(tmpFile, DB_FILE);
    } catch (err) {
      console.error('Failed to write database atomically:', err);
    }
  }

  public getRawData(): DatabaseSchema {
    return this.data;
  }

  // Next unique Student ID
  public generateNextStudentId(year = '2026'): string {
    this.data.studentIdSequence = (this.data.studentIdSequence || 0) + 1;
    const num = this.data.studentIdSequence;
    const padded = String(num).padStart(5, '0');
    this.saveDatabase();
    return `STU-${year}-${padded}`;
  }

  // Next unique Roll Number
  public generateNextRollNumber(
    config: { prefix: string; startingNumber: number; length: number; resetScope: string },
    scopeKey: string
  ): string {
    if (!this.data.rollSequences) {
      this.data.rollSequences = {};
    }

    const currentSeq = this.data.rollSequences[scopeKey] || (config.startingNumber - 1);
    const nextSeq = currentSeq + 1;
    this.data.rollSequences[scopeKey] = nextSeq;
    this.saveDatabase();

    const paddedNum = String(nextSeq).padStart(config.length || 3, '0');
    return `${config.prefix || ''}${paddedNum}`;
  }

  // Audit logger
  public logAudit(log: Omit<SystemAuditLog, 'id' | 'timestamp'>) {
    const newLog: SystemAuditLog = {
      ...log,
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: new Date().toISOString(),
    };
    this.data.auditLogs.unshift(newLog);
    // keep max 500 logs
    if (this.data.auditLogs.length > 500) {
      this.data.auditLogs.pop();
    }
    this.saveDatabase();
  }
}

export const db = new DatabaseManager();
