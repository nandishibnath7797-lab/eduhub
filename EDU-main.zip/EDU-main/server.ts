import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { db } from './server/db.js';
import { Student, AdmissionForm, AttendanceRecord, FeeRecord, FeePayment, NoticeNotification } from './src/types.js';

const app = express();
const PORT = 3000;

// Body parsing middleware with generous limit for photo/document uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Helper to extract instituteId header or query parameter for multi-tenant isolation
const getTenantContext = (req: express.Request) => {
  const instituteId = (req.headers['x-institute-id'] as string) || (req.query.instituteId as string) || 'inst-akashdeep-01';
  const branchId = (req.headers['x-branch-id'] as string) || (req.query.branchId as string);
  return { instituteId, branchId };
};

// Current mock session user
let currentUserId = 'user-admin-01';

// ==========================================
// AUTH & USER ENDPOINTS
// ==========================================
app.get('/api/auth/me', (req, res) => {
  const data = db.getRawData();
  const user = data.users.find((u) => u.id === currentUserId) || data.users[0];
  const institute = data.institutes.find((i) => i.id === user.instituteId) || data.institutes[0];
  res.json({ user, institute, availableUsers: data.users });
});

app.post('/api/auth/switch-user', (req, res) => {
  const { userId } = req.body;
  const data = db.getRawData();
  const user = data.users.find((u) => u.id === userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  currentUserId = user.id;
  res.json({ success: true, user });
});

// ==========================================
// INSTITUTES & MULTI-BRANCH ENDPOINTS
// ==========================================
app.get('/api/institutes', (req, res) => {
  const data = db.getRawData();
  res.json(data.institutes);
});

app.post('/api/institutes', (req, res) => {
  const data = db.getRawData();
  const newInst = {
    ...req.body,
    id: `inst-${Date.now()}`,
    createdAt: new Date().toISOString(),
  };
  data.institutes.push(newInst);
  db.saveDatabase();
  db.logAudit({
    instituteId: newInst.id,
    userId: currentUserId,
    userName: 'Admin',
    action: 'Created Institute',
    details: `Created new institute ${newInst.name} (${newInst.code})`,
  });
  res.status(201).json(newInst);
});

app.put('/api/institutes/:id', (req, res) => {
  const data = db.getRawData();
  const idx = data.institutes.findIndex((i) => i.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Institute not found' });
  data.institutes[idx] = { ...data.institutes[idx], ...req.body };
  db.saveDatabase();
  res.json(data.institutes[idx]);
});

app.get('/api/branches', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const branches = data.branches.filter((b) => b.instituteId === instituteId);
  res.json(branches);
});

app.post('/api/branches', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const newBranch = {
    ...req.body,
    id: `br-${Date.now()}`,
    instituteId,
  };
  data.branches.push(newBranch);
  db.saveDatabase();
  res.status(201).json(newBranch);
});

// ==========================================
// ACADEMIC SESSIONS, CLASSES & BATCHES
// ==========================================
app.get('/api/academic-sessions', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  res.json(data.academicSessions.filter((s) => s.instituteId === instituteId));
});

app.post('/api/academic-sessions', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const newSession = { ...req.body, id: `sess-${Date.now()}`, instituteId };
  if (newSession.isCurrent) {
    data.academicSessions.forEach((s) => {
      if (s.instituteId === instituteId) s.isCurrent = false;
    });
  }
  data.academicSessions.push(newSession);
  db.saveDatabase();
  res.status(201).json(newSession);
});

app.get('/api/classes', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  res.json(data.classes.filter((c) => c.instituteId === instituteId));
});

app.post('/api/classes', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const newClass = { ...req.body, id: `cls-${Date.now()}`, instituteId };
  data.classes.push(newClass);
  db.saveDatabase();
  res.status(201).json(newClass);
});

app.get('/api/batches', (req, res) => {
  const { instituteId, branchId } = getTenantContext(req);
  const data = db.getRawData();
  let batches = data.batches.filter((b) => b.instituteId === instituteId);
  if (branchId && branchId !== 'all') {
    batches = batches.filter((b) => b.branchId === branchId);
  }
  // dynamically calculate enrolledSeats
  batches = batches.map((b) => ({
    ...b,
    enrolledSeats: data.students.filter((s) => s.batchId === b.id && s.status === 'active').length,
  }));
  res.json(batches);
});

app.post('/api/batches', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const newBatch = { ...req.body, id: `batch-${Date.now()}`, instituteId, enrolledSeats: 0 };
  data.batches.push(newBatch);
  db.saveDatabase();
  res.status(201).json(newBatch);
});

// ==========================================
// TEACHERS
// ==========================================
app.get('/api/teachers', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  res.json(data.teachers.filter((t) => t.instituteId === instituteId));
});

app.post('/api/teachers', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const newTeacher = { ...req.body, id: `teacher-${Date.now()}`, instituteId };
  data.teachers.push(newTeacher);
  db.saveDatabase();
  res.status(201).json(newTeacher);
});

app.put('/api/teachers/:id', (req, res) => {
  const data = db.getRawData();
  const idx = data.teachers.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Teacher not found' });
  data.teachers[idx] = { ...data.teachers[idx], ...req.body };
  db.saveDatabase();
  res.json(data.teachers[idx]);
});

// ==========================================
// ADMISSION FORMS & BUILDER
// ==========================================
app.get('/api/forms', (req, res) => {
  const { instituteId, branchId } = getTenantContext(req);
  const data = db.getRawData();
  let forms = data.forms.filter((f) => f.instituteId === instituteId);
  if (branchId && branchId !== 'all') {
    forms = forms.filter((f) => f.branchId === branchId);
  }
  // dynamically attach real count
  forms = forms.map((f) => ({
    ...f,
    submissionsCount: data.students.filter((s) => s.admissionFormId === f.id).length,
  }));
  res.json(forms);
});

app.post('/api/forms', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const now = new Date().toISOString();
  const newForm: AdmissionForm = {
    ...req.body,
    id: `form-${Date.now()}`,
    instituteId,
    viewsCount: 0,
    submissionsCount: 0,
    createdAt: now,
    updatedAt: now,
  };
  data.forms.unshift(newForm);
  db.saveDatabase();
  db.logAudit({
    instituteId,
    userId: currentUserId,
    userName: 'Admin',
    action: 'Created Admission Form',
    details: `Created form "${newForm.title}" with slug /admission/${newForm.slug}`,
  });
  res.status(201).json(newForm);
});

app.put('/api/forms/:id', (req, res) => {
  const data = db.getRawData();
  const idx = data.forms.findIndex((f) => f.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Form not found' });
  data.forms[idx] = { ...data.forms[idx], ...req.body, updatedAt: new Date().toISOString() };
  db.saveDatabase();
  res.json(data.forms[idx]);
});

// Duplicate form
app.post('/api/forms/:id/duplicate', (req, res) => {
  const data = db.getRawData();
  const original = data.forms.find((f) => f.id === req.params.id);
  if (!original) return res.status(404).json({ error: 'Form not found' });

  const randomSlugSuffix = Math.random().toString(36).substring(2, 6).toUpperCase();
  const newForm: AdmissionForm = {
    ...JSON.parse(JSON.stringify(original)),
    id: `form-${Date.now()}`,
    title: `${original.title} (Copy)`,
    slug: `${original.slug}-COPY-${randomSlugSuffix}`,
    status: 'draft',
    viewsCount: 0,
    submissionsCount: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  data.forms.unshift(newForm);
  db.saveDatabase();
  res.status(201).json(newForm);
});

// Delete form
app.delete('/api/forms/:id', (req, res) => {
  const data = db.getRawData();
  const idx = data.forms.findIndex((f) => f.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Form not found' });
  data.forms.splice(idx, 1);
  db.saveDatabase();
  res.json({ success: true });
});

// ==========================================
// PUBLIC ADMISSION FORM ENDPOINTS
// ==========================================
// Fetch public form by slug
app.get('/api/public/form/:slug', (req, res) => {
  const { slug } = req.params;
  const data = db.getRawData();
  const form = data.forms.find((f) => f.slug.toLowerCase() === slug.toLowerCase());
  if (!form) {
    return res.status(404).json({ error: 'Admission form not found' });
  }

  // Increment views
  form.viewsCount = (form.viewsCount || 0) + 1;
  db.saveDatabase();

  const institute = data.institutes.find((i) => i.id === form.instituteId);
  const branch = data.branches.find((b) => b.id === form.branchId);
  const classItem = data.classes.find((c) => c.id === form.classId);
  const batch = data.batches.find((b) => b.id === form.batchId);
  const availableBatches = data.batches.filter(
    (b) => b.instituteId === form.instituteId && (form.branchId ? b.branchId === form.branchId : true) && b.classId === form.classId
  );

  res.json({
    form,
    institute,
    branch,
    classItem,
    batch,
    availableBatches,
  });
});

// Submit public admission form
app.post('/api/public/form/:slug/submit', (req, res) => {
  const { slug } = req.params;
  const data = db.getRawData();
  const form = data.forms.find((f) => f.slug.toLowerCase() === slug.toLowerCase());
  if (!form) {
    return res.status(404).json({ error: 'Admission form not found' });
  }

  if (form.status === 'closed') {
    return res.status(400).json({ error: 'This admission form is currently closed.' });
  }

  if (form.maxSubmissions && form.submissionsCount >= form.maxSubmissions) {
    return res.status(400).json({ error: 'Admission capacity reached for this form.' });
  }

  const payload = req.body;
  const cleanPhone = (payload.phone || '').trim().replace(/\D/g, '');
  const cleanEmail = (payload.email || '').trim().toLowerCase();

  // Duplicate Submission Protection
  const checkPhone = form.duplicateCheckFields?.includes('phone') && cleanPhone;
  const checkEmail = form.duplicateCheckFields?.includes('email') && cleanEmail;

  if (checkPhone || checkEmail) {
    const existing = data.students.find((s) => {
      if (s.instituteId !== form.instituteId) return false;
      const sPhone = (s.phone || '').trim().replace(/\D/g, '');
      const sEmail = (s.email || '').trim().toLowerCase();
      if (checkPhone && sPhone && sPhone === cleanPhone) return true;
      if (checkEmail && sEmail && sEmail === cleanEmail) return true;
      return false;
    });

    if (existing) {
      return res.status(409).json({
        error: `A student with this ${checkPhone ? 'phone number' : 'email'} is already enrolled (Student ID: ${existing.id}, Name: ${existing.name}). Please contact administration to update your record.`,
      });
    }
  }

  // Generate unique sequential Student ID
  const studentId = db.generateNextStudentId('2026');

  // Generate scoped sequential Roll Number
  let scopeKey = form.instituteId;
  if (form.rollNumberConfig.resetScope === 'branch') scopeKey = `${form.instituteId}:${form.branchId}`;
  else if (form.rollNumberConfig.resetScope === 'class') scopeKey = `${form.instituteId}:${form.classId}`;
  else if (form.rollNumberConfig.resetScope === 'batch') scopeKey = `${form.instituteId}:${payload.batchId || form.batchId}`;
  else if (form.rollNumberConfig.resetScope === 'form') scopeKey = `form:${form.id}`;

  const rollNumber = db.generateNextRollNumber(form.rollNumberConfig, scopeKey);

  // Find active session
  const activeSession = data.academicSessions.find((s) => s.instituteId === form.instituteId && s.isCurrent) || data.academicSessions[0];

  const now = new Date().toISOString();
  const newStudent: Student = {
    id: studentId,
    instituteId: form.instituteId,
    branchId: form.branchId || payload.branchId,
    sessionId: activeSession ? activeSession.id : 'session-2026-27',
    classId: form.classId || payload.classId,
    batchId: payload.batchId || form.batchId || 'batch-default',
    rollNumber,
    admissionFormId: form.id,
    admissionDate: now.split('T')[0],
    name: payload.name || 'Student',
    gender: payload.gender || 'Male',
    dob: payload.dob || '2008-01-01',
    bloodGroup: payload.bloodGroup,
    email: payload.email,
    phone: payload.phone || '',
    address: payload.address || '',
    city: payload.city,
    pincode: payload.pincode,
    fatherName: payload.fatherName || '',
    motherName: payload.motherName,
    parentPhone: payload.parentPhone || payload.phone || '',
    parentEmail: payload.parentEmail,
    parentOccupation: payload.parentOccupation,
    previousSchool: payload.previousSchool,
    currentSchool: payload.currentSchool,
    stream: payload.stream,
    subjects: payload.subjects || [],
    photoUrl: payload.photoUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
    signatureUrl: payload.signatureUrl,
    status: 'active',
    customData: payload.customData || {},
    documents: payload.documents || [],
    notes: [],
    activityLogs: [
      {
        id: `act-${Date.now()}`,
        action: 'Admission Form Submitted',
        timestamp: now,
        details: `Online registration via form ${form.title} (Slug: ${form.slug})`,
      },
    ],
    createdAt: now,
    updatedAt: now,
  };

  data.students.unshift(newStudent);
  form.submissionsCount = (form.submissionsCount || 0) + 1;

  // Log Audit
  db.logAudit({
    instituteId: form.instituteId,
    userId: 'public-student',
    userName: newStudent.name,
    action: 'Student Admission Completed',
    details: `Student ${newStudent.name} admitted with ID ${studentId}, Roll No ${rollNumber}`,
  });

  db.saveDatabase();

  const institute = data.institutes.find((i) => i.id === form.instituteId);
  const branch = data.branches.find((b) => b.id === newStudent.branchId);
  const classItem = data.classes.find((c) => c.id === newStudent.classId);
  const batch = data.batches.find((b) => b.id === newStudent.batchId);

  res.status(201).json({
    success: true,
    student: newStudent,
    rollNumber,
    studentId,
    formSuccessConfig: form.successConfig,
    pdfConfig: form.pdfConfig,
    institute,
    branch,
    classItem,
    batch,
  });
});

// ==========================================
// STUDENTS DIRECTORY & MANAGEMENT
// ==========================================
app.get('/api/students', (req, res) => {
  const { instituteId, branchId } = getTenantContext(req);
  const { search, classId, batchId, status, page = '1', limit = '50' } = req.query;

  const data = db.getRawData();
  let list = data.students.filter((s) => s.instituteId === instituteId);

  if (branchId && branchId !== 'all') {
    list = list.filter((s) => s.branchId === branchId);
  }
  if (classId && classId !== 'all') {
    list = list.filter((s) => s.classId === classId);
  }
  if (batchId && batchId !== 'all') {
    list = list.filter((s) => s.batchId === batchId);
  }
  if (status && status !== 'all') {
    list = list.filter((s) => s.status === status);
  } else {
    // By default exclude archived unless asked
    if (!status) {
      list = list.filter((s) => s.status !== 'archived');
    }
  }

  if (search && typeof search === 'string' && search.trim()) {
    const q = search.toLowerCase().trim();
    list = list.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q) ||
        s.rollNumber.toLowerCase().includes(q) ||
        (s.phone && s.phone.includes(q)) ||
        (s.parentPhone && s.parentPhone.includes(q)) ||
        (s.email && s.email.toLowerCase().includes(q)) ||
        (s.fatherName && s.fatherName.toLowerCase().includes(q)) ||
        (s.currentSchool && s.currentSchool.toLowerCase().includes(q))
    );
  }

  const total = list.length;
  const p = parseInt(page as string, 10) || 1;
  const l = parseInt(limit as string, 10) || 50;
  const startIndex = (p - 1) * l;
  const paginated = list.slice(startIndex, startIndex + l);

  res.json({
    students: paginated,
    total,
    page: p,
    limit: l,
    totalPages: Math.ceil(total / l),
  });
});

app.get('/api/students/:id', (req, res) => {
  const data = db.getRawData();
  const student = data.students.find((s) => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });

  const institute = data.institutes.find((i) => i.id === student.instituteId);
  const branch = data.branches.find((b) => b.id === student.branchId);
  const classItem = data.classes.find((c) => c.id === student.classId);
  const batch = data.batches.find((b) => b.id === student.batchId);
  const attendance = data.attendance.filter((a) => a.studentId === student.id);
  const fees = data.feeRecords.filter((f) => f.studentId === student.id);
  const payments = data.feePayments.filter((p) => p.studentId === student.id);

  res.json({
    student,
    institute,
    branch,
    classItem,
    batch,
    attendance,
    fees,
    payments,
  });
});

app.post('/api/students', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const studentId = db.generateNextStudentId('2026');

  const payload = req.body;
  // Sequence roll number
  const rollNumber = payload.rollNumber || db.generateNextRollNumber({ prefix: 'STU-', startingNumber: 1, length: 3, resetScope: 'class' }, `${instituteId}:${payload.classId}`);

  const newStudent: Student = {
    ...payload,
    id: studentId,
    instituteId,
    rollNumber,
    status: 'active',
    documents: payload.documents || [],
    notes: payload.notes || [],
    activityLogs: [
      {
        id: `act-${Date.now()}`,
        action: 'Student Added Directly by Admin',
        timestamp: new Date().toISOString(),
        details: `Created by admin user`,
      },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  data.students.unshift(newStudent);
  db.saveDatabase();
  res.status(201).json(newStudent);
});

app.put('/api/students/:id', (req, res) => {
  const data = db.getRawData();
  const idx = data.students.findIndex((s) => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Student not found' });

  const updated = {
    ...data.students[idx],
    ...req.body,
    updatedAt: new Date().toISOString(),
  };

  data.students[idx] = updated;
  db.saveDatabase();
  res.json(updated);
});

// Student Note
app.post('/api/students/:id/notes', (req, res) => {
  const data = db.getRawData();
  const student = data.students.find((s) => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });

  const note = {
    id: `note-${Date.now()}`,
    author: req.body.author || 'Akashdeep Banerjee',
    text: req.body.text,
    createdAt: new Date().toISOString(),
  };

  student.notes.unshift(note);
  student.activityLogs.unshift({
    id: `act-${Date.now()}`,
    action: 'Teacher Note Added',
    timestamp: new Date().toISOString(),
    details: note.text.substring(0, 40) + '...',
  });
  db.saveDatabase();
  res.status(201).json(note);
});

// Student Document
app.post('/api/students/:id/documents', (req, res) => {
  const data = db.getRawData();
  const student = data.students.find((s) => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });

  const doc = {
    id: `doc-${Date.now()}`,
    name: req.body.name || 'Document',
    type: req.body.type || 'Identity Proof',
    url: req.body.url || '#',
    uploadDate: new Date().toISOString().split('T')[0],
    fileSize: req.body.fileSize || '500 KB',
  };

  student.documents.unshift(doc);
  db.saveDatabase();
  res.status(201).json(doc);
});

// Archive / Delete Student
app.post('/api/students/:id/archive', (req, res) => {
  const data = db.getRawData();
  const student = data.students.find((s) => s.id === req.params.id);
  if (!student) return res.status(404).json({ error: 'Student not found' });
  student.status = student.status === 'archived' ? 'active' : 'archived';
  db.saveDatabase();
  res.json({ success: true, status: student.status });
});

app.delete('/api/students/:id', (req, res) => {
  const data = db.getRawData();
  const idx = data.students.findIndex((s) => s.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Student not found' });
  data.students.splice(idx, 1);
  db.saveDatabase();
  res.json({ success: true });
});

// Bulk student operations
app.post('/api/students/bulk', (req, res) => {
  const { action, studentIds, batchId, status } = req.body;
  const data = db.getRawData();

  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    return res.status(400).json({ error: 'No students selected' });
  }

  if (action === 'archive') {
    data.students.forEach((s) => {
      if (studentIds.includes(s.id)) s.status = 'archived';
    });
  } else if (action === 'restore') {
    data.students.forEach((s) => {
      if (studentIds.includes(s.id)) s.status = 'active';
    });
  } else if (action === 'change_batch' && batchId) {
    data.students.forEach((s) => {
      if (studentIds.includes(s.id)) s.batchId = batchId;
    });
  } else if (action === 'change_status' && status) {
    data.students.forEach((s) => {
      if (studentIds.includes(s.id)) s.status = status;
    });
  } else if (action === 'delete') {
    data.students = data.students.filter((s) => !studentIds.includes(s.id));
  }

  db.saveDatabase();
  res.json({ success: true, count: studentIds.length });
});

// ==========================================
// ATTENDANCE MANAGEMENT
// ==========================================
app.get('/api/attendance', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const { date, classId, batchId } = req.query;
  const data = db.getRawData();

  let records = data.attendance.filter((a) => a.instituteId === instituteId);
  if (date) records = records.filter((a) => a.date === date);
  if (classId) records = records.filter((a) => a.classId === classId);
  if (batchId) records = records.filter((a) => a.batchId === batchId);

  res.json(records);
});

app.post('/api/attendance', (req, res) => {
  const { instituteId, branchId } = getTenantContext(req);
  const { date, classId, batchId, records, markedBy } = req.body;
  const data = db.getRawData();

  if (!Array.isArray(records)) {
    return res.status(400).json({ error: 'Invalid attendance records payload' });
  }

  // Remove existing records for this batch & date to allow re-marking
  data.attendance = data.attendance.filter(
    (a) => !(a.instituteId === instituteId && a.date === date && a.batchId === batchId)
  );

  const newRecords: AttendanceRecord[] = records.map((r: any) => ({
    id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    instituteId,
    branchId: branchId || 'br-burdwan-01',
    classId,
    batchId,
    date,
    studentId: r.studentId,
    status: r.status,
    remarks: r.remarks,
    markedBy: markedBy || 'Teacher',
  }));

  data.attendance.push(...newRecords);
  db.saveDatabase();
  res.status(201).json({ success: true, count: newRecords.length });
});

// ==========================================
// FEE MANAGEMENT & RECEIPTS
// ==========================================
app.get('/api/fees', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const feeRecords = data.feeRecords.filter((f) => f.instituteId === instituteId);
  const feePayments = data.feePayments.filter((p) => p.instituteId === instituteId);

  res.json({ feeRecords, feePayments });
});

app.post('/api/fees', (req, res) => {
  const { instituteId, branchId } = getTenantContext(req);
  const data = db.getRawData();
  const newFee: FeeRecord = {
    ...req.body,
    id: `fee-rec-${Date.now()}`,
    instituteId,
    branchId: branchId || 'br-burdwan-01',
    paidAmount: req.body.paidAmount || 0,
    dueAmount: req.body.totalAmount - (req.body.paidAmount || 0),
    status: req.body.paidAmount >= req.body.totalAmount ? 'paid' : (req.body.paidAmount > 0 ? 'partial' : 'due'),
    createdAt: new Date().toISOString(),
  };

  data.feeRecords.unshift(newFee);
  db.saveDatabase();
  res.status(201).json(newFee);
});

app.post('/api/fees/payments', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const { feeRecordId, studentId, amount, paymentMethod, transactionRef, notes, collectedBy } = req.body;

  const feeRecord = data.feeRecords.find((f) => f.id === feeRecordId);
  const receiptNumber = `RCPT-AKM-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const payment: FeePayment = {
    id: `pay-${Date.now()}`,
    feeRecordId,
    studentId,
    instituteId,
    amount: Number(amount),
    paymentDate: new Date().toISOString().split('T')[0],
    paymentMethod: paymentMethod || 'cash',
    receiptNumber,
    transactionRef,
    notes,
    collectedBy: collectedBy || 'Akashdeep Banerjee',
  };

  data.feePayments.unshift(payment);

  if (feeRecord) {
    feeRecord.paidAmount = (feeRecord.paidAmount || 0) + Number(amount);
    feeRecord.dueAmount = Math.max(0, feeRecord.totalAmount - feeRecord.paidAmount);
    feeRecord.status = feeRecord.dueAmount === 0 ? 'paid' : 'partial';
  }

  db.saveDatabase();
  db.logAudit({
    instituteId,
    userId: currentUserId,
    userName: collectedBy || 'Teacher',
    action: 'Payment Collected',
    details: `Collected ₹${amount} for student ${studentId}. Receipt: ${receiptNumber}`,
  });

  res.status(201).json({ payment, feeRecord });
});

// ==========================================
// NOTICES & ANNOUNCEMENTS
// ==========================================
app.get('/api/notices', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  res.json(data.notices.filter((n) => n.instituteId === instituteId));
});

app.post('/api/notices', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  const newNotice: NoticeNotification = {
    ...req.body,
    id: `notice-${Date.now()}`,
    instituteId,
    createdAt: new Date().toISOString(),
    date: new Date().toISOString().split('T')[0],
    author: req.body.author || 'Akashdeep Sir',
  };
  data.notices.unshift(newNotice);
  db.saveDatabase();
  res.status(201).json(newNotice);
});

// ==========================================
// AUDIT LOGS
// ==========================================
app.get('/api/audit-logs', (req, res) => {
  const { instituteId } = getTenantContext(req);
  const data = db.getRawData();
  res.json(data.auditLogs.filter((l) => l.instituteId === instituteId));
});

// ==========================================
// DASHBOARD ANALYTICS & REPORTS
// ==========================================
app.get('/api/reports/dashboard', (req, res) => {
  const { instituteId, branchId } = getTenantContext(req);
  const data = db.getRawData();

  let students = data.students.filter((s) => s.instituteId === instituteId);
  if (branchId && branchId !== 'all') {
    students = students.filter((s) => s.branchId === branchId);
  }

  const activeStudents = students.filter((s) => s.status === 'active').length;
  const newAdmissionsThisMonth = students.filter((s) => {
    const d = new Date(s.admissionDate);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).length;

  const totalClasses = data.classes.filter((c) => c.instituteId === instituteId).length;
  const totalBatches = data.batches.filter((b) => b.instituteId === instituteId).length;
  const totalTeachers = data.teachers.filter((t) => t.instituteId === instituteId).length;

  const instituteFees = data.feeRecords.filter((f) => f.instituteId === instituteId);
  const totalPendingFees = instituteFees.reduce((acc, f) => acc + (f.dueAmount || 0), 0);
  const totalCollectedFees = data.feePayments
    .filter((p) => p.instituteId === instituteId)
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  // Today attendance
  const todayStr = new Date().toISOString().split('T')[0];
  const todayAtt = data.attendance.filter((a) => a.instituteId === instituteId && a.date === todayStr);
  const presentCount = todayAtt.filter((a) => a.status === 'present' || a.status === 'late').length;
  const todayAttendancePercentage = todayAtt.length > 0 ? Math.round((presentCount / todayAtt.length) * 100) : 92;

  // Monthly admissions breakdown
  const monthlyAdmissions = [
    { month: 'Apr 2026', count: 18 },
    { month: 'May 2026', count: 24 },
    { month: 'Jun 2026', count: 35 },
    { month: 'Jul 2026', count: 42 },
    { month: 'Aug 2026', count: 38 },
    { month: 'Sep 2026', count: Math.max(14, students.length) },
  ];

  // Class distribution
  const classDistribution = data.classes
    .filter((c) => c.instituteId === instituteId)
    .map((c) => ({
      className: c.name,
      studentCount: students.filter((s) => s.classId === c.id).length,
    }));

  // Branch distribution
  const branchDistribution = data.branches
    .filter((b) => b.instituteId === instituteId)
    .map((b) => ({
      branchName: b.name,
      studentCount: data.students.filter((s) => s.branchId === b.id).length,
    }));

  res.json({
    totalStudents: students.length,
    newAdmissionsThisMonth,
    activeStudents,
    totalClasses,
    totalBatches,
    totalTeachers,
    totalPendingFees,
    totalCollectedFees,
    todayAttendancePercentage,
    monthlyAdmissions,
    classDistribution,
    branchDistribution,
    recentAdmissions: students.slice(0, 5),
    recentPayments: data.feePayments.filter((p) => p.instituteId === instituteId).slice(0, 5),
  });
});

// ==========================================
// VITE SPA & STATIC ASSET MIDDLEWARE
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EduRecord Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
