import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Plus,
  Download,
  Search,
  FileText,
  Printer,
  Share2,
  TrendingUp,
  AlertCircle,
  Filter,
  CheckCircle2,
} from 'lucide-react';
import { FeePayment, Student, Institute, Branch } from '../../types';
import { api } from '../../api/client';
import { downloadFeeReceiptPdf } from '../../utils/pdfHelper';

interface FeesViewProps {
  students: Student[];
  institute: Institute | null;
  branches: Branch[];
  onOpenCollectFee: (student?: Student) => void;
}

export const FeesView: React.FC<FeesViewProps> = ({
  students,
  institute,
  branches,
  onOpenCollectFee,
}) => {
  const [payments, setPayments] = useState<FeePayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'receipts' | 'defaulters'>('receipts');

  useEffect(() => {
    loadFeeRecords();
  }, []);

  const loadFeeRecords = async () => {
    setLoading(true);
    try {
      const res = await api.getFees();
      setPayments(res.feePayments || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredPayments = payments.filter((p) => {
    const student = students.find((s) => s.id === p.studentId);
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      p.receiptNumber.toLowerCase().includes(q) ||
      (p.transactionRef && p.transactionRef.toLowerCase().includes(q)) ||
      (student && student.name.toLowerCase().includes(q)) ||
      (student && student.rollNumber.toLowerCase().includes(q))
    );
  });

  const totalCollected = payments.reduce((acc, p) => acc + p.amount, 0);

  // Defaulters calculation: active students whose payments < 5000
  const studentPaidMap: Record<string, number> = {};
  payments.forEach((p) => {
    studentPaidMap[p.studentId] = (studentPaidMap[p.studentId] || 0) + p.amount;
  });

  const defaulters = students
    .filter((s) => s.status === 'active')
    .map((s) => {
      const paid = studentPaidMap[s.id] || 0;
      const expected = 7500; // 3 months
      const due = Math.max(0, expected - paid);
      return { student: s, paid, due };
    })
    .filter((d) => d.due > 0);

  const totalPending = defaulters.reduce((acc, d) => acc + d.due, 0);

  const handleDownloadReceipt = (payment: FeePayment) => {
    const student = students.find((s) => s.id === payment.studentId);
    if (!student || !institute) return;
    downloadFeeReceiptPdf(payment, student, institute, branches[0]);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Tuition Fee Ledger</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage fee collections, computerized GST/tuition invoices, receipts and pending dues.
          </p>
        </div>

        <button
          onClick={() => onOpenCollectFee()}
          className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
        >
          <Plus className="h-4 w-4" />
          <span>Collect Tuition Fee</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Total Fees Collected</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">₹{totalCollected.toLocaleString('en-IN')}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Pending Balances</p>
          <p className="text-xl font-bold text-rose-600 mt-1">₹{totalPending.toLocaleString('en-IN')}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Receipts Issued</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{payments.length}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Defaulter Students</p>
          <p className="text-xl font-bold text-amber-600 mt-1">{defaulters.length}</p>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 p-1 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('receipts')}
            className={`rounded-lg px-3.5 py-1.5 transition ${
              activeTab === 'receipts' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Receipts ({payments.length})
          </button>
          <button
            onClick={() => setActiveTab('defaulters')}
            className={`rounded-lg px-3.5 py-1.5 transition ${
              activeTab === 'defaulters' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pending Dues / Defaulters ({defaulters.length})
          </button>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by receipt #, student..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Content Table */}
      {activeTab === 'receipts' ? (
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50/70 font-semibold text-slate-600">
              <tr>
                <th className="px-4 py-3">Receipt No</th>
                <th className="px-4 py-3">Student Name</th>
                <th className="px-4 py-3">Month / Cycle</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Payment Method</th>
                <th className="px-4 py-3 text-right">Amount</th>
                <th className="px-4 py-3 text-right">Receipt PDF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-400">
                    No fee receipts found.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((payment) => {
                  const student = students.find((s) => s.id === payment.studentId);

                  return (
                    <tr key={payment.id} className="hover:bg-slate-50/60">
                      <td className="px-4 py-3 font-mono font-bold text-blue-700">
                        {payment.receiptNumber}
                      </td>

                      <td className="px-4 py-3">
                        <p className="font-bold text-slate-900">{student?.name || 'Student'}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{student?.rollNumber}</p>
                      </td>

                      <td className="px-4 py-3 text-slate-700 font-medium">
                        {payment.month || 'Current Cycle'}
                      </td>

                      <td className="px-4 py-3 text-slate-500">{payment.paymentDate}</td>

                      <td className="px-4 py-3 capitalize text-slate-700">
                        <span className="font-medium">{payment.paymentMethod}</span>
                        {payment.transactionRef && (
                          <span className="text-[10px] text-slate-400 block font-mono">
                            {payment.transactionRef}
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3 text-right font-bold text-emerald-600">
                        ₹{payment.amount.toLocaleString('en-IN')}
                      </td>

                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => handleDownloadReceipt(payment)}
                          title="Download Official Fee Slip"
                          className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50"
                        >
                          <Download className="h-3 w-3 text-slate-500" />
                          <span>PDF</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      ) : (
        /* DEFAULTERS LIST */
        <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50/70 font-semibold text-slate-600">
              <tr>
                <th className="px-4 py-3">Roll No</th>
                <th className="px-4 py-3">Student Name</th>
                <th className="px-4 py-3">Parent Phone</th>
                <th className="px-4 py-3">Fees Paid</th>
                <th className="px-4 py-3">Pending Due</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {defaulters.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-emerald-600 font-semibold">
                    🎉 Excellent! All students have cleared their tuition fees.
                  </td>
                </tr>
              ) : (
                defaulters.map(({ student, paid, due }) => (
                  <tr key={student.id} className="hover:bg-slate-50/60">
                    <td className="px-4 py-3 font-mono font-bold text-slate-800">{student.rollNumber}</td>
                    <td className="px-4 py-3">
                      <p className="font-bold text-slate-900">{student.name}</p>
                      <p className="text-[10px] text-slate-400">{student.phone}</p>
                    </td>
                    <td className="px-4 py-3 text-slate-700 font-medium">
                      {student.parentPhone} ({student.fatherName})
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-700">₹{paid}</td>
                    <td className="px-4 py-3 font-bold text-rose-600">₹{due}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => onOpenCollectFee(student)}
                        className="rounded-lg bg-emerald-600 px-3 py-1 text-xs font-bold text-white hover:bg-emerald-700"
                      >
                        Collect Now
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
