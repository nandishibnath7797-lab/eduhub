import React, { useState, useEffect } from 'react';
import { X, CreditCard, Check, Download, Printer, Share2, Sparkles, CheckCircle2 } from 'lucide-react';
import { Student, Institute, FeePayment, Branch } from '../../types';
import { api } from '../../api/client';
import { downloadFeeReceiptPdf } from '../../utils/pdfHelper';

interface CollectFeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  institute: Institute | null;
  branches: Branch[];
  students: Student[];
  onPaymentSuccess: (payment: FeePayment) => void;
}

export const CollectFeeModal: React.FC<CollectFeeModalProps> = ({
  isOpen,
  onClose,
  student: initialStudent,
  institute,
  branches,
  students,
  onPaymentSuccess,
}) => {
  if (!isOpen) return null;

  const [selectedStudentId, setSelectedStudentId] = useState(initialStudent?.id || students[0]?.id || '');
  const [amount, setAmount] = useState('2500');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'bank_transfer' | 'cheque'>('upi');
  const [transactionRef, setTransactionRef] = useState('');
  const [month, setMonth] = useState('September 2026');
  const [notes, setNotes] = useState('Monthly tuition fee for Mathematics Coaching');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedPayment, setCompletedPayment] = useState<FeePayment | null>(null);

  useEffect(() => {
    if (initialStudent) {
      setSelectedStudentId(initialStudent.id);
    }
  }, [initialStudent]);

  const activeStudent = students.find((s) => s.id === selectedStudentId) || initialStudent;

  const handleSubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStudent) return;
    if (!amount || Number(amount) <= 0) return alert('Enter valid fee amount');

    setIsSubmitting(true);
    try {
      const res = await api.createPayment({
        studentId: activeStudent.id,
        amount: Number(amount),
        paymentMethod,
        transactionRef: transactionRef || (paymentMethod === 'cash' ? 'Cash Counter' : 'UPI Reference'),
        month,
        notes,
      });

      setCompletedPayment(res.payment);
      onPaymentSuccess(res.payment);
    } catch (err: any) {
      alert(`Payment failed: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownloadPdf = () => {
    if (!completedPayment || !activeStudent || !institute) return;
    downloadFeeReceiptPdf(completedPayment, activeStudent, institute, branches[0]);
  };

  const handleShareWhatsApp = () => {
    if (!completedPayment || !activeStudent || !institute) return;
    const text = encodeURIComponent(
      `🧾 *Fee Receipt - ${institute.name}*\n\n` +
      `Receipt No: *${completedPayment.receiptNumber}*\n` +
      `Student Name: *${activeStudent.name}* (Roll: ${activeStudent.rollNumber})\n` +
      `Amount Paid: *₹${completedPayment.amount.toLocaleString('en-IN')}*\n` +
      `Month/Period: ${completedPayment.month}\n` +
      `Payment Mode: ${completedPayment.paymentMethod.toUpperCase()} (${completedPayment.transactionRef})\n` +
      `Date: ${completedPayment.paymentDate}\n\n` +
      `Status: *PAID & VERIFIED* ✅\n` +
      `Thank you!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-lg rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-xs">
              <CreditCard className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                {completedPayment ? 'Fee Receipt Generated' : 'Collect Tuition Fee'}
              </h3>
              <p className="text-[11px] text-slate-500">
                {completedPayment ? completedPayment.receiptNumber : 'Issue computerized tuition fee receipt'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        {completedPayment && activeStudent ? (
          /* PAYMENT SUCCESS CONFIRMATION & RECEIPT */
          <div className="py-4 text-center space-y-4">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600">
              <CheckCircle2 className="h-8 w-8" />
            </div>

            <div>
              <h4 className="text-base font-bold text-slate-900">Payment Recorded Successfully</h4>
              <p className="text-xs text-slate-500 mt-0.5">
                Receipt <strong className="font-mono text-emerald-700">{completedPayment.receiptNumber}</strong> generated
              </p>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-xs space-y-2 text-left">
              <div className="flex justify-between">
                <span className="text-slate-500">Student:</span>
                <span className="font-bold text-slate-800">{activeStudent.name} ({activeStudent.rollNumber})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Amount Paid:</span>
                <span className="font-bold text-emerald-600 text-sm">₹{completedPayment.amount.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Month / Cycle:</span>
                <span className="font-medium text-slate-800">{completedPayment.month}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Mode:</span>
                <span className="font-medium text-slate-800 capitalize">{completedPayment.paymentMethod}</span>
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <button
                onClick={handleDownloadPdf}
                className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
              >
                <Download className="h-4 w-4" />
                <span>Download Official Fee Receipt (PDF)</span>
              </button>

              <button
                onClick={handleShareWhatsApp}
                className="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-emerald-700"
              >
                <Share2 className="h-4 w-4" />
                <span>Send Receipt on WhatsApp</span>
              </button>
            </div>
          </div>
        ) : (
          /* COLLECT FEE FORM */
          <form onSubmit={handleSubmitPayment} className="mt-4 space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-700">Select Student</label>
              <select
                value={selectedStudentId}
                onChange={(e) => setSelectedStudentId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              >
                {students.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} (Roll: {s.rollNumber})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700">Fee Amount (₹)</label>
                <input
                  type="number"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs font-bold text-slate-800 outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Fee Month / Cycle</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. September 2026"
                  value={month}
                  onChange={(e) => setMonth(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-700">Payment Mode</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value as any)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
                >
                  <option value="upi">UPI / GPay / PhonePe</option>
                  <option value="cash">Cash at Counter</option>
                  <option value="bank_transfer">Direct Bank Transfer</option>
                  <option value="cheque">Bank Cheque</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Transaction Ref / UTR</label>
                <input
                  type="text"
                  placeholder="e.g. UPI Ref / Cashier code"
                  value={transactionRef}
                  onChange={(e) => setTransactionRef(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700">Remarks / Note</label>
              <input
                type="text"
                placeholder="Optional remarks"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
              />
            </div>

            <div className="mt-6 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
              <button
                type="button"
                onClick={onClose}
                className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-5 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-700 disabled:opacity-50"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>{isSubmitting ? 'Recording...' : 'Generate Receipt'}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
