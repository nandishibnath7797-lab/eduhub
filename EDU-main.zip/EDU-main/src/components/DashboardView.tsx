import React from 'react';
import {
  Users,
  UserPlus,
  CalendarCheck,
  CreditCard,
  Layers,
  GraduationCap,
  TrendingUp,
  ArrowUpRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { DashboardStats, Student, Institute, Branch } from '../types';

interface DashboardViewProps {
  stats: DashboardStats | null;
  institute: Institute | null;
  selectedBranch: Branch | undefined;
  onNavigateTab: (tab: string) => void;
  onSelectStudent: (student: Student) => void;
  onOpenPublicForm: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  stats,
  institute,
  selectedBranch,
  onNavigateTab,
  onSelectStudent,
  onOpenPublicForm,
}) => {
  if (!stats) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="flex items-center gap-3 text-slate-500 text-sm font-medium">
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-blue-600 border-t-transparent" />
          Loading dashboard metrics...
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Students',
      value: stats.totalStudents,
      change: '+14% this session',
      icon: Users,
      color: 'blue',
      tab: 'students',
    },
    {
      title: 'New Admissions',
      value: stats.newAdmissionsThisMonth,
      change: 'Current month enrollments',
      icon: UserPlus,
      color: 'emerald',
      tab: 'students',
    },
    {
      title: 'Fees Collected',
      value: `₹${stats.totalCollectedFees.toLocaleString('en-IN')}`,
      change: `Pending: ₹${stats.totalPendingFees.toLocaleString('en-IN')}`,
      icon: CreditCard,
      color: 'indigo',
      tab: 'fees',
    },
    {
      title: "Today's Attendance",
      value: `${stats.todayAttendancePercentage}%`,
      change: 'Calculated across active batches',
      icon: CalendarCheck,
      color: 'amber',
      tab: 'attendance',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Welcome Banner */}
      <div className="flex flex-col gap-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-xs sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              {institute ? institute.name : 'Coaching Institute'}
            </h1>
            <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[11px] font-semibold text-blue-700">
              {selectedBranch ? `${selectedBranch.name}` : 'All Campuses'}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Director / Faculty: <span className="font-medium text-slate-700">{institute?.teacherName}</span> • Academic Session: <span className="font-semibold text-slate-800">2026–27</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenPublicForm}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 transition hover:bg-slate-100"
          >
            <ExternalLink className="h-3.5 w-3.5 text-blue-600" />
            <span>Open Public Form</span>
          </button>
          <button
            onClick={() => onNavigateTab('forms')}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xs transition hover:bg-blue-700"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Admission Form Builder</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.title}
              onClick={() => onNavigateTab(card.tab)}
              className="group cursor-pointer rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition hover:border-blue-300 hover:shadow-md"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">{card.title}</span>
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-50 text-slate-700 transition group-hover:bg-blue-50 group-hover:text-blue-600">
                  <Icon className="h-4 w-4" />
                </div>
              </div>
              <div className="mt-3">
                <span className="text-2xl font-bold tracking-tight text-slate-900">{card.value}</span>
                <p className="mt-1 text-[11px] font-medium text-slate-500">{card.change}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Analytics & Breakdown Section */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Admission Growth Visualizer */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Admission Growth Trend</h2>
              <p className="text-xs text-slate-400">Monthly student registrations for Session 2026-27</p>
            </div>
            <div className="flex items-center gap-1 text-emerald-600 text-xs font-semibold">
              <TrendingUp className="h-4 w-4" />
              <span>Consistent Influx</span>
            </div>
          </div>

          {/* Clean SVG Bar Chart */}
          <div className="h-52 w-full pt-4">
            <div className="flex h-40 items-end justify-between gap-3 border-b border-slate-100 px-2 pb-2">
              {stats.monthlyAdmissions.map((m) => {
                const maxVal = Math.max(...stats.monthlyAdmissions.map((x) => x.count), 45);
                const heightPct = Math.round((m.count / maxVal) * 100);
                return (
                  <div key={m.month} className="group relative flex flex-1 flex-col items-center gap-1.5">
                    {/* Tooltip on hover */}
                    <div className="absolute -top-7 opacity-0 transition-opacity group-hover:opacity-100 rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-bold text-white whitespace-nowrap pointer-events-none">
                      {m.count} Admissions
                    </div>
                    <div
                      style={{ height: `${heightPct}%` }}
                      className="w-full max-w-[36px] rounded-t-lg bg-gradient-to-t from-blue-600 to-indigo-500 transition-all duration-300 group-hover:from-blue-700 group-hover:to-indigo-600 shadow-xs"
                    />
                    <span className="text-[10px] font-medium text-slate-500 truncate">{m.month.split(' ')[0]}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="mt-4 grid grid-cols-3 gap-3 border-t border-slate-100 pt-3 text-center">
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">Total Batches</p>
              <p className="text-sm font-bold text-slate-800">{stats.totalBatches}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">Active Classes</p>
              <p className="text-sm font-bold text-slate-800">{stats.totalClasses}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">Faculty Members</p>
              <p className="text-sm font-bold text-slate-800">{stats.totalTeachers}</p>
            </div>
          </div>
        </div>

        {/* Class Distribution & Capacity */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Students by Class</h2>
          <p className="text-xs text-slate-400 mb-4">Class strength distribution</p>

          <div className="space-y-3.5">
            {stats.classDistribution.map((item) => {
              const pct = stats.totalStudents > 0 ? Math.round((item.studentCount / stats.totalStudents) * 100) : 0;
              return (
                <div key={item.className}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-semibold text-slate-700 truncate max-w-[180px]">{item.className}</span>
                    <span className="font-bold text-slate-900">{item.studentCount} students ({pct}%)</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                    <div
                      style={{ width: `${Math.max(pct, 8)}%` }}
                      className="h-full rounded-full bg-blue-600 transition-all duration-500"
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Branch Distribution */}
          <div className="mt-6 border-t border-slate-100 pt-4">
            <h3 className="text-xs font-bold text-slate-800 mb-2">Branch Campuses</h3>
            <div className="space-y-2">
              {stats.branchDistribution.map((b) => (
                <div key={b.branchName} className="flex items-center justify-between text-xs py-1">
                  <span className="text-slate-600 truncate">{b.branchName}</span>
                  <span className="rounded-md bg-slate-100 px-2 py-0.5 font-bold text-slate-800">
                    {b.studentCount}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Admissions & Payments Feed */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Recent Admissions */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Recent Student Admissions</h2>
              <p className="text-xs text-slate-400">Newly enrolled students via public links & forms</p>
            </div>
            <button
              onClick={() => onNavigateTab('students')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700"
            >
              View All
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {stats.recentAdmissions.length === 0 ? (
              <p className="py-6 text-center text-xs text-slate-400">No admissions yet.</p>
            ) : (
              stats.recentAdmissions.map((student) => (
                <div
                  key={student.id}
                  onClick={() => onSelectStudent(student)}
                  className="flex items-center justify-between py-3 cursor-pointer transition hover:bg-slate-50/60 rounded-xl px-2"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={student.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                      alt={student.name}
                      className="h-10 w-10 rounded-full object-cover border border-slate-200"
                    />
                    <div>
                      <p className="text-xs font-bold text-slate-800">{student.name}</p>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                        <span className="font-semibold text-blue-600">{student.rollNumber}</span>
                        <span>•</span>
                        <span>{student.phone}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">
                      {student.status.toUpperCase()}
                    </span>
                    <p className="mt-1 text-[10px] text-slate-400">{student.admissionDate}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Payments */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Recent Tuition Collections</h2>
              <p className="text-xs text-slate-400">Latest fee payments and computerized receipts</p>
            </div>
            <button
              onClick={() => onNavigateTab('fees')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700"
            >
              Fee Ledger
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {stats.recentPayments.length === 0 ? (
              <p className="py-6 text-center text-xs text-slate-400">No recent payments recorded.</p>
            ) : (
              stats.recentPayments.map((payment) => (
                <div key={payment.id} className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 font-bold text-xs">
                      ₹
                    </div>
                    <div>
                      <p className="text-xs font-bold text-slate-800">
                        {payment.receiptNumber}
                      </p>
                      <p className="text-[11px] text-slate-500 capitalize">
                        Method: {payment.paymentMethod} • Ref: {payment.transactionRef || 'Cash'}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-emerald-600">
                      +₹{payment.amount.toLocaleString('en-IN')}
                    </span>
                    <p className="text-[10px] text-slate-400">{payment.paymentDate}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
