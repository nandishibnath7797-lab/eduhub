import React, { useState } from 'react';
import {
  BarChart2,
  TrendingUp,
  Download,
  Printer,
  Calendar,
  CreditCard,
  Users,
  CheckCircle2,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { DashboardStats, Student, ClassItem, Batch, Institute } from '../../types';

interface ReportsViewProps {
  stats: DashboardStats | null;
  students: Student[];
  classes: ClassItem[];
  batches: Batch[];
  institute: Institute | null;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  stats,
  students,
  classes,
  batches,
  institute,
}) => {
  const [selectedReport, setSelectedReport] = useState<'admissions' | 'fees' | 'attendance' | 'batches'>('admissions');

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    let headers: string[] = [];
    let rows: string[][] = [];

    if (selectedReport === 'admissions') {
      headers = ['Student ID', 'Roll Number', 'Name', 'Admission Date', 'Gender', 'Phone'];
      rows = students.map((s) => [
        `"${s.id}"`,
        `"${s.rollNumber}"`,
        `"${s.name}"`,
        `"${s.admissionDate}"`,
        `"${s.gender}"`,
        `"${s.phone}"`,
      ]);
    } else if (selectedReport === 'batches') {
      headers = ['Batch Name', 'Timing Slot', 'Monthly Fee', 'Capacity'];
      rows = batches.map((b) => [
        `"${b.name}"`,
        `"${b.timeSlot}"`,
        `"₹${b.monthlyFee}"`,
        `"${b.capacity}"`,
      ]);
    }

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EduRecord_${selectedReport}_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Analytics & Reports</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Audit-ready academic reporting, monthly collection summaries, and batch capacity utilization.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 rounded-xl bg-slate-800 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-black"
          >
            <Printer className="h-3.5 w-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Report Selector Tabs */}
      <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 p-1 text-xs font-semibold w-fit">
        <button
          onClick={() => setSelectedReport('admissions')}
          className={`rounded-lg px-4 py-1.5 transition ${
            selectedReport === 'admissions' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Admissions Growth
        </button>
        <button
          onClick={() => setSelectedReport('batches')}
          className={`rounded-lg px-4 py-1.5 transition ${
            selectedReport === 'batches' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Batch Capacity & Strength
        </button>
      </div>

      {/* Report Content */}
      <div id="printable-content" className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xs space-y-6">
        {/* Printable Header */}
        <div className="border-b border-slate-100 pb-4 flex justify-between items-center">
          <div>
            <h2 className="text-base font-bold text-slate-900">{institute?.name}</h2>
            <p className="text-xs text-slate-500">
              Faculty / Director: {institute?.teacherName} • Generated on {new Date().toLocaleDateString('en-IN')}
            </p>
          </div>
          <span className="rounded-full bg-blue-50 px-3 py-1 font-mono text-xs font-bold text-blue-700 uppercase">
            Official Audit Report
          </span>
        </div>

        {selectedReport === 'admissions' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-800">Monthly Registration Trend (2026-27)</h3>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {stats?.monthlyAdmissions.map((m) => (
                <div key={m.month} className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-center">
                  <p className="text-xs font-medium text-slate-500">{m.month}</p>
                  <p className="text-xl font-bold text-blue-600 mt-1">{m.count}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Enrolled students</p>
                </div>
              ))}
            </div>

            <h3 className="text-sm font-bold text-slate-800 pt-4">Enrolled Students Register</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 bg-slate-50 font-semibold text-slate-600">
                  <tr>
                    <th className="px-3 py-2">Roll No</th>
                    <th className="px-3 py-2">Student Name</th>
                    <th className="px-3 py-2">Father Name</th>
                    <th className="px-3 py-2">Contact</th>
                    <th className="px-3 py-2">Admission Date</th>
                    <th className="px-3 py-2">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {students.map((s) => (
                    <tr key={s.id}>
                      <td className="px-3 py-2 font-mono font-bold text-slate-800">{s.rollNumber}</td>
                      <td className="px-3 py-2 font-medium text-slate-900">{s.name}</td>
                      <td className="px-3 py-2 text-slate-600">{s.fatherName}</td>
                      <td className="px-3 py-2 text-slate-600">{s.phone}</td>
                      <td className="px-3 py-2 text-slate-500">{s.admissionDate}</td>
                      <td className="px-3 py-2 uppercase font-semibold text-emerald-700">{s.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {selectedReport === 'batches' && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-800">Batch Enrollment & Capacity Audit</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 bg-slate-50 font-semibold text-slate-600">
                  <tr>
                    <th className="px-3 py-2">Batch Name</th>
                    <th className="px-3 py-2">Schedule / Timing</th>
                    <th className="px-3 py-2">Monthly Fee</th>
                    <th className="px-3 py-2">Enrolled Count</th>
                    <th className="px-3 py-2">Max Capacity</th>
                    <th className="px-3 py-2">Utilization</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {batches.map((b) => {
                    const enrolledCount = students.filter((s) => s.batchId === b.id).length;
                    const pct = Math.round((enrolledCount / b.capacity) * 100);

                    return (
                      <tr key={b.id}>
                        <td className="px-3 py-2 font-bold text-slate-900">{b.name}</td>
                        <td className="px-3 py-2 text-slate-600">{b.timeSlot}</td>
                        <td className="px-3 py-2 font-semibold text-emerald-600">₹{b.monthlyFee}</td>
                        <td className="px-3 py-2 font-bold text-blue-600">{enrolledCount}</td>
                        <td className="px-3 py-2 text-slate-600">{b.capacity}</td>
                        <td className="px-3 py-2">
                          <span className="rounded-full bg-slate-100 px-2 py-0.5 font-bold text-slate-800">
                            {pct}%
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
