import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Phone,
  Mail,
  Home,
  GraduationCap,
  CalendarCheck,
  CreditCard,
  FileText,
  Printer,
  Download,
  Plus,
  CheckCircle2,
  AlertCircle,
  Clock,
  QrCode,
  Tag,
  Shield,
  Edit,
  Sparkles,
} from 'lucide-react';
import { Student, ClassItem, Batch, Institute, Branch, FeePayment, AttendanceRecord } from '../../types';
import { downloadStudentAdmissionPdf } from '../../utils/pdfHelper';
import { generateQrCodeUrl } from '../../utils/qrHelper';
import { api } from '../../api/client';

interface StudentProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  institute: Institute | null;
  branches: Branch[];
  classes: ClassItem[];
  batches: Batch[];
  onUpdateStudent: (id: string, updates: Partial<Student>) => Promise<void>;
  onCollectFee: (student: Student) => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  isOpen,
  onClose,
  student,
  institute,
  branches,
  classes,
  batches,
  onUpdateStudent,
  onCollectFee,
}) => {
  if (!isOpen || !student) return null;

  const [activeTab, setActiveTab] = useState<'overview' | 'academic' | 'fees' | 'attendance' | 'idcard' | 'notes'>('overview');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [studentPayments, setStudentPayments] = useState<FeePayment[]>([]);
  const [studentAttendance, setStudentAttendance] = useState<AttendanceRecord[]>([]);
  const [loadingExtras, setLoadingExtras] = useState(false);

  // New Note State
  const [noteText, setNoteText] = useState('');

  const classItem = classes.find((c) => c.id === student.classId);
  const batch = batches.find((b) => b.id === student.batchId);
  const branch = branches.find((b) => b.id === student.branchId);

  useEffect(() => {
    // Generate QR for Student ID Card
    const qrData = `STUDENT:${student.id}|ROLL:${student.rollNumber}|NAME:${student.name}|INSTITUTE:${institute?.name || ''}`;
    generateQrCodeUrl(qrData).then((url) => setQrDataUrl(url));

    // Fetch related fee payments and attendance
    loadStudentDetails();
  }, [student.id]);

  const loadStudentDetails = async () => {
    setLoadingExtras(true);
    try {
      const details = await api.getStudentById(student.id);
      setStudentPayments(details.payments || []);
      setStudentAttendance(details.attendance || []);
    } catch (err) {
      console.error('Failed loading student extras', err);
    } finally {
      setLoadingExtras(false);
    }
  };

  const handleAddNote = async () => {
    if (!noteText.trim()) return;
    const newNote = {
      id: `note-${Date.now()}`,
      author: institute?.teacherName || 'Faculty',
      text: noteText.trim(),
      date: new Date().toISOString().split('T')[0],
    };
    const updatedNotes = [...(student.notes || []), newNote];
    await onUpdateStudent(student.id, { notes: updatedNotes });
    setNoteText('');
  };

  const handleDownloadPdf = () => {
    if (!institute) return;
    downloadStudentAdmissionPdf(student, institute, branch, classItem, batch);
  };

  const totalPaid = studentPayments.reduce((acc, p) => acc + p.amount, 0);
  const monthlyFee = batch?.monthlyFee || 2500;
  const totalDue = Math.max(0, monthlyFee * 3 - totalPaid);

  const totalAttSessions = studentAttendance.length;
  const presentCount = studentAttendance.filter((a) => a.status === 'present').length;
  const attendanceRate = totalAttSessions > 0 ? Math.round((presentCount / totalAttSessions) * 100) : 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-3 sm:p-5">
      <div className="flex h-[92vh] w-full max-w-5xl flex-col rounded-3xl border border-slate-200 bg-white shadow-2xl overflow-hidden">
        {/* Top Header Card */}
        <div className="relative border-b border-slate-200 bg-gradient-to-r from-slate-50 to-blue-50/30 p-6">
          <button
            onClick={onClose}
            className="absolute right-5 top-5 rounded-xl p-2 text-slate-400 hover:bg-slate-200 hover:text-slate-700"
          >
            <X className="h-5 w-5" />
          </button>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img
                src={student.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'}
                alt={student.name}
                className="h-16 w-16 rounded-2xl object-cover border-2 border-white shadow-md"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold tracking-tight text-slate-900">{student.name}</h2>
                  <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-bold text-emerald-800">
                    {student.status.toUpperCase()}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-slate-600">
                  <span>
                    Roll No: <strong className="font-mono text-emerald-700">{student.rollNumber}</strong>
                  </span>
                  <span>•</span>
                  <span>
                    ID: <strong className="font-mono text-blue-700">{student.id}</strong>
                  </span>
                  <span>•</span>
                  <span>
                    Class: <strong className="text-slate-800">{classItem?.name}</strong> ({batch?.name})
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onCollectFee(student)}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-700"
              >
                <CreditCard className="h-3.5 w-3.5" />
                <span>Collect Tuition Fee</span>
              </button>
              <button
                onClick={handleDownloadPdf}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50"
              >
                <FileText className="h-3.5 w-3.5 text-slate-500" />
                <span>Admission Slip (PDF)</span>
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-2 mt-6 overflow-x-auto border-t border-slate-200/80 pt-3">
            {[
              { id: 'overview', label: 'Overview & Profile' },
              { id: 'academic', label: 'Academic & Form Answers' },
              { id: 'attendance', label: `Attendance (${attendanceRate}%)` },
              { id: 'fees', label: `Fee Ledger (₹${totalPaid})` },
              { id: 'idcard', label: 'ID Card' },
              { id: 'notes', label: `Teacher Notes (${student.notes?.length || 0})` },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* TAB 1: OVERVIEW & PROFILE */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Quick KPI Cards */}
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                <div className="rounded-2xl border border-slate-200 bg-slate-50/50 p-4">
                  <p className="text-xs font-medium text-slate-500">Attendance Rate</p>
                  <p className="text-xl font-bold text-slate-900 mt-1">{attendanceRate}%</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{presentCount} present sessions</p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50/50 p-4">
                  <p className="text-xs font-medium text-slate-500">Monthly Tuition Fee</p>
                  <p className="text-xl font-bold text-slate-900 mt-1">₹{monthlyFee}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Cycle: 1st - 5th of month</p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50/50 p-4">
                  <p className="text-xs font-medium text-slate-500">Total Fees Paid</p>
                  <p className="text-xl font-bold text-emerald-600 mt-1">₹{totalPaid}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{studentPayments.length} receipts generated</p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50/50 p-4">
                  <p className="text-xs font-medium text-slate-500">Pending Balance</p>
                  <p className="text-xl font-bold text-rose-600 mt-1">₹{totalDue}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Calculated dues</p>
                </div>
              </div>

              {/* Personal & Parent Two-Column Grid */}
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="rounded-2xl border border-slate-200 p-5 space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Personal Identity
                  </h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Full Name</span>
                      <span className="font-semibold text-slate-800">{student.name}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Gender</span>
                      <span className="font-semibold text-slate-800">{student.gender}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Date of Birth</span>
                      <span className="font-semibold text-slate-800">{student.dob}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Blood Group</span>
                      <span className="font-semibold text-slate-800">{student.bloodGroup || 'B+'}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Student WhatsApp</span>
                      <span className="font-semibold text-slate-800">{student.phone}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Email Address</span>
                      <span className="font-semibold text-slate-800">{student.email || 'Not provided'}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-500">Residential Address</span>
                      <span className="font-semibold text-slate-800 text-right max-w-[200px] truncate">
                        {student.address}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="rounded-2xl border border-slate-200 p-5 space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                    Parent / Guardian Details
                  </h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Father / Guardian</span>
                      <span className="font-semibold text-slate-800">{student.fatherName}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Mother's Name</span>
                      <span className="font-semibold text-slate-800">{student.motherName || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Parent Mobile</span>
                      <span className="font-semibold text-slate-800">{student.parentPhone}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Occupation</span>
                      <span className="font-semibold text-slate-800">{student.parentOccupation || 'Service'}</span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Admission Date</span>
                      <span className="font-semibold text-slate-800">{student.admissionDate}</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span className="text-slate-500">Campus / Branch</span>
                      <span className="font-semibold text-slate-800">{branch?.name || 'Main Campus'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ACADEMIC & SUBMITTED FORM ANSWERS */}
          {activeTab === 'academic' && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-slate-200 p-5">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Academic Enrollment
                </h3>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500">Enrolled Program / Class</span>
                    <p className="font-bold text-slate-800 mt-0.5">{classItem?.name}</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Batch & Time Schedule</span>
                    <p className="font-bold text-slate-800 mt-0.5">{batch?.name} ({batch?.timeSlot})</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Current Regular School</span>
                    <p className="font-bold text-slate-800 mt-0.5">{student.currentSchool || 'Burdwan High School'}</p>
                  </div>
                  <div>
                    <span className="text-slate-500">Subject Stream</span>
                    <p className="font-bold text-slate-800 mt-0.5">{student.stream || 'Pure Science (Mathematics)'}</p>
                  </div>
                </div>
              </div>

              {/* Dynamic Submitted Form Responses */}
              {student.customFields && Object.keys(student.customFields).length > 0 && (
                <div className="rounded-2xl border border-slate-200 p-5">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                    Submitted Custom Form Answers
                  </h3>
                  <div className="divide-y divide-slate-100">
                    {Object.entries(student.customFields).map(([key, val]) => (
                      <div key={key} className="py-2.5 flex justify-between text-xs">
                        <span className="text-slate-500 capitalize">{key.replace('fld-', '').replace(/_/g, ' ')}</span>
                        <span className="font-semibold text-slate-800">{String(val)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: ATTENDANCE */}
          {activeTab === 'attendance' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-800">Attendance Log</h3>
                  <p className="text-xs text-slate-400">Class-wise roll call recordings</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800">
                    {attendanceRate}% Overall Attendance
                  </span>
                </div>
              </div>

              <div className="overflow-hidden rounded-2xl border border-slate-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Date</th>
                      <th className="px-4 py-2.5">Batch</th>
                      <th className="px-4 py-2.5">Status</th>
                      <th className="px-4 py-2.5">Recorded By</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {studentAttendance.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-8 text-center text-slate-400">
                          No attendance sessions logged yet for this student.
                        </td>
                      </tr>
                    ) : (
                      studentAttendance.map((rec) => (
                        <tr key={rec.id}>
                          <td className="px-4 py-2.5 font-medium text-slate-800">{rec.date}</td>
                          <td className="px-4 py-2.5 text-slate-600">{batch?.name || 'Class Batch'}</td>
                          <td className="px-4 py-2.5">
                            <span
                              className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                                rec.status === 'present'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : rec.status === 'absent'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {rec.status}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 text-slate-500">{rec.markedBy || 'Faculty'}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: FEE LEDGER */}
          {activeTab === 'fees' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-800">Fee Ledger & Payment Receipts</h3>
                  <p className="text-xs text-slate-400">Computerized invoices and receipt history</p>
                </div>
                <button
                  onClick={() => onCollectFee(student)}
                  className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Collect Payment</span>
                </button>
              </div>

              <div className="overflow-hidden rounded-2xl border border-slate-200">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Receipt #</th>
                      <th className="px-4 py-2.5">Date</th>
                      <th className="px-4 py-2.5">Payment Method</th>
                      <th className="px-4 py-2.5">Month / Cycle</th>
                      <th className="px-4 py-2.5 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {studentPayments.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-slate-400">
                          No tuition fee payments recorded yet.
                        </td>
                      </tr>
                    ) : (
                      studentPayments.map((pay) => (
                        <tr key={pay.id}>
                          <td className="px-4 py-2.5 font-mono font-bold text-blue-700">{pay.receiptNumber}</td>
                          <td className="px-4 py-2.5 text-slate-600">{pay.paymentDate}</td>
                          <td className="px-4 py-2.5 capitalize font-medium text-slate-700">
                            {pay.paymentMethod} {pay.transactionRef ? `(${pay.transactionRef})` : ''}
                          </td>
                          <td className="px-4 py-2.5 text-slate-500">{pay.month || 'Current Month'}</td>
                          <td className="px-4 py-2.5 text-right font-bold text-emerald-600">
                            ₹{pay.amount.toLocaleString('en-IN')}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: STUDENT ID CARD */}
          {activeTab === 'idcard' && (
            <div className="flex flex-col items-center justify-center p-4">
              {/* ID Card Front */}
              <div
                id="printable-idcard"
                className="w-full max-w-sm rounded-2xl border-2 border-slate-800 bg-white shadow-xl overflow-hidden"
              >
                {/* ID Card Top Header */}
                <div className="bg-slate-900 px-4 py-3 text-center text-white">
                  <h4 className="text-xs font-black uppercase tracking-wider">{institute?.name}</h4>
                  <p className="text-[10px] text-slate-300 font-medium">{branch?.name || institute?.address}</p>
                </div>

                {/* ID Card Body */}
                <div className="p-4 space-y-3">
                  <div className="flex items-center gap-3.5">
                    <img
                      src={student.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'}
                      alt={student.name}
                      className="h-20 w-20 rounded-xl object-cover border-2 border-slate-300"
                    />
                    <div className="space-y-0.5">
                      <h3 className="text-sm font-black text-slate-900">{student.name}</h3>
                      <p className="text-[11px] font-bold text-blue-700">{classItem?.name}</p>
                      <p className="text-[10px] text-slate-500">Roll: <span className="font-bold text-slate-800 font-mono">{student.rollNumber}</span></p>
                      <p className="text-[10px] text-slate-500">ID: <span className="font-bold text-slate-800 font-mono">{student.id}</span></p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 rounded-xl bg-slate-50 p-2 text-[10px]">
                    <div>
                      <span className="text-slate-400">Father:</span>
                      <p className="font-bold text-slate-800 truncate">{student.fatherName}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Emergency:</span>
                      <p className="font-bold text-slate-800">{student.parentPhone}</p>
                    </div>
                  </div>

                  {/* QR Code Bar */}
                  <div className="flex items-center justify-between border-t border-slate-200 pt-2">
                    <div className="text-[9px] text-slate-400">
                      <p>Authorized Student Identity Card</p>
                      <p>Academic Session 2026-27</p>
                    </div>
                    {qrDataUrl && <img src={qrDataUrl} alt="QR" className="h-10 w-10 object-contain" />}
                  </div>
                </div>
              </div>

              <div className="mt-4 flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 rounded-xl bg-slate-800 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-black"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Print ID Card</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 6: TEACHER NOTES */}
          {activeTab === 'notes' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800">Faculty Remarks & Guidance</h3>
                <p className="text-xs text-slate-400">Private internal progress notes</p>
              </div>

              {/* Add Note Input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Type note regarding performance, doubts or parent communication..."
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddNote()}
                  className="flex-1 rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
                <button
                  onClick={handleAddNote}
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
                >
                  Add Note
                </button>
              </div>

              {/* Notes List */}
              <div className="space-y-2">
                {(!student.notes || student.notes.length === 0) ? (
                  <p className="py-6 text-center text-xs text-slate-400">No notes written yet.</p>
                ) : (
                  student.notes.map((n) => (
                    <div key={n.id} className="rounded-xl border border-slate-200 bg-slate-50/50 p-3 text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-slate-800">{n.author}</span>
                        <span className="text-[10px] text-slate-400">{n.date}</span>
                      </div>
                      <p className="text-slate-700 leading-relaxed">{n.text}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
