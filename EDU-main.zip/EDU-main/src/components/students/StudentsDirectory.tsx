import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Download,
  Upload,
  FileText,
  Filter,
  Eye,
  Edit,
  Trash2,
  Archive,
  CreditCard,
  CalendarCheck,
  GraduationCap,
  ChevronLeft,
  ChevronRight,
  CheckSquare,
  Square,
  Sparkles,
} from 'lucide-react';
import { Student, ClassItem, Batch, Branch, Institute } from '../../types';
import { downloadStudentAdmissionPdf } from '../../utils/pdfHelper';

interface StudentsDirectoryProps {
  students: Student[];
  totalStudents: number;
  classes: ClassItem[];
  batches: Batch[];
  branches: Branch[];
  institute: Institute | null;
  onSelectStudent: (student: Student) => void;
  onAddNewStudent: () => void;
  onArchiveStudent: (id: string) => void;
  onDeleteStudent: (id: string) => void;
  onBulkAction: (action: string, ids: string[], param?: string) => Promise<void>;
  onImportCsv: () => void;
}

export const StudentsDirectory: React.FC<StudentsDirectoryProps> = ({
  students,
  totalStudents,
  classes,
  batches,
  branches,
  institute,
  onSelectStudent,
  onAddNewStudent,
  onArchiveStudent,
  onDeleteStudent,
  onBulkAction,
  onImportCsv,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('all');
  const [selectedBatchId, setSelectedBatchId] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('active');

  // Bulk Selection State
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [bulkBatchChangeId, setBulkBatchChangeId] = useState('');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 25;

  const filteredStudents = students.filter((s) => {
    if (selectedStatus !== 'all' && s.status !== selectedStatus) return false;
    if (selectedClassId !== 'all' && s.classId !== selectedClassId) return false;
    if (selectedBatchId !== 'all' && s.batchId !== selectedBatchId) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return (
        s.name.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q) ||
        s.rollNumber.toLowerCase().includes(q) ||
        (s.phone && s.phone.includes(q)) ||
        (s.parentPhone && s.parentPhone.includes(q)) ||
        (s.email && s.email.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const totalPages = Math.ceil(filteredStudents.length / pageSize) || 1;
  const paginatedStudents = filteredStudents.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleSelectAll = () => {
    if (selectedStudentIds.length === paginatedStudents.length) {
      setSelectedStudentIds([]);
    } else {
      setSelectedStudentIds(paginatedStudents.map((s) => s.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    if (selectedStudentIds.includes(id)) {
      setSelectedStudentIds(selectedStudentIds.filter((item) => item !== id));
    } else {
      setSelectedStudentIds([...selectedStudentIds, id]);
    }
  };

  const handleExportCsv = () => {
    const listToExport = selectedStudentIds.length > 0
      ? students.filter((s) => selectedStudentIds.includes(s.id))
      : filteredStudents;

    const headers = ['Student ID', 'Roll Number', 'Full Name', 'Gender', 'DOB', 'Mobile', 'Parent Mobile', 'Father Name', 'Address', 'Status', 'Admission Date'];
    const rows = listToExport.map((s) => [
      `"${s.id}"`,
      `"${s.rollNumber}"`,
      `"${s.name}"`,
      `"${s.gender}"`,
      `"${s.dob}"`,
      `"${s.phone}"`,
      `"${s.parentPhone}"`,
      `"${s.fatherName}"`,
      `"${s.address.replace(/"/g, '""')}"`,
      `"${s.status}"`,
      `"${s.admissionDate}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EduRecord_Students_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-slate-900">Student Directory</h1>
            <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-bold text-blue-700">
              {filteredStudents.length} Records
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Search, filter, manage student admissions, roll numbers, fees and printable documents.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onImportCsv}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50"
          >
            <Upload className="h-3.5 w-3.5 text-slate-500" />
            <span>Import CSV</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50"
          >
            <Download className="h-3.5 w-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>

          <button
            id="add-student-btn"
            onClick={onAddNewStudent}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
          >
            <Plus className="h-4 w-4" />
            <span>Add Student</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        {/* Search */}
        <div className="relative sm:col-span-2">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name, roll no, student ID, mobile..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full rounded-xl border border-slate-200 pl-9 pr-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
          />
        </div>

        {/* Class Filter */}
        <div>
          <select
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-700 outline-none"
          >
            <option value="all">All Classes ({classes.length})</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        {/* Batch Filter */}
        <div>
          <select
            value={selectedBatchId}
            onChange={(e) => setSelectedBatchId(e.target.value)}
            className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-700 outline-none"
          >
            <option value="all">All Batches ({batches.length})</option>
            {batches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-700 outline-none"
          >
            <option value="active">Active Students</option>
            <option value="archived">Archived Records</option>
            <option value="all">All Statuses</option>
          </select>
        </div>
      </div>

      {/* Bulk Actions Banner */}
      {selectedStudentIds.length > 0 && (
        <div className="flex flex-wrap items-center justify-between rounded-2xl border border-blue-200 bg-blue-50 p-3 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-900">
            <span>{selectedStudentIds.length} students selected</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onBulkAction('archive', selectedStudentIds)}
              className="rounded-lg bg-white border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Bulk Archive
            </button>
            <button
              onClick={() => onBulkAction('delete', selectedStudentIds)}
              className="rounded-lg bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-700"
            >
              Bulk Delete
            </button>
          </div>
        </div>
      )}

      {/* Student Table */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="border-b border-slate-200 bg-slate-50/70 font-semibold text-slate-600">
              <tr>
                <th className="w-10 px-4 py-3">
                  <input
                    type="checkbox"
                    checked={
                      paginatedStudents.length > 0 &&
                      selectedStudentIds.length === paginatedStudents.length
                    }
                    onChange={handleSelectAll}
                    className="rounded text-blue-600"
                  />
                </th>
                <th className="px-4 py-3">Student Details</th>
                <th className="px-4 py-3">Roll No & ID</th>
                <th className="px-4 py-3">Class & Batch</th>
                <th className="px-4 py-3">Contact</th>
                <th className="px-4 py-3">Guardian</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No student records matching current filters.
                  </td>
                </tr>
              ) : (
                paginatedStudents.map((student) => {
                  const isSelected = selectedStudentIds.includes(student.id);
                  const classItem = classes.find((c) => c.id === student.classId);
                  const batch = batches.find((b) => b.id === student.batchId);

                  return (
                    <tr
                      key={student.id}
                      onClick={() => onSelectStudent(student)}
                      className={`cursor-pointer transition hover:bg-slate-50/70 ${
                        isSelected ? 'bg-blue-50/40' : ''
                      }`}
                    >
                      <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(student.id)}
                          className="rounded text-blue-600"
                        />
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={student.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                            alt={student.name}
                            className="h-9 w-9 rounded-full object-cover border border-slate-200 shrink-0"
                          />
                          <div>
                            <p className="font-bold text-slate-900">{student.name}</p>
                            <p className="text-[11px] text-slate-400">
                              {student.gender} • DOB: {student.dob}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3 font-mono">
                        <span className="font-bold text-emerald-700 bg-emerald-50 border border-emerald-200/60 rounded px-1.5 py-0.5 text-[11px]">
                          {student.rollNumber}
                        </span>
                        <p className="text-[10px] text-blue-600 font-semibold mt-0.5">{student.id}</p>
                      </td>

                      <td className="px-4 py-3">
                        <p className="font-semibold text-slate-800">{classItem?.name || 'Class'}</p>
                        <p className="text-[11px] text-slate-400 truncate max-w-[140px]">
                          {batch?.name || 'Assigned Batch'}
                        </p>
                      </td>

                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-700">{student.phone}</p>
                        <p className="text-[10px] text-slate-400">{student.email || 'No email'}</p>
                      </td>

                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-700">{student.fatherName}</p>
                        <p className="text-[10px] text-slate-400">{student.parentPhone}</p>
                      </td>

                      <td className="px-4 py-3">
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                            student.status === 'active'
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {student.status}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => onSelectStudent(student)}
                            title="View Full Student Profile"
                            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-blue-600"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (institute) {
                                downloadStudentAdmissionPdf(student, institute, branches[0], classItem, batch);
                              }
                            }}
                            title="Download Official Admission PDF"
                            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-800"
                          >
                            <FileText className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => onArchiveStudent(student.id)}
                            title={student.status === 'archived' ? 'Restore Student' : 'Archive Student'}
                            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-amber-600"
                          >
                            <Archive className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="flex items-center justify-between border-t border-slate-200 px-4 py-3 text-xs text-slate-500">
          <span>
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, filteredStudents.length)} of {filteredStudents.length} students
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1 disabled:opacity-30"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
              <span>Previous</span>
            </button>
            <span className="font-semibold text-slate-700">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1 disabled:opacity-30"
            >
              <span>Next</span>
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
