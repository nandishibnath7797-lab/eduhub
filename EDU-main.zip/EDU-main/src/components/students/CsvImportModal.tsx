import React, { useState } from 'react';
import { X, Upload, Download, Check, AlertCircle, FileSpreadsheet } from 'lucide-react';
import { Student } from '../../types';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (students: Partial<Student>[]) => Promise<void>;
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({
  isOpen,
  onClose,
  onImport,
}) => {
  if (!isOpen) return null;

  const [csvText, setCsvText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedCount, setParsedCount] = useState(0);

  const sampleCsv = `Name,FatherName,Phone,ParentPhone,Gender,DOB,Address
Arun Ghosh,Bimal Ghosh,9832100001,9832100002,Male,2009-04-12,Burdwan Rajbari
Priyanka Sen,Dipak Sen,9832100003,9832100004,Female,2009-07-20,Burdwan Station Road
Subhashish Das,Tapan Das,9832100005,9832100006,Male,2008-11-05,Golapbag Burdwan`;

  const handleDownloadTemplate = () => {
    const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(sampleCsv);
    const link = document.createElement('a');
    link.setAttribute('href', csvContent);
    link.setAttribute('download', 'EduRecord_Student_Import_Template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleProcessImport = async () => {
    if (!csvText.trim()) return alert('Paste CSV data or load template');

    setIsProcessing(true);
    try {
      const lines = csvText.trim().split('\n');
      if (lines.length < 2) throw new Error('CSV must contain header row and at least 1 record.');

      const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
      const studentsToImport: Partial<Student>[] = [];

      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const cols = line.split(',').map((c) => c.trim().replace(/^"|"$/g, ''));

        const s: Partial<Student> = {
          name: cols[0] || `Student ${i}`,
          fatherName: cols[1] || 'Guardian',
          phone: cols[2] || '9876543210',
          parentPhone: cols[3] || cols[2] || '9876543210',
          gender: (cols[4] as any) || 'Male',
          dob: cols[5] || '2009-01-01',
          address: cols[6] || 'Burdwan, West Bengal',
          status: 'active',
          admissionDate: new Date().toISOString().split('T')[0],
        };
        studentsToImport.push(s);
      }

      await onImport(studentsToImport);
      alert(`Successfully imported ${studentsToImport.length} students!`);
      onClose();
    } catch (err: any) {
      alert(`Import error: ${err.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4">
      <div className="w-full max-w-xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white">
              <FileSpreadsheet className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Bulk Import Students (CSV)</h3>
              <p className="text-[11px] text-slate-500">Fast batch enrollment with automatic roll numbers</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">Paste CSV Rows</span>
            <button
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1 text-xs font-semibold text-blue-600 hover:text-blue-700"
            >
              <Download className="h-3 w-3" />
              <span>Download Sample Template</span>
            </button>
          </div>

          <textarea
            rows={7}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            placeholder={`Paste comma-separated data here...\n\nExample:\nName,FatherName,Phone,ParentPhone,Gender,DOB,Address\nSourav Das,Suman Das,9832111111,9832222222,Male,2009-01-01,Burdwan`}
            className="w-full rounded-xl border border-slate-200 p-3 font-mono text-xs text-slate-800 outline-none focus:border-blue-500"
          />

          <p className="text-[11px] text-slate-500">
            Roll numbers and permanent student IDs will be generated atomically according to active numbering rules.
          </p>
        </div>

        <div className="mt-6 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
          <button
            onClick={onClose}
            className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
          >
            Cancel
          </button>
          <button
            onClick={handleProcessImport}
            disabled={isProcessing}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700 disabled:opacity-50"
          >
            <Upload className="h-3.5 w-3.5" />
            <span>{isProcessing ? 'Importing...' : 'Start Import'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
