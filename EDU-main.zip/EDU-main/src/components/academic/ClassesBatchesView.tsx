import React, { useState } from 'react';
import {
  Layers,
  GraduationCap,
  Clock,
  Users,
  Plus,
  Edit,
  Trash2,
  Building2,
  Check,
  Sparkles,
} from 'lucide-react';
import { ClassItem, Batch, Branch, Institute } from '../../types';

interface ClassesBatchesViewProps {
  classes: ClassItem[];
  batches: Batch[];
  branches: Branch[];
  institute: Institute | null;
  onAddClass: (name: string, description: string) => Promise<void>;
  onAddBatch: (batchData: Partial<Batch>) => Promise<void>;
}

export const ClassesBatchesView: React.FC<ClassesBatchesViewProps> = ({
  classes,
  batches,
  branches,
  institute,
  onAddClass,
  onAddBatch,
}) => {
  const [activeTab, setActiveTab] = useState<'classes' | 'batches' | 'branches'>('classes');

  // New Class Form State
  const [showAddClass, setShowAddClass] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newClassDesc, setNewClassDesc] = useState('');

  // New Batch Form State
  const [showAddBatch, setShowAddBatch] = useState(false);
  const [newBatchName, setNewBatchName] = useState('');
  const [newBatchClassId, setNewBatchClassId] = useState(classes[0]?.id || '');
  const [newBatchTime, setNewBatchTime] = useState('07:00 AM - 08:30 AM');
  const [newBatchFee, setNewBatchFee] = useState('2500');
  const [newBatchCapacity, setNewBatchCapacity] = useState('40');

  const handleCreateClass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim()) return;
    await onAddClass(newClassName.trim(), newClassDesc.trim());
    setNewClassName('');
    setNewClassDesc('');
    setShowAddClass(false);
  };

  const handleCreateBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBatchName.trim()) return;
    await onAddBatch({
      name: newBatchName.trim(),
      classId: newBatchClassId,
      branchId: branches[0]?.id,
      timeSlot: newBatchTime,
      monthlyFee: Number(newBatchFee),
      capacity: Number(newBatchCapacity),
    });
    setNewBatchName('');
    setShowAddBatch(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Academic Setup</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure coaching classes, time schedules, batches, and multi-campus branches.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {activeTab === 'classes' && (
            <button
              onClick={() => setShowAddClass(true)}
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              <span>Create New Class</span>
            </button>
          )}

          {activeTab === 'batches' && (
            <button
              onClick={() => setShowAddBatch(true)}
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              <span>Create New Batch</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 p-1 text-xs font-semibold w-fit">
        <button
          onClick={() => setActiveTab('classes')}
          className={`rounded-lg px-4 py-1.5 transition ${
            activeTab === 'classes' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Classes ({classes.length})
        </button>
        <button
          onClick={() => setActiveTab('batches')}
          className={`rounded-lg px-4 py-1.5 transition ${
            activeTab === 'batches' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Batches & Timing ({batches.length})
        </button>
        <button
          onClick={() => setActiveTab('branches')}
          className={`rounded-lg px-4 py-1.5 transition ${
            activeTab === 'branches' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Campus Branches ({branches.length})
        </button>
      </div>

      {/* MODAL: ADD CLASS */}
      {showAddClass && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-900">Add New Class</h3>
            <p className="text-xs text-slate-500 mt-0.5">e.g. Class IX, Class X Foundation, JEE Advanced</p>

            <form onSubmit={handleCreateClass} className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700">Class Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Class XI Pure Mathematics"
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Description</label>
                <input
                  type="text"
                  placeholder="e.g. Board & Olympiad syllabus preparation"
                  value={newClassDesc}
                  onChange={(e) => setNewClassDesc(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>

              <div className="mt-5 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddClass(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700"
                >
                  Save Class
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD BATCH */}
      {showAddBatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-900">Create New Batch</h3>
            <p className="text-xs text-slate-500 mt-0.5">Assign class, time slot, and monthly tuition fee</p>

            <form onSubmit={handleCreateBatch} className="mt-4 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700">Batch Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Batch A (Morning Regular)"
                  value={newBatchName}
                  onChange={(e) => setNewBatchName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Class</label>
                <select
                  value={newBatchClassId}
                  onChange={(e) => setNewBatchClassId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
                >
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Timing Slot</label>
                  <input
                    type="text"
                    value={newBatchTime}
                    onChange={(e) => setNewBatchTime(e.target.value)}
                    placeholder="e.g. 06:30 AM - 08:00 AM"
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700">Monthly Fee (₹)</label>
                  <input
                    type="number"
                    value={newBatchFee}
                    onChange={(e) => setNewBatchFee(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700">Max Student Capacity</label>
                <input
                  type="number"
                  value={newBatchCapacity}
                  onChange={(e) => setNewBatchCapacity(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
                />
              </div>

              <div className="mt-5 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddBatch(false)}
                  className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700"
                >
                  Create Batch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TAB 1: CLASSES */}
      {activeTab === 'classes' && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {classes.map((cls) => {
            const classBatches = batches.filter((b) => b.classId === cls.id);

            return (
              <div
                key={cls.id}
                className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-slate-300"
              >
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-700">
                    CLASS PROGRAM
                  </span>
                  <span className="text-xs text-slate-400">{classBatches.length} Batches</span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mt-2">{cls.name}</h3>
                <p className="text-xs text-slate-500 mt-1">{cls.description || 'Academic curriculum'}</p>

                <div className="mt-4 border-t border-slate-100 pt-3">
                  <p className="text-[11px] font-bold text-slate-600 mb-1.5">Scheduled Batches:</p>
                  <div className="space-y-1">
                    {classBatches.map((b) => (
                      <div key={b.id} className="flex justify-between text-xs py-1 text-slate-600">
                        <span>{b.name}</span>
                        <span className="font-semibold text-slate-800">{b.timeSlot}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 2: BATCHES */}
      {activeTab === 'batches' && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {batches.map((batch) => {
            const cls = classes.find((c) => c.id === batch.classId);

            return (
              <div
                key={batch.id}
                className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs hover:border-slate-300"
              >
                <div className="flex items-center justify-between">
                  <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                    ₹{batch.monthlyFee}/month
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    Cap: {batch.capacity} seats
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 mt-2">{batch.name}</h3>
                <p className="text-xs font-semibold text-blue-600 mt-0.5">{cls?.name}</p>

                <div className="mt-4 rounded-xl bg-slate-50 p-3 space-y-1 text-xs">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Clock className="h-3.5 w-3.5 text-slate-400" />
                    <span>Time: <strong>{batch.timeSlot}</strong></span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Users className="h-3.5 w-3.5 text-slate-400" />
                    <span>Faculty: <strong>{institute?.teacherName}</strong></span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 3: BRANCHES */}
      {activeTab === 'branches' && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {branches.map((br) => (
            <div
              key={br.id}
              className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs"
            >
              <div className="flex items-center gap-2">
                <Building2 className="h-4 w-4 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">{br.name}</h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">{br.address}</p>
              <p className="text-xs text-slate-600 mt-2 font-medium">Contact: {br.phone}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
