import React, { useState, useEffect, useRef } from 'react';
import {
  GraduationCap,
  Building2,
  CheckCircle2,
  AlertCircle,
  Upload,
  Download,
  Printer,
  Share2,
  ArrowRight,
  ArrowLeft,
  Camera,
  FileText,
  User,
  Phone,
  Home,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { AdmissionForm, Institute, Branch, ClassItem, Batch, Student } from '../../types';
import { api } from '../../api/client';
import { downloadStudentAdmissionPdf } from '../../utils/pdfHelper';

interface PublicAdmissionPortalProps {
  slug: string;
  onClose?: () => void;
}

export const PublicAdmissionPortal: React.FC<PublicAdmissionPortalProps> = ({ slug, onClose }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState<AdmissionForm | null>(null);
  const [institute, setInstitute] = useState<Institute | null>(null);
  const [branch, setBranch] = useState<Branch | null>(null);
  const [classItem, setClassItem] = useState<ClassItem | null>(null);
  const [batch, setBatch] = useState<Batch | null>(null);
  const [availableBatches, setAvailableBatches] = useState<Batch[]>([]);

  // Wizard Steps: 1: Personal, 2: Parent, 3: Academic, 4: Custom/Options, 5: Photo & Review
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 5;

  // Form Field State
  const [name, setName] = useState('');
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [dob, setDob] = useState('2009-01-01');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('Burdwan');
  const [pincode, setPincode] = useState('713101');

  // Parents
  const [fatherName, setFatherName] = useState('');
  const [motherName, setMotherName] = useState('');
  const [parentPhone, setParentPhone] = useState('');
  const [parentOccupation, setParentOccupation] = useState('');

  // Academic
  const [selectedBatchId, setSelectedBatchId] = useState('');
  const [previousSchool, setPreviousSchool] = useState('');
  const [currentSchool, setCurrentSchool] = useState('');
  const [stream, setStream] = useState('Pure Science');

  // Dynamic Custom Form Fields map
  const [customData, setCustomData] = useState<Record<string, any>>({});

  // Student Photo
  const [photoUrl, setPhotoUrl] = useState<string>(
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'
  );
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  // Submission Result State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<{
    success: boolean;
    student: Student;
    rollNumber: string;
    studentId: string;
    formSuccessConfig: any;
    pdfConfig: any;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadPublicFormData();
  }, [slug]);

  const loadPublicFormData = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getPublicForm(slug);
      setForm(data.form);
      setInstitute(data.institute);
      setBranch(data.branch);
      setClassItem(data.classItem);
      setBatch(data.batch);
      setAvailableBatches(data.availableBatches || []);
      if (data.batch) {
        setSelectedBatchId(data.batch.id);
      } else if (data.availableBatches?.length > 0) {
        setSelectedBatchId(data.availableBatches[0].id);
      }

      // Initialize default values for custom fields
      const initialCustom: Record<string, any> = {};
      data.form.fields.forEach((f) => {
        if (f.defaultValue !== undefined) {
          initialCustom[f.id] = f.defaultValue;
        }
      });
      setCustomData(initialCustom);
    } catch (err: any) {
      setError(err.message || 'Failed to load admission form.');
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload a valid image file (JPG, PNG).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('Photo size exceeds 5MB. Please upload a smaller image.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setPhotoUrl(result);
      setPhotoPreview(result);
    };
    reader.readAsDataURL(file);
  };

  // Check conditional visibility of custom field
  const isFieldVisible = (f: any): boolean => {
    if (!f.condition) return true;
    const parentVal = customData[f.condition.dependsOnFieldId];
    if (f.condition.operator === 'equals') {
      return String(parentVal) === String(f.condition.value);
    }
    return true;
  };

  const handleSubmitAdmission = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Please enter student full name');
      setCurrentStep(1);
      return;
    }
    if (!phone.trim()) {
      alert('Please enter student contact number');
      setCurrentStep(1);
      return;
    }
    if (!fatherName.trim()) {
      alert('Please enter father/guardian name');
      setCurrentStep(2);
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      const payload = {
        name,
        gender,
        dob,
        bloodGroup,
        phone,
        email,
        address,
        city,
        pincode,
        fatherName,
        motherName,
        parentPhone: parentPhone || phone,
        parentOccupation,
        batchId: selectedBatchId,
        previousSchool,
        currentSchool,
        stream,
        photoUrl: photoPreview || photoUrl,
        customData,
      };

      const res = await api.submitPublicForm(slug, payload);
      setSubmissionResult(res);
    } catch (err: any) {
      setError(err.message || 'Error completing admission.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownloadSlip = () => {
    if (!submissionResult || !institute) return;
    downloadStudentAdmissionPdf(
      submissionResult.student,
      institute,
      branch || undefined,
      classItem || undefined,
      batch || undefined
    );
  };

  const handleShareWhatsApp = () => {
    if (!submissionResult || !institute) return;
    const text = encodeURIComponent(
      `🎉 *Admission Confirmed!*\n\n` +
      `Institute: *${institute.name}*\n` +
      `Student Name: *${submissionResult.student.name}*\n` +
      `Assigned Roll No: *${submissionResult.rollNumber}*\n` +
      `Permanent Student ID: *${submissionResult.studentId}*\n` +
      `Class: ${classItem?.name || ''}\n\n` +
      `Thank you for joining ${institute.name}. Keep your admission slip saved!`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="h-10 w-10 animate-spin rounded-full border-3 border-blue-600 border-t-transparent" />
          <p className="text-sm font-semibold text-slate-700">Loading Official Admission Portal...</p>
        </div>
      </div>
    );
  }

  if (error && !submissionResult) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
        <div className="w-full max-w-md rounded-2xl border border-rose-200 bg-white p-6 text-center shadow-lg">
          <AlertCircle className="mx-auto h-10 w-10 text-rose-500 mb-2" />
          <h2 className="text-base font-bold text-slate-900">Admission Notice</h2>
          <p className="mt-2 text-xs text-slate-600">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 rounded-xl bg-blue-600 px-4 py-2 text-xs font-semibold text-white"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // SUCCESS CONFIRMATION VIEW
  if (submissionResult && institute) {
    const successConfig = submissionResult.formSuccessConfig || form?.successConfig;
    const student = submissionResult.student;

    return (
      <div className="min-h-screen bg-slate-50 py-8 px-4 sm:px-6">
        <div className="mx-auto max-w-2xl rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 shadow-xl">
          {/* Institute Micro Header */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3">
              <img
                src={institute.logo}
                alt={institute.name}
                className="h-10 w-10 rounded-xl object-cover border border-slate-200"
              />
              <div>
                <h3 className="text-sm font-bold text-slate-900">{institute.name}</h3>
                <p className="text-[11px] text-slate-500">{branch?.name || institute.address}</p>
              </div>
            </div>
            {onClose && (
              <button
                onClick={onClose}
                className="rounded-lg border border-slate-200 px-3 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-50"
              >
                Back to Admin
              </button>
            )}
          </div>

          {/* Celebration Banner */}
          <div className="py-6 text-center">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600 shadow-sm">
              <CheckCircle2 className="h-8 w-8" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              {successConfig?.title || 'Admission Application Submitted!'}
            </h1>
            <p className="mx-auto mt-2 max-w-md text-xs text-slate-600 leading-relaxed">
              {successConfig?.message || 'Your enrollment has been successfully recorded.'}
            </p>
          </div>

          {/* Assigned Roll Number & Student ID Badges */}
          <div className="my-4 grid grid-cols-2 gap-4">
            <div className="rounded-2xl border border-blue-200 bg-blue-50/60 p-4 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
                Permanent Student ID
              </span>
              <p className="mt-1 text-lg font-mono font-extrabold text-blue-800">
                {submissionResult.studentId}
              </p>
              <span className="text-[10px] text-blue-600">Save for fee and attendance queries</span>
            </div>

            <div className="rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600">
                Official Roll Number
              </span>
              <p className="mt-1 text-xl font-mono font-extrabold text-emerald-800">
                {submissionResult.rollNumber}
              </p>
              <span className="text-[10px] text-emerald-600">{classItem?.name || 'Class Batch'}</span>
            </div>
          </div>

          {/* Student Quick Summary Card */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/60 p-4">
            <div className="flex items-center gap-4">
              <img
                src={student.photoUrl || photoUrl}
                alt={student.name}
                className="h-16 w-16 rounded-xl object-cover border border-slate-300"
              />
              <div className="space-y-0.5">
                <p className="text-sm font-bold text-slate-900">{student.name}</p>
                <p className="text-xs text-slate-600">
                  Father: <span className="font-medium text-slate-800">{student.fatherName}</span>
                </p>
                <p className="text-xs text-slate-600">
                  Phone: <span className="font-medium text-slate-800">{student.phone}</span>
                </p>
                <p className="text-xs text-slate-500">
                  Admission Date: <span className="font-medium text-slate-700">{student.admissionDate}</span>
                </p>
              </div>
            </div>

            {/* Custom Instructions */}
            {successConfig?.instructions && (
              <div className="mt-4 rounded-xl bg-amber-50 border border-amber-200/80 p-3 text-xs text-amber-900">
                <span className="font-bold">Next Steps: </span>
                {successConfig.instructions}
              </div>
            )}
          </div>

          {/* Action Buttons: PDF Download, WhatsApp, Print */}
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <button
              onClick={handleDownloadSlip}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 text-xs font-bold text-white shadow-md shadow-blue-500/20 hover:bg-blue-700"
            >
              <Download className="h-4 w-4" />
              <span>Download Official Admission Slip (PDF)</span>
            </button>

            <button
              onClick={handleShareWhatsApp}
              className="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-5 py-3 text-xs font-bold text-white shadow-md shadow-emerald-500/20 hover:bg-emerald-700"
            >
              <Share2 className="h-4 w-4" />
              <span>Share WhatsApp</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // MULTI-STEP ADMISSION FORM VIEW
  const progressPct = Math.round((currentStep / totalSteps) * 100);

  return (
    <div className="min-h-screen bg-slate-50 py-6 px-4 sm:px-6">
      <div className="mx-auto max-w-2xl">
        {/* Institute Branding Header */}
        <div className="mb-6 rounded-3xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3.5">
              <img
                src={institute?.logo}
                alt={institute?.name}
                className="h-12 w-12 rounded-2xl object-cover border border-slate-200"
              />
              <div>
                <h1 className="text-base font-bold text-slate-900">{institute?.name}</h1>
                <p className="text-xs text-slate-500 font-medium">
                  Faculty: <span className="text-slate-800 font-semibold">{institute?.teacherName}</span> • {branch?.name || institute?.address}
                </p>
              </div>
            </div>
            {onClose && (
              <button
                onClick={onClose}
                className="text-xs font-semibold text-slate-500 hover:text-slate-800"
              >
                Close Preview
              </button>
            )}
          </div>

          <div className="mt-4 border-t border-slate-100 pt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
            <span>Program: <strong className="text-slate-800">{classItem?.name}</strong></span>
            <span>Helpline WhatsApp: <strong className="text-emerald-600">{institute?.whatsapp}</strong></span>
          </div>
        </div>

        {/* Multi-Step Progress Bar */}
        <div className="mb-6 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2">
            <span>
              Step {currentStep} of {totalSteps}:{' '}
              {currentStep === 1
                ? 'Personal Information'
                : currentStep === 2
                ? 'Parent / Guardian Details'
                : currentStep === 3
                ? 'Academic & School Background'
                : currentStep === 4
                ? 'Custom Admission Questions'
                : 'Student Photo & Review'}
            </span>
            <span className="font-bold text-blue-600">{progressPct}% completed</span>
          </div>
          <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
            <div
              style={{ width: `${progressPct}%` }}
              className="h-full rounded-full bg-blue-600 transition-all duration-300"
            />
          </div>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmitAdmission} className="rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 shadow-sm">
          {/* STEP 1: PERSONAL INFORMATION */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h2 className="text-sm font-bold text-slate-900">Step 1: Student Personal Details</h2>
                <p className="text-xs text-slate-400">Please provide accurate legal identity information</p>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">
                  Student Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sourav Ghosh"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700">
                    Gender <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as any)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700">
                    Date of Birth <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700">
                    Student WhatsApp Mobile <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="10 digit mobile"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700">Student Email Address</label>
                  <input
                    type="email"
                    placeholder="student@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">
                  Residential Address <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="House number, street, area landmark, city and PIN code"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>
            </div>
          )}

          {/* STEP 2: PARENT / GUARDIAN DETAILS */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h2 className="text-sm font-bold text-slate-900">Step 2: Parent / Guardian Information</h2>
                <p className="text-xs text-slate-400">Primary contact for fee receipts, progress and attendance alerts</p>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">
                  Father / Guardian Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Father's full name"
                  value={fatherName}
                  onChange={(e) => setFatherName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700">Mother Name</label>
                  <input
                    type="text"
                    placeholder="Mother's name"
                    value={motherName}
                    onChange={(e) => setMotherName(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700">
                    Parent Calling Mobile <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="Parent mobile number"
                    value={parentPhone}
                    onChange={(e) => setParentPhone(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">Parent Occupation</label>
                <input
                  type="text"
                  placeholder="e.g. Govt Service / Teacher / Businessman"
                  value={parentOccupation}
                  onChange={(e) => setParentOccupation(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>
            </div>
          )}

          {/* STEP 3: ACADEMIC & BATCH SELECTION */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h2 className="text-sm font-bold text-slate-900">Step 3: Academic Background & Batch</h2>
                <p className="text-xs text-slate-400">Class timing and educational history</p>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">Preferred Batch & Timing</label>
                <select
                  value={selectedBatchId}
                  onChange={(e) => setSelectedBatchId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                >
                  {availableBatches.length > 0 ? (
                    availableBatches.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.timeSlot}) - ₹{b.monthlyFee}/mo
                      </option>
                    ))
                  ) : (
                    <option value="batch-default">Default Assigned Batch</option>
                  )}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700">Current School Name</label>
                <input
                  type="text"
                  placeholder="e.g. Burdwan CMS High School"
                  value={currentSchool}
                  onChange={(e) => setCurrentSchool(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700">Stream</label>
                  <select
                    value={stream}
                    onChange={(e) => setStream(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  >
                    <option value="Pure Science">Pure Science (PCM)</option>
                    <option value="Bio Science">Bio Science (PCMB)</option>
                    <option value="Commerce">Commerce with Math</option>
                    <option value="Arts">General / Arts</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700">Previous School / Board</label>
                  <input
                    type="text"
                    placeholder="e.g. WBBSE / CBSE"
                    value={previousSchool}
                    onChange={(e) => setPreviousSchool(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: CUSTOM ADMISSION QUESTIONS (With Real-Time Conditional Logic) */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <div className="border-b border-slate-100 pb-3">
                <h2 className="text-sm font-bold text-slate-900">Step 4: Additional Information</h2>
                <p className="text-xs text-slate-400">Questions tailored for this specific coaching program</p>
              </div>

              {form?.fields
                .filter((f) => !['fld-name', 'fld-gender', 'fld-dob', 'fld-phone', 'fld-email', 'fld-address', 'fld-father', 'fld-parent-phone', 'fld-parent-occ'].includes(f.id))
                .filter(isFieldVisible)
                .map((field) => (
                  <div key={field.id} className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">
                      {field.label} {field.required && <span className="text-rose-500">*</span>}
                    </label>

                    {field.type === 'yes_no' ? (
                      <div className="flex gap-4 pt-1">
                        {['Yes', 'No'].map((opt) => (
                          <label key={opt} className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                            <input
                              type="radio"
                              name={field.id}
                              value={opt}
                              checked={customData[field.id] === opt}
                              onChange={() => setCustomData({ ...customData, [field.id]: opt })}
                              className="text-blue-600 focus:ring-blue-500"
                            />
                            <span>{opt}</span>
                          </label>
                        ))}
                      </div>
                    ) : field.type === 'dropdown' ? (
                      <select
                        value={customData[field.id] || ''}
                        onChange={(e) => setCustomData({ ...customData, [field.id]: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2 text-xs text-slate-800 outline-none"
                      >
                        <option value="">Select option</option>
                        {(field.options || []).map((o) => (
                          <option key={o} value={o}>
                            {o}
                          </option>
                        ))}
                      </select>
                    ) : field.type === 'textarea' ? (
                      <textarea
                        rows={2}
                        placeholder={field.placeholder}
                        value={customData[field.id] || ''}
                        onChange={(e) => setCustomData({ ...customData, [field.id]: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3 py-2 text-xs text-slate-800 outline-none"
                      />
                    ) : (
                      <input
                        type={field.type === 'number' ? 'number' : 'text'}
                        placeholder={field.placeholder}
                        value={customData[field.id] || ''}
                        onChange={(e) => setCustomData({ ...customData, [field.id]: e.target.value })}
                        className="w-full rounded-xl border border-slate-200 bg-slate-50/50 px-3.5 py-2.5 text-xs text-slate-800 outline-none"
                      />
                    )}
                    {field.helpText && <p className="text-[10px] text-slate-400">{field.helpText}</p>}
                  </div>
                ))}
            </div>
          )}

          {/* STEP 5: PHOTO UPLOAD & REVIEW */}
          {currentStep === 5 && (
            <div className="space-y-5">
              <div className="border-b border-slate-100 pb-3">
                <h2 className="text-sm font-bold text-slate-900">Step 5: Student Passport Photo & Review</h2>
                <p className="text-xs text-slate-400">Photo will be printed on Student ID Card and Official Admission Slip</p>
              </div>

              {/* Photo Upload Box with Preview */}
              <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50/50 p-6 text-center">
                <div className="relative mb-3">
                  <img
                    src={photoPreview || photoUrl}
                    alt="Preview"
                    className="h-28 w-28 rounded-2xl object-cover border-2 border-white shadow-md"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute -bottom-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-white shadow-md hover:bg-blue-700"
                  >
                    <Camera className="h-4 w-4" />
                  </button>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />

                <p className="text-xs font-bold text-slate-800">Upload Student Passport Photo</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Supports JPG, PNG (Max 5MB)</p>

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="mt-3 rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50"
                >
                  Change Photo
                </button>
              </div>

              {/* Summary Checklist */}
              <div className="rounded-2xl bg-slate-50 p-4 text-xs space-y-2">
                <p className="font-bold text-slate-800">Review Admission Details:</p>
                <div className="grid grid-cols-2 gap-2 text-slate-600">
                  <p>Student Name: <strong className="text-slate-800">{name}</strong></p>
                  <p>Phone: <strong className="text-slate-800">{phone}</strong></p>
                  <p>Father: <strong className="text-slate-800">{fatherName}</strong></p>
                  <p>DOB: <strong className="text-slate-800">{dob}</strong></p>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Controls */}
          <div className="mt-8 flex items-center justify-between border-t border-slate-100 pt-4">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={() => setCurrentStep(currentStep - 1)}
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                <span>Previous Step</span>
              </button>
            ) : (
              <div />
            )}

            {currentStep < totalSteps ? (
              <button
                type="button"
                onClick={() => {
                  if (currentStep === 1 && (!name || !phone)) {
                    alert('Please fill student name and phone before continuing.');
                    return;
                  }
                  if (currentStep === 2 && !fatherName) {
                    alert('Please enter father/guardian name before continuing.');
                    return;
                  }
                  setCurrentStep(currentStep + 1);
                }}
                className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-bold text-white shadow-xs hover:bg-blue-700"
              >
                <span>Continue</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-600 px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-emerald-600/20 hover:bg-emerald-700 disabled:opacity-50"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>{isSubmitting ? 'Confirming Admission...' : 'Submit & Confirm Admission'}</span>
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
