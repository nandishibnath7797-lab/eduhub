import React from 'react';
import {
  LayoutDashboard,
  Users,
  FileSpreadsheet,
  CalendarCheck,
  CreditCard,
  Layers,
  GraduationCap,
  Contact,
  FileText,
  BarChart3,
  Bell,
  Building2,
  ShieldAlert,
  Sparkles,
  ExternalLink,
  QrCode,
  Sliders,
  ChevronRight,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'students'
  | 'forms'
  | 'attendance'
  | 'fees'
  | 'academics'
  | 'teachers'
  | 'idcards'
  | 'pdf_templates'
  | 'reports'
  | 'notices'
  | 'settings'
  | 'audit_logs'
  | 'onboarding';

interface SidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  instituteName: string;
  isCollapsed?: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  instituteName,
  isCollapsed = false,
}) => {
  const navSections = [
    {
      title: 'OPERATIONS',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'students', label: 'Student Records', icon: Users, badge: 'Live' },
        { id: 'forms', label: 'Admission Forms', icon: FileSpreadsheet, badge: 'Builder' },
        { id: 'attendance', label: 'Attendance', icon: CalendarCheck },
        { id: 'fees', label: 'Fees & Receipts', icon: CreditCard },
      ],
    },
    {
      title: 'ACADEMICS',
      items: [
        { id: 'academics', label: 'Classes & Batches', icon: Layers },
        { id: 'teachers', label: 'Teachers', icon: Contact },
        { id: 'idcards', label: 'Student ID Cards', icon: GraduationCap },
        { id: 'pdf_templates', label: 'PDF Templates', icon: FileText },
      ],
    },
    {
      title: 'REPORTS & COMMS',
      items: [
        { id: 'reports', label: 'Analytics & Reports', icon: BarChart3 },
        { id: 'notices', label: 'Notices & WhatsApp', icon: Bell },
      ],
    },
    {
      title: 'ORGANIZATION',
      items: [
        { id: 'settings', label: 'Institute & Branches', icon: Building2 },
        { id: 'audit_logs', label: 'Audit Log', icon: ShieldAlert },
        { id: 'onboarding', label: 'Setup Wizard', icon: Sparkles },
      ],
    },
  ];

  return (
    <aside
      className={`flex flex-col border-r border-slate-200 bg-white transition-all duration-200 select-none ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Current Institute Micro Header */}
      {!isCollapsed && (
        <div className="border-b border-slate-100 px-4 py-3 bg-slate-50/50">
          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Current Workspace</p>
          <p className="text-xs font-bold text-slate-800 truncate mt-0.5">{instituteName}</p>
        </div>
      )}

      {/* Nav links */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {navSections.map((sec) => (
          <div key={sec.title}>
            {!isCollapsed && (
              <h3 className="px-2.5 mb-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                {sec.title}
              </h3>
            )}
            <div className="space-y-0.5">
              {sec.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-item-${item.id}`}
                    onClick={() => onSelectTab(item.id as NavTab)}
                    title={item.label}
                    className={`group flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-xs font-semibold transition ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon
                        className={`h-4 w-4 shrink-0 transition ${
                          isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-700'
                        }`}
                      />
                      {!isCollapsed && <span>{item.label}</span>}
                    </div>

                    {!isCollapsed && item.badge && (
                      <span
                        className={`rounded-full px-1.5 py-0.2 text-[9px] font-bold ${
                          isActive ? 'bg-blue-700 text-white' : 'bg-slate-200/80 text-slate-700'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Sidebar Footer */}
      {!isCollapsed && (
        <div className="border-t border-slate-100 p-3">
          <div className="rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50/70 p-3 border border-blue-100/80">
            <div className="flex items-center gap-1.5 text-blue-700">
              <Sparkles className="h-3.5 w-3.5" />
              <span className="text-xs font-bold">Admission Portal Ready</span>
            </div>
            <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
              Share your custom links & QR codes for seamless student enrollments.
            </p>
          </div>
        </div>
      )}
    </aside>
  );
};
