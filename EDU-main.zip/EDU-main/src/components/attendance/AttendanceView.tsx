import React, { useState, useEffect } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Download,
  Save,
  Check,
  Users,
  Search,
  AlertCircle,
  Filter,
} from 'lucide-react';
import { Student, ClassItem, Batch, AttendanceRecord } from '../../types';
import { api } from '../../api/client';

interface AttendanceViewProps {
  students: Student[];
  classes: ClassItem[];
  batches: Batch[];
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  students,
  classes,
  batches,
}) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedClassId, setSelectedClassId] = useState(classes[0]?.id || '');
  const [selectedBatchId, setSelectedBatchId] = useState(batches[0]?.id || '');
  const [attendanceMap, setAttendanceMap] = useState<Record<string, 'present' | 'absent' | 'late' | 'leave'>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Filter students for the selected batch
  const batchStudents = students.filter((s) => {
    if (s.status !== 'active') return false;
    if (selectedClassId && s.classId !== selectedClassId) return false;
    if (selectedBatchId && s.batchId !== selectedBatchId) return false;
    if (searchQuery) {
      return (
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.rollNumber.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    return true;
  });

  // Load existing records on date or batch change
  useEffect(() => {
    loadAttendance();
  }, [selectedDate, selectedBatchId]);

  const loadAttendance = async () => {
    try {
      const res = await api.getAttendance({ date: selectedDate, batchId: selectedBatchId });
      const map: Record<string, 'present' | 'absent' | 'late' | 'leave'> = {};
      if (Array.isArray(res) && res.length > 0) {
        res.forEach((r: AttendanceRecord) => {
          map[r.studentId] = r.status;
        });
      } else {
        // Default everyone to present
        batchStudents.forEach((s) => {
          map[s.id] = 'present';
        });
      }
      setAttendanceMap(map);
    } catch (err) {
      console.error(err);
    }
  };

  const handleStatusChange = (studentId: string, status: 'present' | 'absent' | 'late' | 'leave') => {
    setAttendanceMap({
      ...attendanceMap,
      [studentId]: status,
    });
    setSaveSuccess(false);
  };

  const handleMarkAll = (status: 'present' | 'absent') => {
    const newMap = { ...attendanceMap };
    batchStudents.forEach((s) => {
      newMap[s.id] = status;
    });
    setAttendanceMap(newMap);
    setSaveSuccess(false);
  };

  const handleSaveAttendance = async () => {
    setIsSaving(true);
    try {
      const records = batchStudents.map((s) => ({
        studentId: s.id,
        status: attendanceMap[s.id] || 'present',
      }));

      await api.saveAttendance({
        date: selectedDate,
        classId: selectedClassId || classes[0]?.id || 'class-general',
        batchId: selectedBatchId,
        records,
        markedBy: 'Faculty',
      });

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      alert(`Error saving attendance: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleExportCsv = () => {
    const headers = ['Roll Number', 'Student Name', 'Date', 'Status', 'Batch'];
    const rows = batchStudents.map((s) => [
      `"${s.rollNumber}"`,
      `"${s.name}"`,
      `"${selectedDate}"`,
      `"${attendanceMap[s.id] || 'present'}"`,
      `"${batches.find((b) => b.id === selectedBatchId)?.name || ''}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Attendance_${selectedDate}_${selectedBatchId}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const total = batchStudents.length;
  const present = batchStudents.filter((s) => (attendanceMap[s.id] || 'present') === 'present').length;
  const absent = batchStudents.filter((s) => attendanceMap[s.id] === 'absent').length;
  const late = batchStudents.filter((s) => attendanceMap[s.id] === 'late').length;
  const percentage = total > 0 ? Math.round((present / total) * 100) : 0;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Attendance Register</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Conduct 1-click roll call, track student regularity, and export attendance records.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Export Register</span>
          </button>
          <button
            onClick={handleSaveAttendance}
            disabled={isSaving}
            className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs hover:bg-blue-700 disabled:opacity-50"
          >
            {saveSuccess ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
            <span>{isSaving ? 'Saving...' : saveSuccess ? 'Saved!' : 'Save Attendance'}</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
        <div>
          <label className="text-[11px] font-semibold text-slate-600">Attendance Date</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500"
          />
        </div>

        <div>
          <label className="text-[11px] font-semibold text-slate-600">Select Class</label>
          <select
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs text-slate-800 outline-none"
          >
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-[11px] font-semibold text-slate-600">Batch / Schedule</label>
          <select
            value={selectedBatchId}
            onChange={(e) => setSelectedBatchId(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs text-slate-800 outline-none"
          >
            {batches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.timeSlot})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-[11px] font-semibold text-slate-600">Search In Batch</label>
          <input
            type="text"
            placeholder="Roll number or student name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Attendance Stats Cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Total Enrolled in Batch</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{total}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Present Count</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">{present}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Absent Count</p>
          <p className="text-xl font-bold text-rose-600 mt-1">{absent}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Session Attendance Rate</p>
          <p className="text-xl font-bold text-blue-600 mt-1">{percentage}%</p>
        </div>
      </div>

      {/* Quick Mark All Controls */}
      <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50/50 p-3">
        <span className="text-xs font-bold text-slate-700">Quick Roll Call Bulk Actions:</span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleMarkAll('present')}
            className="rounded-lg bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800 hover:bg-emerald-200"
          >
            Mark All Present
          </button>
          <button
            onClick={() => handleMarkAll('absent')}
            className="rounded-lg bg-rose-100 px-3 py-1 text-xs font-bold text-rose-800 hover:bg-rose-200"
          >
            Mark All Absent
          </button>
        </div>
      </div>

      {/* Student Attendance List */}
      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xs">
        <table className="w-full text-left text-xs">
          <thead className="border-b border-slate-200 bg-slate-50/70 font-semibold text-slate-600">
            <tr>
              <th className="px-4 py-3">Roll Number</th>
              <th className="px-4 py-3">Student Name</th>
              <th className="px-4 py-3">Parent Contact</th>
              <th className="px-4 py-3 text-right">Attendance Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {batchStudents.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-10 text-center text-slate-400">
                  No active students enrolled in this batch.
                </td>
              </tr>
            ) : (
              batchStudents.map((student) => {
                const currentStatus = attendanceMap[student.id] || 'present';

                return (
                  <tr key={student.id} className="hover:bg-slate-50/60">
                    <td className="px-4 py-3 font-mono font-bold text-slate-800">
                      {student.rollNumber}
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={student.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                          alt={student.name}
                          className="h-8 w-8 rounded-full object-cover border border-slate-200"
                        />
                        <div>
                          <p className="font-bold text-slate-900">{student.name}</p>
                          <p className="text-[10px] text-slate-400">{student.phone}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3 text-slate-600">
                      {student.parentPhone} ({student.fatherName})
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="inline-flex items-center rounded-xl bg-slate-100 p-1">
                        <button
                          onClick={() => handleStatusChange(student.id, 'present')}
                          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition ${
                            currentStatus === 'present'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          Present
                        </button>
                        <button
                          onClick={() => handleStatusChange(student.id, 'absent')}
                          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition ${
                            currentStatus === 'absent'
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          Absent
                        </button>
                        <button
                          onClick={() => handleStatusChange(student.id, 'late')}
                          className={`rounded-lg px-2.5 py-1 text-xs font-bold transition ${
                            currentStatus === 'late'
                              ? 'bg-amber-600 text-white shadow-xs'
                              : 'text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          Late
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
