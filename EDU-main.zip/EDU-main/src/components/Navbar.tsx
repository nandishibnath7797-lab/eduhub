import React, { useState } from 'react';
import {
  Building2,
  GitBranch,
  Search,
  Plus,
  Bell,
  ChevronDown,
  UserCheck,
  ShieldCheck,
  ExternalLink,
  GraduationCap,
  Sparkles,
  FileText,
  CreditCard,
  CalendarCheck,
  UserPlus,
} from 'lucide-react';
import { Institute, Branch, User } from '../types';

interface NavbarProps {
  currentUser: User | null;
  currentInstitute: Institute | null;
  institutes: Institute[];
  branches: Branch[];
  selectedBranchId: string;
  onSelectInstitute: (instituteId: string) => void;
  onSelectBranch: (branchId: string) => void;
  onOpenSearch: () => void;
  onQuickAction: (action: 'add_student' | 'add_form' | 'mark_attendance' | 'collect_fee' | 'new_notice') => void;
  onSwitchUserRole: (userId: string) => void;
  availableUsers: User[];
  onOpenPublicForm: () => void;
  onOpenNewInstituteModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  currentInstitute,
  institutes,
  branches,
  selectedBranchId,
  onSelectInstitute,
  onSelectBranch,
  onOpenSearch,
  onQuickAction,
  onSwitchUserRole,
  availableUsers,
  onOpenPublicForm,
  onOpenNewInstituteModal,
}) => {
  const [showQuickMenu, setShowQuickMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showInstituteMenu, setShowInstituteMenu] = useState(false);

  const selectedBranch = branches.find((b) => b.id === selectedBranchId);

  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur md:px-6">
      {/* Left: Brand & Multi-Institute Switcher */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600 font-bold text-white shadow-sm shadow-blue-500/30">
            <GraduationCap className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base font-bold tracking-tight text-slate-900">EduRecord</span>
              <span className="rounded-full bg-blue-50 px-1.5 py-0.5 text-[10px] font-semibold text-blue-700">SaaS</span>
            </div>
            <span className="text-[11px] font-medium text-slate-500 hidden sm:inline">Tuition & Student OS</span>
          </div>
        </div>

        {/* Divider */}
        <div className="hidden h-6 w-px bg-slate-200 md:block" />

        {/* Institute Selector */}
        <div className="relative">
          <button
            id="institute-dropdown-btn"
            onClick={() => {
              setShowInstituteMenu(!showInstituteMenu);
              setShowQuickMenu(false);
              setShowUserMenu(false);
            }}
            className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50/70 px-2.5 py-1.5 text-xs font-semibold text-slate-800 transition hover:bg-slate-100"
          >
            <Building2 className="h-3.5 w-3.5 text-blue-600" />
            <span className="max-w-[130px] truncate sm:max-w-[180px]">
              {currentInstitute ? currentInstitute.name : 'Select Institute'}
            </span>
            <ChevronDown className="h-3 w-3 text-slate-400" />
          </button>

          {showInstituteMenu && (
            <div className="absolute left-0 mt-1.5 w-64 rounded-xl border border-slate-200 bg-white p-1.5 shadow-lg ring-1 ring-black/5 z-50">
              <div className="px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Switch Institute (Multi-Tenant)
              </div>
              {institutes.map((inst) => (
                <button
                  key={inst.id}
                  onClick={() => {
                    onSelectInstitute(inst.id);
                    setShowInstituteMenu(false);
                  }}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-left text-xs transition ${
                    currentInstitute?.id === inst.id
                      ? 'bg-blue-50 font-semibold text-blue-700'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="truncate">
                    <p className="truncate">{inst.name}</p>
                    <p className="text-[10px] text-slate-400 font-normal">Code: {inst.code}</p>
                  </div>
                  {currentInstitute?.id === inst.id && <span className="h-1.5 w-1.5 rounded-full bg-blue-600" />}
                </button>
              ))}
              <div className="mt-1 border-t border-slate-100 pt-1">
                <button
                  onClick={() => {
                    setShowInstituteMenu(false);
                    onOpenNewInstituteModal();
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs font-medium text-blue-600 hover:bg-blue-50"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Register New Institute</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Branch Selector */}
        <div className="hidden items-center gap-1.5 lg:flex">
          <GitBranch className="h-3.5 w-3.5 text-slate-400" />
          <select
            id="branch-select"
            value={selectedBranchId}
            onChange={(e) => onSelectBranch(e.target.value)}
            aria-label="Select Branch"
            className="rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 text-xs font-medium text-slate-700 outline-none transition focus:border-blue-500 focus:bg-white"
          >
            <option value="all">All Branches ({branches.length})</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.city})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Center: Global Search Bar */}
      <div className="hidden flex-1 max-w-md mx-4 md:block">
        <button
          id="global-search-trigger"
          onClick={onOpenSearch}
          className="flex w-full items-center justify-between rounded-lg border border-slate-200 bg-slate-50/80 px-3 py-1.5 text-xs text-slate-400 transition hover:border-slate-300 hover:bg-white"
        >
          <span className="flex items-center gap-2">
            <Search className="h-3.5 w-3.5 text-slate-400" />
            <span>Search student, roll no, phone, ID, form...</span>
          </span>
          <kbd className="rounded bg-slate-200/70 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600">⌘K</kbd>
        </button>
      </div>

      {/* Right: Actions, Public Link, User Switcher */}
      <div className="flex items-center gap-2.5">
        {/* Mobile search button */}
        <button
          onClick={onOpenSearch}
          aria-label="Open Search"
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 text-slate-600 md:hidden hover:bg-slate-100"
        >
          <Search className="h-4 w-4" />
        </button>

        {/* Public Admission Form preview button */}
        <button
          id="open-public-portal-btn"
          onClick={onOpenPublicForm}
          className="hidden sm:flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-xs font-semibold text-emerald-700 transition hover:bg-emerald-100"
        >
          <ExternalLink className="h-3.5 w-3.5" />
          <span>Public Form Link</span>
        </button>

        {/* Quick Action Dropdown */}
        <div className="relative">
          <button
            id="quick-actions-btn"
            onClick={() => {
              setShowQuickMenu(!showQuickMenu);
              setShowInstituteMenu(false);
              setShowUserMenu(false);
            }}
            className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm transition hover:bg-blue-700"
          >
            <Plus className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Quick Action</span>
          </button>

          {showQuickMenu && (
            <div className="absolute right-0 mt-1.5 w-52 rounded-xl border border-slate-200 bg-white p-1.5 shadow-lg ring-1 ring-black/5 z-50">
              <button
                onClick={() => {
                  onQuickAction('add_student');
                  setShowQuickMenu(false);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <UserPlus className="h-4 w-4 text-blue-600" />
                <span>New Student Admission</span>
              </button>
              <button
                onClick={() => {
                  onQuickAction('add_form');
                  setShowQuickMenu(false);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <FileText className="h-4 w-4 text-purple-600" />
                <span>Create Admission Form</span>
              </button>
              <button
                onClick={() => {
                  onQuickAction('mark_attendance');
                  setShowQuickMenu(false);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <CalendarCheck className="h-4 w-4 text-emerald-600" />
                <span>Mark Attendance</span>
              </button>
              <button
                onClick={() => {
                  onQuickAction('collect_fee');
                  setShowQuickMenu(false);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-xs font-medium text-slate-700 hover:bg-slate-50"
              >
                <CreditCard className="h-4 w-4 text-amber-600" />
                <span>Collect Fee & Receipt</span>
              </button>
            </div>
          )}
        </div>

        {/* User Role Switcher Dropdown */}
        <div className="relative">
          <button
            id="user-profile-menu-btn"
            onClick={() => {
              setShowUserMenu(!showUserMenu);
              setShowInstituteMenu(false);
              setShowQuickMenu(false);
            }}
            className="flex items-center gap-2 rounded-lg border border-slate-200 p-1 pl-1.5 text-left transition hover:bg-slate-50"
          >
            <img
              src={currentUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
              alt={currentUser?.name || 'User'}
              className="h-7 w-7 rounded-full object-cover"
            />
            <div className="hidden text-left xl:block">
              <p className="text-xs font-bold leading-none text-slate-800">{currentUser?.name}</p>
              <p className="text-[10px] text-slate-400 font-medium capitalize">
                {currentUser?.role.replace('_', ' ')}
              </p>
            </div>
            <ChevronDown className="h-3 w-3 text-slate-400" />
          </button>

          {showUserMenu && (
            <div className="absolute right-0 mt-1.5 w-60 rounded-xl border border-slate-200 bg-white p-2 shadow-lg ring-1 ring-black/5 z-50">
              <div className="border-b border-slate-100 pb-2 px-1">
                <p className="text-xs font-bold text-slate-900">{currentUser?.name}</p>
                <p className="text-[11px] text-slate-500">{currentUser?.email}</p>
                <span className="mt-1 inline-block rounded bg-blue-100 px-1.5 py-0.5 text-[10px] font-semibold text-blue-800 capitalize">
                  {currentUser?.role.replace('_', ' ')}
                </span>
              </div>

              <div className="pt-2">
                <p className="px-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Switch Active Role (RBAC Demo)
                </p>
                {availableUsers.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => {
                      onSwitchUserRole(u.id);
                      setShowUserMenu(false);
                    }}
                    className={`mt-1 flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-xs ${
                      currentUser?.id === u.id
                        ? 'bg-blue-50 font-semibold text-blue-700'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p>{u.name}</p>
                      <p className="text-[10px] text-slate-400 font-normal capitalize">
                        {u.role.replace('_', ' ')}
                      </p>
                    </div>
                    {currentUser?.id === u.id && <UserCheck className="h-3.5 w-3.5 text-blue-600" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
