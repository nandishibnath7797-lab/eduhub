import React, { useState, useEffect } from 'react';
import { Search, X, User, FileText, ArrowRight, Phone, Mail, GraduationCap } from 'lucide-react';
import { Student, AdmissionForm } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  forms: AdmissionForm[];
  onSelectStudent: (student: Student) => void;
  onSelectForm: (form: AdmissionForm) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  students,
  forms,
  onSelectStudent,
  onSelectForm,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else onClose(); // parent handles toggle
      }
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  const filteredStudents = q
    ? students
        .filter(
          (s) =>
            s.name.toLowerCase().includes(q) ||
            s.id.toLowerCase().includes(q) ||
            s.rollNumber.toLowerCase().includes(q) ||
            (s.phone && s.phone.includes(q)) ||
            (s.email && s.email.toLowerCase().includes(q)) ||
            (s.fatherName && s.fatherName.toLowerCase().includes(q))
        )
        .slice(0, 6)
    : [];

  const filteredForms = q
    ? forms
        .filter(
          (f) =>
            f.title.toLowerCase().includes(q) ||
            f.slug.toLowerCase().includes(q)
        )
        .slice(0, 4)
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-slate-900/40 p-4 pt-20 backdrop-blur-xs">
      <div className="w-full max-w-xl rounded-2xl border border-slate-200 bg-white shadow-2xl overflow-hidden ring-1 ring-black/5 animate-in fade-in zoom-in-95 duration-150">
        {/* Search Input */}
        <div className="flex items-center border-b border-slate-100 px-4 py-3">
          <Search className="h-5 w-5 text-slate-400 shrink-0" />
          <input
            id="global-search-input"
            autoFocus
            type="text"
            placeholder="Search students by name, roll no, student ID, mobile or forms..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full px-3 text-sm font-medium text-slate-800 placeholder-slate-400 outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="rounded p-1 text-slate-400 hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
          <kbd className="hidden sm:inline rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-500">
            ESC
          </kbd>
        </div>

        {/* Search Results */}
        <div className="max-h-96 overflow-y-auto p-2">
          {!q && (
            <div className="py-8 text-center text-xs text-slate-400">
              Type student name (e.g. "Sourav"), Roll No ("001"), or Form title to search instantly.
            </div>
          )}

          {q && filteredStudents.length === 0 && filteredForms.length === 0 && (
            <div className="py-8 text-center text-xs text-slate-400">
              No matching records found for "{query}".
            </div>
          )}

          {filteredStudents.length > 0 && (
            <div className="mb-2">
              <p className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Students ({filteredStudents.length})
              </p>
              <div className="space-y-1">
                {filteredStudents.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      onSelectStudent(s);
                      onClose();
                    }}
                    className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-left transition hover:bg-blue-50/70"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={s.photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                        alt={s.name}
                        className="h-8 w-8 rounded-full object-cover border border-slate-200"
                      />
                      <div>
                        <p className="text-xs font-bold text-slate-800">{s.name}</p>
                        <p className="text-[11px] text-slate-500">
                          Roll: <span className="font-semibold text-emerald-600">{s.rollNumber}</span> • ID:{' '}
                          <span className="font-semibold text-blue-600">{s.id}</span>
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-semibold text-slate-600">
                        {s.phone}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {filteredForms.length > 0 && (
            <div>
              <p className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Admission Forms ({filteredForms.length})
              </p>
              <div className="space-y-1">
                {filteredForms.map((f) => (
                  <button
                    key={f.id}
                    onClick={() => {
                      onSelectForm(f);
                      onClose();
                    }}
                    className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-left transition hover:bg-purple-50/70"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-100 text-purple-700">
                        <FileText className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800">{f.title}</p>
                        <p className="text-[10px] text-slate-400">Slug: /admission/{f.slug}</p>
                      </div>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
