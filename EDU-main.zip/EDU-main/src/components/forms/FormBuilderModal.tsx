import React, { useState } from 'react';
import {
  X,
  Plus,
  Trash2,
  Copy,
  MoveUp,
  MoveDown,
  Eye,
  Save,
  Check,
  Smartphone,
  Monitor,
  Settings,
  Sliders,
  Layers,
  Sparkles,
  HelpCircle,
  FileCheck,
  AlertCircle,
} from 'lucide-react';
import { AdmissionForm, FormField, FormFieldType, FormSection, Branch, ClassItem, Batch } from '../../types';

interface FormBuilderModalProps {
  isOpen: boolean;
  onClose: () => void;
  form: AdmissionForm | null;
  onSave: (formData: Partial<AdmissionForm>) => Promise<void>;
  branches: Branch[];
  classes: ClassItem[];
  batches: Batch[];
  instituteCode: string;
}

const FIELD_TYPES: { type: FormFieldType; label: string; icon: string }[] = [
  { type: 'text', label: 'Single Line Text', icon: 'Aa' },
  { type: 'textarea', label: 'Paragraph / Address', icon: '¶' },
  { type: 'number', label: 'Number / Marks', icon: '123' },
  { type: 'email', label: 'Email Address', icon: '@' },
  { type: 'phone', label: 'Phone / WhatsApp', icon: '📞' },
  { type: 'date', label: 'Date of Birth / Date', icon: '📅' },
  { type: 'dropdown', label: 'Select Dropdown', icon: '▼' },
  { type: 'radio', label: 'Single Choice (Radio)', icon: '◉' },
  { type: 'checkbox', label: 'Checkbox', icon: '☑' },
  { type: 'multi_select', label: 'Multi-Select', icon: '☷' },
  { type: 'yes_no', label: 'Yes / No Toggle', icon: '⇄' },
  { type: 'image_upload', label: 'Student Photo Upload', icon: '📷' },
  { type: 'file_upload', label: 'Document / Marksheet File', icon: '📎' },
  { type: 'signature', label: 'Digital Signature', icon: '✍' },
  { type: 'rating', label: 'Rating (1 to 5 Stars)', icon: '★' },
  { type: 'custom', label: 'Custom Field', icon: '⚙' },
];

export const FormBuilderModal: React.FC<FormBuilderModalProps> = ({
  isOpen,
  onClose,
  form,
  onSave,
  branches,
  classes,
  batches,
  instituteCode,
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'fields' | 'roll_config' | 'success_page' | 'preview'>('fields');
  const [previewDevice, setPreviewDevice] = useState<'mobile' | 'desktop'>('desktop');
  const [isSaving, setIsSaving] = useState(false);

  // Form State
  const [title, setTitle] = useState(form?.title || 'New Student Admission Form 2026');
  const [slug, setSlug] = useState(form?.slug || `${instituteCode}-ADM-${Date.now().toString(36).toUpperCase()}`);
  const [description, setDescription] = useState(form?.description || 'Please fill in student and parent details accurately.');
  const [branchId, setBranchId] = useState(form?.branchId || branches[0]?.id || '');
  const [classId, setClassId] = useState(form?.classId || classes[0]?.id || '');
  const [batchId, setBatchId] = useState(form?.batchId || batches[0]?.id || '');
  const [status, setStatus] = useState<'draft' | 'published' | 'closed'>(form?.status || 'published');
  const [maxSubmissions, setMaxSubmissions] = useState<number | undefined>(form?.maxSubmissions);

  // Sections & Fields
  const [sections, setSections] = useState<FormSection[]>(
    form?.sections || [
      { id: 'sec-personal', title: 'Personal Information', description: 'Student profile & contact', order: 1 },
      { id: 'sec-parent', title: 'Parent Information', description: 'Guardian details & emergency contact', order: 2 },
      { id: 'sec-academic', title: 'Academic & Previous Marks', description: 'School background and goals', order: 3 },
    ]
  );

  const [fields, setFields] = useState<FormField[]>(
    form?.fields || [
      { id: 'fld-name', type: 'text', label: 'Student Full Name', placeholder: 'Enter complete legal name', required: true, order: 1, sectionId: 'sec-personal' },
      { id: 'fld-gender', type: 'radio', label: 'Gender', options: ['Male', 'Female', 'Other'], required: true, order: 2, sectionId: 'sec-personal' },
      { id: 'fld-dob', type: 'date', label: 'Date of Birth', required: true, order: 3, sectionId: 'sec-personal' },
      { id: 'fld-phone', type: 'phone', label: 'Student WhatsApp Mobile', placeholder: '10 digit mobile number', required: true, order: 4, sectionId: 'sec-personal' },
      { id: 'fld-email', type: 'email', label: 'Student Email Address', placeholder: 'student@example.com', required: false, order: 5, sectionId: 'sec-personal' },
      { id: 'fld-address', type: 'textarea', label: 'Residential Address', placeholder: 'Complete address with PIN', required: true, order: 6, sectionId: 'sec-personal' },

      { id: 'fld-father', type: 'text', label: 'Father / Guardian Name', placeholder: 'Guardian full name', required: true, order: 7, sectionId: 'sec-parent' },
      { id: 'fld-parent-phone', type: 'phone', label: 'Parent Calling Mobile', placeholder: 'Parent mobile number', required: true, order: 8, sectionId: 'sec-parent' },
      { id: 'fld-parent-occ', type: 'text', label: 'Parent Occupation', placeholder: 'e.g. Service / Business', required: false, order: 9, sectionId: 'sec-parent' },

      { id: 'fld-school-student', type: 'yes_no', label: 'Are you currently attending school?', defaultValue: 'Yes', required: true, order: 10, sectionId: 'sec-academic' },
      { id: 'fld-school-name', type: 'text', label: 'Current School Name', placeholder: 'School name', required: true, order: 11, sectionId: 'sec-academic', condition: { dependsOnFieldId: 'fld-school-student', operator: 'equals', value: 'Yes' } },
      { id: 'fld-marks', type: 'number', label: 'Previous Mathematics Marks (%)', placeholder: 'e.g. 90', required: false, order: 12, sectionId: 'sec-academic', condition: { dependsOnFieldId: 'fld-school-student', operator: 'equals', value: 'Yes' } },
    ]
  );

  // Roll Number Config
  const [rollPrefix, setRollPrefix] = useState(form?.rollNumberConfig?.prefix || `${instituteCode}-2026-`);
  const [rollStart, setRollStart] = useState(form?.rollNumberConfig?.startingNumber || 1);
  const [rollLength, setRollLength] = useState(form?.rollNumberConfig?.length || 3);
  const [rollScope, setRollScope] = useState<'institute' | 'branch' | 'class' | 'batch' | 'form'>(
    form?.rollNumberConfig?.resetScope || 'class'
  );

  // Success Config
  const [successTitle, setSuccessTitle] = useState(form?.successConfig?.title || 'Admission Submitted Successfully!');
  const [successMessage, setSuccessMessage] = useState(
    form?.successConfig?.message || 'Your enrollment has been recorded. Please save your official admission slip below.'
  );
  const [showRollNo, setShowRollNo] = useState(form?.successConfig?.showRollNo ?? true);
  const [showStudentId, setShowStudentId] = useState(form?.successConfig?.showStudentId ?? true);
  const [showPdfDownload, setShowPdfDownload] = useState(form?.successConfig?.showPdfDownload ?? true);
  const [instructions, setInstructions] = useState(
    form?.successConfig?.instructions || 'Please bring a printed copy of this admission slip to your first class.'
  );

  // Field editing modal / inline state
  const [selectedFieldId, setSelectedFieldId] = useState<string | null>(fields[0]?.id || null);

  const selectedField = fields.find((f) => f.id === selectedFieldId);

  // Handlers
  const handleAddField = (type: FormFieldType) => {
    const newFieldId = `fld-${Date.now().toString(36)}`;
    const newField: FormField = {
      id: newFieldId,
      type,
      label: `New ${type.replace('_', ' ').toUpperCase()} Field`,
      placeholder: 'Enter response...',
      required: false,
      order: fields.length + 1,
      sectionId: sections[0]?.id || 'sec-personal',
      options: ['dropdown', 'radio', 'checkbox', 'multi_select'].includes(type) ? ['Option 1', 'Option 2', 'Option 3'] : undefined,
    };
    setFields([...fields, newField]);
    setSelectedFieldId(newFieldId);
  };

  const handleUpdateField = (id: string, updates: Partial<FormField>) => {
    setFields(fields.map((f) => (f.id === id ? { ...f, ...updates } : f)));
  };

  const handleDeleteField = (id: string) => {
    const remaining = fields.filter((f) => f.id !== id);
    setFields(remaining);
    if (selectedFieldId === id) {
      setSelectedFieldId(remaining[0]?.id || null);
    }
  };

  const handleDuplicateField = (field: FormField) => {
    const newField: FormField = {
      ...field,
      id: `fld-${Date.now().toString(36)}`,
      label: `${field.label} (Copy)`,
      order: fields.length + 1,
    };
    setFields([...fields, newField]);
    setSelectedFieldId(newField.id);
  };

  const handleMoveField = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === fields.length - 1) return;
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const reordered = [...fields];
    const temp = reordered[index];
    reordered[index] = reordered[targetIdx];
    reordered[targetIdx] = temp;
    // update order property
    reordered.forEach((f, idx) => (f.order = idx + 1));
    setFields(reordered);
  };

  const handleSaveForm = async () => {
    setIsSaving(true);
    try {
      await onSave({
        title,
        slug: slug.toUpperCase().trim().replace(/[^A-Z0-9_-]/g, '-'),
        description,
        branchId,
        classId,
        batchId,
        status,
        maxSubmissions: maxSubmissions ? Number(maxSubmissions) : undefined,
        sections,
        fields,
        rollNumberConfig: {
          prefix: rollPrefix,
          startingNumber: Number(rollStart),
          length: Number(rollLength),
          resetScope: rollScope,
        },
        successConfig: {
          title: successTitle,
          message: successMessage,
          showRollNo,
          showStudentId,
          showPdfDownload,
          showPrint: true,
          instructions,
        },
      });
      onClose();
    } catch (err: any) {
      alert(`Failed to save form: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-2 sm:p-4">
      <div className="flex h-[94vh] w-full max-w-6xl flex-col rounded-2xl border border-slate-200 bg-white shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-5 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 font-bold text-white shadow-xs">
              <Layers className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                {form ? 'Edit Admission Form' : 'Create New Admission Form'}
              </h2>
              <p className="text-[11px] text-slate-500">
                Slug: <span className="font-mono text-blue-600 font-semibold">/admission/{slug}</span>
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 rounded-xl bg-slate-200/80 p-1 text-xs font-semibold">
            <button
              onClick={() => setActiveTab('fields')}
              className={`rounded-lg px-3 py-1 transition ${
                activeTab === 'fields' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Fields & Logic ({fields.length})
            </button>
            <button
              onClick={() => setActiveTab('roll_config')}
              className={`rounded-lg px-3 py-1 transition ${
                activeTab === 'roll_config' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Roll Number Rule
            </button>
            <button
              onClick={() => setActiveTab('success_page')}
              className={`rounded-lg px-3 py-1 transition ${
                activeTab === 'success_page' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Success Page
            </button>
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-1.5 rounded-lg px-3 py-1 transition ${
                activeTab === 'preview' ? 'bg-blue-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="h-3.5 w-3.5" />
              <span>Live Preview</span>
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveForm}
              disabled={isSaving}
              className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs transition hover:bg-blue-700 disabled:opacity-50"
            >
              <Save className="h-3.5 w-3.5" />
              <span>{isSaving ? 'Saving...' : 'Save & Publish'}</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden">
          {activeTab === 'fields' && (
            <div className="flex h-full divide-x divide-slate-200">
              {/* Left Column: Form Settings & Add Field Palette */}
              <div className="w-64 overflow-y-auto p-4 bg-slate-50/50 space-y-5 shrink-0">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Form Details</h3>
                  <div className="space-y-2.5">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600">Form Title</label>
                      <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600">Public URL Slug</label>
                      <input
                        type="text"
                        value={slug}
                        onChange={(e) => setSlug(e.target.value.toUpperCase())}
                        className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-blue-600 outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600">Target Class</label>
                      <select
                        value={classId}
                        onChange={(e) => setClassId(e.target.value)}
                        className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 outline-none"
                      >
                        {classes.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-600">Status</label>
                      <select
                        value={status}
                        onChange={(e) => setStatus(e.target.value as any)}
                        className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 outline-none"
                      >
                        <option value="published">Published (Open for admissions)</option>
                        <option value="draft">Draft (Private preview only)</option>
                        <option value="closed">Closed (Expired)</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Click to Add Field
                  </h3>
                  <div className="grid grid-cols-1 gap-1.5">
                    {FIELD_TYPES.map((ft) => (
                      <button
                        key={ft.type}
                        onClick={() => handleAddField(ft.type)}
                        className="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-left font-medium text-slate-700 transition hover:border-blue-400 hover:bg-blue-50/50 hover:text-blue-700"
                      >
                        <span className="flex items-center gap-2">
                          <span className="flex h-5 w-5 items-center justify-center rounded bg-slate-100 text-[10px] font-bold text-slate-600">
                            {ft.icon}
                          </span>
                          <span className="truncate">{ft.label}</span>
                        </span>
                        <Plus className="h-3 w-3 text-slate-400" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Middle Column: Fields List & Drag Reorder */}
              <div className="flex-1 overflow-y-auto p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-800">Form Structure ({fields.length} Fields)</h3>
                  <span className="text-xs text-slate-400">Click any field to configure validation & conditional logic</span>
                </div>

                <div className="space-y-2">
                  {fields.map((field, idx) => {
                    const isSelected = field.id === selectedFieldId;
                    const hasCondition = !!field.condition;

                    return (
                      <div
                        key={field.id}
                        onClick={() => setSelectedFieldId(field.id)}
                        className={`group flex items-center justify-between rounded-xl border p-3 cursor-pointer transition ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50/40 ring-1 ring-blue-600'
                            : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex flex-col items-center">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveField(idx, 'up');
                              }}
                              disabled={idx === 0}
                              className="text-slate-300 hover:text-slate-700 disabled:opacity-20"
                            >
                              <MoveUp className="h-3.5 w-3.5" />
                            </button>
                            <span className="text-[10px] font-bold text-slate-400">{idx + 1}</span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleMoveField(idx, 'down');
                              }}
                              disabled={idx === fields.length - 1}
                              className="text-slate-300 hover:text-slate-700 disabled:opacity-20"
                            >
                              <MoveDown className="h-3.5 w-3.5" />
                            </button>
                          </div>

                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-bold text-slate-800">{field.label}</span>
                              {field.required && (
                                <span className="rounded bg-rose-50 px-1 py-0.2 text-[9px] font-bold text-rose-600">
                                  REQUIRED
                                </span>
                              )}
                              {hasCondition && (
                                <span className="rounded bg-amber-50 px-1 py-0.2 text-[9px] font-bold text-amber-700">
                                  CONDITIONAL
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
                              <span className="capitalize font-medium text-slate-500">{field.type.replace('_', ' ')}</span>
                              {field.placeholder && <span>• "{field.placeholder}"</span>}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDuplicateField(field);
                            }}
                            title="Duplicate Field"
                            className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
                          >
                            <Copy className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteField(field.id);
                            }}
                            title="Delete Field"
                            className="rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Column: Selected Field Inspector & Conditional Logic */}
              <div className="w-80 overflow-y-auto p-4 bg-slate-50/50 space-y-4 shrink-0">
                {selectedField ? (
                  <>
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Field Inspector</h3>
                        <span className="rounded bg-blue-100 px-1.5 py-0.5 text-[10px] font-bold text-blue-800">
                          {selectedField.type.replace('_', ' ').toUpperCase()}
                        </span>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <label className="text-[11px] font-semibold text-slate-700">Label Name</label>
                          <input
                            type="text"
                            value={selectedField.label}
                            onChange={(e) => handleUpdateField(selectedField.id, { label: e.target.value })}
                            className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                          />
                        </div>

                        <div>
                          <label className="text-[11px] font-semibold text-slate-700">Placeholder</label>
                          <input
                            type="text"
                            value={selectedField.placeholder || ''}
                            onChange={(e) => handleUpdateField(selectedField.id, { placeholder: e.target.value })}
                            className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                          />
                        </div>

                        <div>
                          <label className="text-[11px] font-semibold text-slate-700">Help / Subtitle Text</label>
                          <input
                            type="text"
                            value={selectedField.helpText || ''}
                            onChange={(e) => handleUpdateField(selectedField.id, { helpText: e.target.value })}
                            placeholder="Additional instructions for student"
                            className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 outline-none focus:border-blue-500"
                          />
                        </div>

                        <div className="flex items-center justify-between rounded-lg border border-slate-200 bg-white p-2.5">
                          <span className="text-xs font-medium text-slate-700">Mandatory Field</span>
                          <input
                            type="checkbox"
                            checked={selectedField.required}
                            onChange={(e) => handleUpdateField(selectedField.id, { required: e.target.checked })}
                            className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                          />
                        </div>

                        {/* Options for dropdown, radio, checkbox */}
                        {['dropdown', 'radio', 'checkbox', 'multi_select'].includes(selectedField.type) && (
                          <div>
                            <label className="text-[11px] font-semibold text-slate-700">Choices (one per line)</label>
                            <textarea
                              rows={4}
                              value={(selectedField.options || []).join('\n')}
                              onChange={(e) =>
                                handleUpdateField(selectedField.id, {
                                  options: e.target.value.split('\n').filter((x) => x.trim()),
                                })
                              }
                              className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white p-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                            />
                          </div>
                        )}

                        {/* ADVANCED CONDITIONAL LOGIC */}
                        <div className="rounded-xl border border-amber-200 bg-amber-50/50 p-3">
                          <div className="flex items-center gap-1.5 text-amber-900 font-bold text-xs mb-2">
                            <Sliders className="h-3.5 w-3.5 text-amber-700" />
                            <span>Conditional Display Logic</span>
                          </div>
                          <p className="text-[11px] text-slate-600 mb-2.5">
                            Show this field only when a previous answer matches:
                          </p>

                          <div className="space-y-2">
                            <div>
                              <label className="text-[10px] font-bold uppercase text-slate-500">Depends On Field</label>
                              <select
                                value={selectedField.condition?.dependsOnFieldId || ''}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (!val) {
                                    handleUpdateField(selectedField.id, { condition: undefined });
                                  } else {
                                    handleUpdateField(selectedField.id, {
                                      condition: {
                                        dependsOnFieldId: val,
                                        operator: 'equals',
                                        value: 'Yes',
                                      },
                                    });
                                  }
                                }}
                                className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs outline-none"
                              >
                                <option value="">Always Visible (No Condition)</option>
                                {fields
                                  .filter((f) => f.id !== selectedField.id)
                                  .map((f) => (
                                    <option key={f.id} value={f.id}>
                                      {f.label} ({f.type})
                                    </option>
                                  ))}
                              </select>
                            </div>

                            {selectedField.condition && (
                              <div>
                                <label className="text-[10px] font-bold uppercase text-slate-500">When Answer Equals</label>
                                <input
                                  type="text"
                                  value={selectedField.condition.value}
                                  onChange={(e) =>
                                    handleUpdateField(selectedField.id, {
                                      condition: {
                                        ...selectedField.condition!,
                                        value: e.target.value,
                                      },
                                    })
                                  }
                                  placeholder="e.g. Yes"
                                  className="mt-0.5 w-full rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs outline-none focus:border-amber-500"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                ) : (
                  <p className="text-xs text-slate-400 text-center py-10">Select a field to inspect and edit</p>
                )}
              </div>
            </div>
          )}

          {/* Roll Number Rules Tab */}
          {activeTab === 'roll_config' && (
            <div className="max-w-2xl mx-auto p-6 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900">Automatic Sequential Roll Number Configuration</h3>
                <p className="text-xs text-slate-500">
                  Configure how student roll numbers are generated automatically upon successful submission.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700">Custom Prefix</label>
                    <input
                      type="text"
                      value={rollPrefix}
                      onChange={(e) => setRollPrefix(e.target.value)}
                      placeholder="e.g. AKM-2026-"
                      className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 font-mono text-xs text-slate-800 outline-none focus:border-blue-500"
                    />
                    <span className="text-[10px] text-slate-400">Leave blank for plain numbers (e.g. 001)</span>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700">Padding Length</label>
                    <input
                      type="number"
                      min={1}
                      max={6}
                      value={rollLength}
                      onChange={(e) => setRollLength(Number(e.target.value))}
                      className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                    />
                    <span className="text-[10px] text-slate-400">e.g. length 3 generates 001, 002...</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-slate-700">Starting Number</label>
                    <input
                      type="number"
                      min={1}
                      value={rollStart}
                      onChange={(e) => setRollStart(Number(e.target.value))}
                      className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700">Reset Scope</label>
                    <select
                      value={rollScope}
                      onChange={(e) => setRollScope(e.target.value as any)}
                      className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
                    >
                      <option value="class">Class-Wise (Class IX: 001..., Class XII: 001...)</option>
                      <option value="batch">Batch-Wise (Separate 001 per batch)</option>
                      <option value="branch">Branch-Wise</option>
                      <option value="institute">Institute-Wide (Global continuous)</option>
                      <option value="form">Form-Wise</option>
                    </select>
                  </div>
                </div>

                {/* Live Preview of Roll Number */}
                <div className="rounded-xl bg-blue-50/70 border border-blue-100 p-4">
                  <p className="text-xs font-bold text-blue-900">Next Generated Roll Number Sample:</p>
                  <p className="text-xl font-mono font-extrabold text-blue-700 mt-1">
                    {rollPrefix}
                    {String(rollStart).padStart(rollLength, '0')}
                  </p>
                  <p className="text-[11px] text-blue-600 mt-1">
                    Guaranteed unique and thread-safe. Concurrent submissions will never collide.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Success Page Tab */}
          {activeTab === 'success_page' && (
            <div className="max-w-2xl mx-auto p-6 space-y-6">
              <div>
                <h3 className="text-base font-bold text-slate-900">Post-Submission Success Page</h3>
                <p className="text-xs text-slate-500">Customize what the student sees after submitting their application.</p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-700">Success Header Title</label>
                  <input
                    type="text"
                    value={successTitle}
                    onChange={(e) => setSuccessTitle(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700">Congratulatory Message</label>
                  <textarea
                    rows={2}
                    value={successMessage}
                    onChange={(e) => setSuccessMessage(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700">Important Instructions for Next Step</label>
                  <textarea
                    rows={2}
                    value={instructions}
                    onChange={(e) => setInstructions(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
                  />
                </div>

                <div className="space-y-2 border-t border-slate-100 pt-3">
                  <label className="flex items-center gap-2 text-xs text-slate-700">
                    <input
                      type="checkbox"
                      checked={showRollNo}
                      onChange={(e) => setShowRollNo(e.target.checked)}
                      className="rounded text-blue-600"
                    />
                    <span>Show Assigned Roll Number on Success Screen</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700">
                    <input
                      type="checkbox"
                      checked={showStudentId}
                      onChange={(e) => setShowStudentId(e.target.checked)}
                      className="rounded text-blue-600"
                    />
                    <span>Show Permanent Student ID</span>
                  </label>
                  <label className="flex items-center gap-2 text-xs text-slate-700">
                    <input
                      type="checkbox"
                      checked={showPdfDownload}
                      onChange={(e) => setShowPdfDownload(e.target.checked)}
                      className="rounded text-blue-600"
                    />
                    <span>Provide One-Click Download Official Admission Slip (PDF)</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Live Preview Tab */}
          {activeTab === 'preview' && (
            <div className="h-full flex flex-col bg-slate-100 p-4">
              <div className="flex items-center justify-between mb-3 px-4">
                <span className="text-xs font-bold text-slate-600">Student View Preview</span>
                <div className="flex items-center gap-1 rounded-lg bg-white p-1 border border-slate-200">
                  <button
                    onClick={() => setPreviewDevice('desktop')}
                    className={`flex items-center gap-1 rounded px-2 py-1 text-[11px] font-semibold ${
                      previewDevice === 'desktop' ? 'bg-slate-800 text-white' : 'text-slate-600'
                    }`}
                  >
                    <Monitor className="h-3.5 w-3.5" />
                    <span>Desktop</span>
                  </button>
                  <button
                    onClick={() => setPreviewDevice('mobile')}
                    className={`flex items-center gap-1 rounded px-2 py-1 text-[11px] font-semibold ${
                      previewDevice === 'mobile' ? 'bg-slate-800 text-white' : 'text-slate-600'
                    }`}
                  >
                    <Smartphone className="h-3.5 w-3.5" />
                    <span>Mobile (375px)</span>
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto flex items-center justify-center">
                <div
                  className={`bg-white rounded-2xl shadow-xl border border-slate-200 transition-all p-6 overflow-y-auto max-h-[75vh] ${
                    previewDevice === 'mobile' ? 'w-[380px]' : 'w-full max-w-3xl'
                  }`}
                >
                  <div className="border-b border-slate-100 pb-4 mb-5">
                    <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-bold text-blue-700">
                      OFFICIAL ADMISSION FORM
                    </span>
                    <h2 className="text-base font-bold text-slate-900 mt-1">{title}</h2>
                    <p className="text-xs text-slate-500 mt-0.5">{description}</p>
                  </div>

                  <div className="space-y-4">
                    {fields.map((field) => (
                      <div key={field.id} className="space-y-1">
                        <label className="text-xs font-bold text-slate-700">
                          {field.label} {field.required && <span className="text-rose-500">*</span>}
                        </label>
                        {field.type === 'textarea' ? (
                          <textarea
                            disabled
                            placeholder={field.placeholder}
                            rows={2}
                            className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2 text-xs"
                          />
                        ) : field.type === 'dropdown' ? (
                          <select disabled className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2 text-xs">
                            <option>Select an option</option>
                            {(field.options || []).map((o) => (
                              <option key={o}>{o}</option>
                            ))}
                          </select>
                        ) : field.type === 'radio' ? (
                          <div className="flex gap-4 pt-1">
                            {(field.options || []).map((o) => (
                              <label key={o} className="flex items-center gap-1.5 text-xs text-slate-600">
                                <input type="radio" disabled name={field.id} />
                                <span>{o}</span>
                              </label>
                            ))}
                          </div>
                        ) : field.type === 'yes_no' ? (
                          <div className="flex gap-3 pt-1">
                            {['Yes', 'No'].map((o) => (
                              <label key={o} className="flex items-center gap-1.5 text-xs text-slate-600">
                                <input type="radio" disabled name={field.id} defaultChecked={o === 'Yes'} />
                                <span>{o}</span>
                              </label>
                            ))}
                          </div>
                        ) : (
                          <input
                            disabled
                            type={field.type === 'number' ? 'number' : 'text'}
                            placeholder={field.placeholder}
                            className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
                          />
                        )}
                        {field.helpText && <p className="text-[10px] text-slate-400">{field.helpText}</p>}
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 border-t border-slate-100 pt-4">
                    <button
                      disabled
                      className="w-full rounded-xl bg-blue-600 py-2.5 text-xs font-bold text-white shadow-xs"
                    >
                      Submit Student Admission Application
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
