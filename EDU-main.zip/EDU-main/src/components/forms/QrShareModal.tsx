import React, { useState, useEffect } from 'react';
import { X, Copy, Check, Download, Printer, Share2, ExternalLink, QrCode } from 'lucide-react';
import { AdmissionForm, Institute } from '../../types';
import { generateQrCodeUrl } from '../../utils/qrHelper';

interface QrShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  form: AdmissionForm | null;
  institute: Institute | null;
  onOpenPublicForm: (slug: string) => void;
}

export const QrShareModal: React.FC<QrShareModalProps> = ({
  isOpen,
  onClose,
  form,
  institute,
  onOpenPublicForm,
}) => {
  if (!isOpen || !form) return null;

  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copied, setCopied] = useState(false);

  // Construct absolute URL
  const origin = window.location.origin;
  const publicUrl = `${origin}/admission/${form.slug}`;

  useEffect(() => {
    generateQrCodeUrl(publicUrl).then((url) => setQrDataUrl(url));
  }, [publicUrl]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsAppShare = () => {
    const text = encodeURIComponent(
      `*${institute?.name || 'Coaching Institute'}* - Admissions Open 2026-27!\n\n` +
      `Program: *${form.title}*\n` +
      `Director/Faculty: ${institute?.teacherName || ''}\n\n` +
      `👉 Click here to fill online student admission form:\n${publicUrl}\n\n` +
      `For queries WhatsApp: ${institute?.whatsapp || institute?.phone || ''}`
    );
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleTelegramShare = () => {
    const text = encodeURIComponent(
      `*${institute?.name || 'Coaching'}* Admissions Open!\n${form.title}\nFill form here: ${publicUrl}`
    );
    window.open(`https://t.me/share/url?url=${encodeURIComponent(publicUrl)}&text=${text}`, '_blank');
  };

  const handleDownloadQr = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `${form.slug}_QR_Code.png`;
    a.click();
  };

  const handlePrintPoster = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl overflow-hidden ring-1 ring-black/5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
              <QrCode className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Share Admission Form</h3>
              <p className="text-[11px] text-slate-500 font-mono">/admission/{form.slug}</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1 text-slate-400 hover:text-slate-600">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* QR Code & Poster Section */}
        <div id="printable-content" className="py-4 text-center">
          <div className="mx-auto flex h-52 w-52 items-center justify-center rounded-2xl border border-slate-200 bg-white p-3 shadow-xs">
            {qrDataUrl ? (
              <img src={qrDataUrl} alt="Form QR Code" className="h-full w-full object-contain" />
            ) : (
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-blue-600 border-t-transparent" />
            )}
          </div>
          <p className="mt-2 text-xs font-bold text-slate-800">{form.title}</p>
          <p className="text-[11px] text-slate-500">
            Scan with any phone camera or Google Lens to open admission form
          </p>
        </div>

        {/* Copy Link input */}
        <div className="mt-1 flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 p-1.5">
          <input
            type="text"
            readOnly
            value={publicUrl}
            className="flex-1 bg-transparent px-2 text-xs font-medium text-slate-700 outline-none"
          />
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1 rounded-lg bg-white px-2.5 py-1 text-xs font-semibold text-slate-800 shadow-xs border border-slate-200 hover:bg-slate-50"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        </div>

        {/* Social Share Buttons */}
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            onClick={handleWhatsAppShare}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white shadow-xs hover:bg-emerald-700"
          >
            <Share2 className="h-3.5 w-3.5" />
            <span>WhatsApp Share</span>
          </button>
          <button
            onClick={handleTelegramShare}
            className="flex items-center justify-center gap-1.5 rounded-xl bg-sky-500 px-3 py-2 text-xs font-bold text-white shadow-xs hover:bg-sky-600"
          >
            <Share2 className="h-3.5 w-3.5" />
            <span>Telegram Share</span>
          </button>
        </div>

        {/* Secondary download / print buttons */}
        <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-3">
          <button
            onClick={handleDownloadQr}
            className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download PNG</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onOpenPublicForm(form.slug);
            }}
            className="flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700"
          >
            <ExternalLink className="h-3.5 w-3.5" />
            <span>Open in Portal</span>
          </button>
        </div>
      </div>
    </div>
  );
};
