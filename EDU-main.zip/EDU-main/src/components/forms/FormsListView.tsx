import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Plus,
  QrCode,
  Edit,
  Copy,
  Trash2,
  Eye,
  ExternalLink,
  CheckCircle2,
  Clock,
  Sparkles,
  TrendingUp,
  BarChart2,
  Share2,
} from 'lucide-react';
import { AdmissionForm, Institute, Branch, ClassItem, Batch } from '../../types';

interface FormsListViewProps {
  forms: AdmissionForm[];
  institute: Institute | null;
  branches: Branch[];
  classes: ClassItem[];
  batches: Batch[];
  onCreateNewForm: () => void;
  onEditForm: (form: AdmissionForm) => void;
  onDuplicateForm: (formId: string) => void;
  onDeleteForm: (formId: string) => void;
  onToggleStatus: (form: AdmissionForm) => void;
  onOpenQrModal: (form: AdmissionForm) => void;
  onOpenPublicForm: (slug: string) => void;
}

export const FormsListView: React.FC<FormsListViewProps> = ({
  forms,
  institute,
  branches,
  classes,
  batches,
  onCreateNewForm,
  onEditForm,
  onDuplicateForm,
  onDeleteForm,
  onToggleStatus,
  onOpenQrModal,
  onOpenPublicForm,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredForms = forms.filter((f) =>
    f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.slug.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalViews = forms.reduce((acc, f) => acc + (f.viewsCount || 0), 0);
  const totalSubmissions = forms.reduce((acc, f) => acc + (f.submissionsCount || 0), 0);
  const avgConversion = totalViews > 0 ? Math.round((totalSubmissions / totalViews) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Custom Admission Forms</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Build dynamic online admission forms with conditional fields, automatic roll numbers, and QR codes.
          </p>
        </div>

        <button
          id="create-form-btn"
          onClick={onCreateNewForm}
          className="flex items-center gap-1.5 rounded-xl bg-blue-600 px-4 py-2 text-xs font-bold text-white shadow-xs transition hover:bg-blue-700"
        >
          <Plus className="h-4 w-4" />
          <span>Create Admission Form</span>
        </button>
      </div>

      {/* Analytics Counter Row */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Active Forms</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{forms.length}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Total Form Views</p>
          <p className="text-xl font-bold text-slate-900 mt-1">{totalViews}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Total Submissions</p>
          <p className="text-xl font-bold text-emerald-600 mt-1">{totalSubmissions}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs">
          <p className="text-xs font-medium text-slate-500">Overall Conversion</p>
          <p className="text-xl font-bold text-indigo-600 mt-1">{avgConversion}%</p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex items-center gap-3">
        <input
          type="text"
          placeholder="Filter admission forms by title or slug..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full max-w-sm rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
        />
      </div>

      {/* Forms Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredForms.map((form) => {
          const classItem = classes.find((c) => c.id === form.classId);
          const branch = branches.find((b) => b.id === form.branchId);
          const conversionRate = form.viewsCount > 0 ? Math.round((form.submissionsCount / form.viewsCount) * 100) : 0;

          return (
            <div
              key={form.id}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-5 shadow-xs transition hover:border-slate-300 hover:shadow-md"
            >
              <div>
                {/* Status & Badges */}
                <div className="flex items-center justify-between">
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                      form.status === 'published'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200/60'
                        : form.status === 'draft'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200/60'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {form.status}
                  </span>

                  <span className="text-[10px] text-slate-400 font-medium">
                    {form.fields?.length || 0} fields
                  </span>
                </div>

                {/* Form Title & Slug */}
                <h3 className="text-sm font-bold text-slate-900 mt-2 line-clamp-2">{form.title}</h3>
                <div className="mt-1 flex items-center gap-1 font-mono text-[11px] text-blue-600">
                  <span>/admission/{form.slug}</span>
                </div>

                <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-slate-700">{classItem?.name || 'Class'}</span>
                  <span>•</span>
                  <span>{branch?.name || 'Main Campus'}</span>
                </div>

                {/* Mini Stats Bar */}
                <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-slate-50 p-2.5 text-center">
                  <div>
                    <p className="text-[10px] uppercase font-bold text-slate-400">Views</p>
                    <p className="text-xs font-bold text-slate-800">{form.viewsCount}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-bold text-slate-400">Enrolled</p>
                    <p className="text-xs font-bold text-emerald-600">{form.submissionsCount}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-bold text-slate-400">Conv %</p>
                    <p className="text-xs font-bold text-indigo-600">{conversionRate}%</p>
                  </div>
                </div>

                {/* Roll number preview */}
                <div className="mt-3 rounded-lg bg-blue-50/50 p-2 text-[11px] text-slate-600">
                  Roll sequence: <span className="font-mono font-bold text-blue-700">{form.rollNumberConfig?.prefix || ''}001</span> ({form.rollNumberConfig?.resetScope || 'class'} scoped)
                </div>
              </div>

              {/* Action Buttons Footer */}
              <div className="mt-5 border-t border-slate-100 pt-3 flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onOpenQrModal(form)}
                    title="Share Link & QR Code"
                    className="flex items-center gap-1 rounded-lg bg-slate-100 px-2.5 py-1.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-200"
                  >
                    <QrCode className="h-3.5 w-3.5 text-slate-600" />
                    <span>Share / QR</span>
                  </button>
                  <button
                    onClick={() => onOpenPublicForm(form.slug)}
                    title="Open Live Student Admission Portal"
                    className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-blue-600"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </button>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onEditForm(form)}
                    title="Edit Form in Builder"
                    className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onDuplicateForm(form.id)}
                    title="Duplicate Form"
                    className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-800"
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onDeleteForm(form.id)}
                    title="Delete Form"
                    className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
