import React, { useState } from 'react';
import {
  Settings,
  Building2,
  FileText,
  Upload,
  Download,
  Save,
  Check,
  Sparkles,
  Shield,
  Smartphone,
  Phone,
  Mail,
  Home,
} from 'lucide-react';
import { Institute, Branch } from '../../types';

interface SettingsViewProps {
  institute: Institute | null;
  selectedBranch: Branch | undefined;
  onUpdateInstitute: (updates: Partial<Institute>) => Promise<void>;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  institute,
  selectedBranch,
  onUpdateInstitute,
}) => {
  const [name, setName] = useState(institute?.name || '');
  const [tagline, setTagline] = useState(institute?.tagline || '');
  const [teacherName, setTeacherName] = useState(institute?.teacherName || '');
  const [qualification, setQualification] = useState(institute?.teacherQualification || '');
  const [phone, setPhone] = useState(institute?.phone || '');
  const [whatsapp, setWhatsapp] = useState(institute?.whatsapp || '');
  const [email, setEmail] = useState(institute?.email || '');
  const [address, setAddress] = useState(institute?.address || '');
  const [logo, setLogo] = useState(institute?.logo || '');
  const [signature, setSignature] = useState(institute?.signature || '');

  // PDF Branding Config
  const [headerTitle, setHeaderTitle] = useState(institute?.pdfTemplateConfig?.headerTitle || institute?.name || '');
  const [subHeader, setSubHeader] = useState(institute?.pdfTemplateConfig?.subHeader || institute?.tagline || '');
  const [footerNote, setFooterNote] = useState(
    institute?.pdfTemplateConfig?.footerNote || 'This is an official system generated computerized record.'
  );

  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onUpdateInstitute({
        name,
        tagline,
        teacherName,
        teacherQualification: qualification,
        phone,
        whatsapp,
        email,
        address,
        logo,
        signature,
        pdfTemplateConfig: {
          headerTitle,
          subHeader,
          footerNote,
          primaryColor: '#2563EB',
          showLogo: true,
          showSignature: true,
        },
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      alert(`Failed to save settings: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  const handleBackupExport = () => {
    // Read directly or fetch
    fetch('/api/backup', { headers: { 'x-institute-id': institute?.id || 'inst-akm' } })
      .then((r) => r.json())
      .then((data) => {
        const jsonStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
        const downloadAnchor = document.createElement('a');
        downloadAnchor.setAttribute('href', jsonStr);
        downloadAnchor.setAttribute('download', `EduRecord_Backup_${new Date().toISOString().split('T')[0]}.json`);
        document.body.appendChild(downloadAnchor);
        downloadAnchor.click();
        downloadAnchor.remove();
      })
      .catch(() => alert('Backup ready to export.'));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">Institute & PDF Settings</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure institute profile, official stamp/signature, and printable PDF slip formatting.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleBackupExport}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-xs hover:bg-slate-50"
          >
            <Download className="h-3.5 w-3.5 text-slate-500" />
            <span>Export Full Backup (JSON)</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Profile Card */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900">Coaching Profile Details</h3>
            <p className="text-xs text-slate-400">Displayed on student admission slips, fee receipts, and portal</p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="text-xs font-semibold text-slate-700">Institute / Class Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700">Tagline / Motto</label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="text-xs font-semibold text-slate-700">Faculty / Director Name</label>
              <input
                type="text"
                required
                value={teacherName}
                onChange={(e) => setTeacherName(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700">Teacher Qualifications</label>
              <input
                type="text"
                value={qualification}
                onChange={(e) => setQualification(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label className="text-xs font-semibold text-slate-700">Office Contact Phone</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700">Official WhatsApp Helpline</label>
              <input
                type="text"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700">Main Campus Physical Address</label>
            <textarea
              rows={2}
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* PDF & Receipt Template Configuration */}
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-xs space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900">PDF Admission Slip & Receipt Header Config</h3>
            <p className="text-xs text-slate-400">Customized layout printed on all downloadable documents</p>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="text-xs font-semibold text-slate-700">Header Title on PDF</label>
              <input
                type="text"
                value={headerTitle}
                onChange={(e) => setHeaderTitle(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700">Sub-Header Line</label>
              <input
                type="text"
                value={subHeader}
                onChange={(e) => setSubHeader(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700">Official Disclaimer / Footer Note</label>
            <input
              type="text"
              value={footerNote}
              onChange={(e) => setFooterNote(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2 text-xs text-slate-800 outline-none"
            />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 rounded-2xl bg-blue-600 px-6 py-2.5 text-xs font-bold text-white shadow-md shadow-blue-600/20 hover:bg-blue-700 disabled:opacity-50"
          >
            {savedSuccess ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
            <span>{isSaving ? 'Saving Changes...' : savedSuccess ? 'Settings Saved!' : 'Save All Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
