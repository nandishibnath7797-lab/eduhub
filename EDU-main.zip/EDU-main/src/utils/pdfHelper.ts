import { jsPDF } from 'jspdf';
import { Student, Institute, Branch, ClassItem, Batch, FeePayment, FeeRecord } from '../types';

export const downloadStudentAdmissionPdf = (
  student: Student,
  institute: Institute,
  branch?: Branch,
  classItem?: ClassItem,
  batch?: Batch
) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const accentColor = institute.brandingColor || '#2563EB';

  // Top header colored bar
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, pageWidth, 6, 'F');

  // Institute Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(15, 23, 42);
  doc.text(institute.name.toUpperCase(), 14, 20);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(71, 85, 105);
  doc.text(`Director / Faculty: ${institute.teacherName || institute.directorName}`, 14, 26);
  doc.text(`Address: ${branch ? branch.address : institute.address}`, 14, 31);
  doc.text(`Contact: ${institute.phone}  |  WhatsApp: ${institute.whatsapp}  |  Email: ${institute.email}`, 14, 36);

  // Divider
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(14, 40, pageWidth - 14, 40);

  // Title Box
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(14, 44, pageWidth - 28, 12, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(30, 41, 59);
  doc.text('OFFICIAL STUDENT ADMISSION RECORD & ENROLLMENT CONFIRMATION', pageWidth / 2, 52, { align: 'center' });

  // Student Primary Badges (Roll No & ID)
  doc.setFillColor(239, 246, 255);
  doc.setDrawColor(191, 219, 254);
  doc.roundedRect(14, 60, 85, 22, 2, 2, 'FD');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('PERMANENT STUDENT ID', 18, 66);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(37, 99, 235);
  doc.text(student.id, 18, 76);

  doc.setFillColor(240, 253, 244);
  doc.setDrawColor(187, 247, 208);
  doc.roundedRect(105, 60, 85, 22, 2, 2, 'FD');
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('OFFICIAL ROLL NUMBER', 109, 66);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(22, 101, 52);
  doc.text(student.rollNumber, 109, 76);

  // Section 1: Academic & Enrollment Information
  let y = 92;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('1. ACADEMIC & ENROLLMENT DETAILS', 14, y);
  doc.line(14, y + 2, pageWidth - 14, y + 2);

  y += 9;
  doc.setFontSize(9);
  const addRow = (label: string, value: string, x1 = 14, x2 = 105) => {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(100, 116, 139);
    doc.text(label, x1, y);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(15, 23, 42);
    doc.text(value || 'N/A', x1 + 38, y);
  };

  addRow('Class / Standard:', classItem?.name || student.classId, 14);
  addRow('Assigned Batch:', batch?.name || student.batchId, 105);
  y += 7;
  addRow('Batch Timings:', batch?.timeSlot || 'Scheduled Weekly', 14);
  addRow('Branch Campus:', branch?.name || 'Main Campus', 105);
  y += 7;
  addRow('Admission Date:', student.admissionDate, 14);
  addRow('Enrollment Status:', student.status.toUpperCase(), 105);

  // Section 2: Student Personal Information
  y += 14;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('2. STUDENT PERSONAL INFORMATION', 14, y);
  doc.line(14, y + 2, pageWidth - 14, y + 2);

  y += 9;
  doc.setFontSize(9);
  addRow('Full Name:', student.name, 14);
  addRow('Gender & Blood:', `${student.gender}  |  Blood: ${student.bloodGroup || 'N/A'}`, 105);
  y += 7;
  addRow('Date of Birth:', student.dob, 14);
  addRow('Contact Mobile:', student.phone, 105);
  y += 7;
  addRow('Email Address:', student.email || 'N/A', 14);
  addRow('Current School:', student.currentSchool || student.previousSchool || 'N/A', 105);
  y += 7;
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('Residential Address:', 14, y);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(student.address, 52, y, { maxWidth: 140 });

  // Section 3: Parent / Guardian Information
  y += 15;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('3. PARENT / GUARDIAN INFORMATION', 14, y);
  doc.line(14, y + 2, pageWidth - 14, y + 2);

  y += 9;
  doc.setFontSize(9);
  addRow('Father / Guardian:', student.fatherName, 14);
  addRow('Mother Name:', student.motherName || 'N/A', 105);
  y += 7;
  addRow('Parent Mobile:', student.parentPhone, 14);
  addRow('Occupation:', student.parentOccupation || 'N/A', 105);

  // Section 4: Additional Information
  if (student.customData && Object.keys(student.customData).length > 0) {
    y += 14;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(30, 41, 59);
    doc.text('4. CUSTOM ADMISSION DETAILS', 14, y);
    doc.line(14, y + 2, pageWidth - 14, y + 2);

    y += 9;
    Object.entries(student.customData).slice(0, 4).forEach(([key, val]) => {
      const displayVal = Array.isArray(val) ? val.join(', ') : String(val);
      const cleanKey = key.replace(/^fld-/, '').replace(/-/g, ' ').toUpperCase();
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 116, 139);
      doc.text(`${cleanKey.slice(0, 22)}:`, 14, y);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(15, 23, 42);
      doc.text(displayVal || 'N/A', 60, y, { maxWidth: 130 });
      y += 6;
    });
  }

  // Watermark
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(32);
  doc.setTextColor(241, 245, 249);
  doc.text('OFFICIAL ADMISSION RECORD', pageWidth / 2, 175, { align: 'center', angle: 30 });

  // Signatures at bottom
  const bottomY = 250;
  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.4);

  doc.line(20, bottomY, 75, bottomY);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('Student / Parent Signature', 32, bottomY + 5);

  doc.line(pageWidth - 75, bottomY, pageWidth - 20, bottomY);
  doc.text('Authorized Institute Signature & Seal', pageWidth - 70, bottomY + 5);

  // Footer note
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `Generated via EduRecord SaaS on ${new Date().toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' })}. Verify credentials with ${institute.phone}.`,
    pageWidth / 2,
    285,
    { align: 'center' }
  );

  doc.save(`${student.rollNumber}_Admission_${student.name.replace(/\s+/g, '_')}.pdf`);
};

export const downloadFeeReceiptPdf = (
  payment: FeePayment,
  student: Student,
  feeRecord: FeeRecord,
  institute: Institute
) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a5',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // Header band
  doc.setFillColor(37, 99, 235);
  doc.rect(0, 0, pageWidth, 5, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text(institute.name, 12, 16);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`${institute.address} | Tel: ${institute.phone}`, 12, 21);

  doc.setDrawColor(226, 232, 240);
  doc.line(12, 25, pageWidth - 12, 25);

  // Title & Receipt No
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 41, 59);
  doc.text('FEE PAYMENT RECEIPT', 12, 32);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Receipt No: ${payment.receiptNumber}`, pageWidth - 12, 32, { align: 'right' });
  doc.text(`Date: ${payment.paymentDate}`, pageWidth - 12, 37, { align: 'right' });

  // Student Details Box
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(12, 42, pageWidth - 24, 26, 2, 2, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Student Name:', 16, 49);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(student.name, 45, 49);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('Roll Number:', 16, 56);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(student.rollNumber, 45, 56);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('Student ID:', 16, 63);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(student.id, 45, 63);

  // Payment Breakdown
  let y = 78;
  doc.setFillColor(241, 245, 249);
  doc.rect(12, y, pageWidth - 24, 7, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);
  doc.text('DESCRIPTION', 16, y + 5);
  doc.text('AMOUNT (₹)', pageWidth - 16, y + 5, { align: 'right' });

  y += 13;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(15, 23, 42);
  doc.text(feeRecord.title || 'Tuition Fee Payment', 16, y);
  doc.text(`₹${payment.amount.toLocaleString('en-IN')}`, pageWidth - 16, y, { align: 'right' });

  y += 10;
  doc.line(12, y, pageWidth - 12, y);

  y += 6;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('Total Paid:', 16, y);
  doc.setTextColor(22, 101, 52);
  doc.text(`₹${payment.amount.toLocaleString('en-IN')}`, pageWidth - 16, y, { align: 'right' });

  y += 7;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`Payment Method: ${payment.paymentMethod.toUpperCase()}`, 16, y);
  if (payment.transactionRef) {
    y += 5;
    doc.text(`Ref / Txn No: ${payment.transactionRef}`, 16, y);
  }

  // Signature
  y = 175;
  doc.line(pageWidth - 60, y, pageWidth - 12, y);
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text('Authorized Signature & Seal', pageWidth - 55, y + 4);

  doc.save(`${payment.receiptNumber}.pdf`);
};
