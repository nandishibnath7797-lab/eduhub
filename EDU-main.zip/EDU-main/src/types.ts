export type UserRole = 'super_admin' | 'institute_admin' | 'teacher' | 'student';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  instituteId: string;
  branchId?: string;
  avatar?: string;
  phone?: string;
}

export interface Institute {
  id: string;
  name: string;
  code: string;
  logo: string;
  teacherName: string;
  directorName: string;
  address: string;
  phone: string;
  whatsapp: string;
  email: string;
  website: string;
  socialLinks?: {
    facebook?: string;
    instagram?: string;
    youtube?: string;
  };
  brandingColor: string;
  currency: string;
  timezone: string;
  tagline?: string;
  teacherQualification?: string;
  signature?: string;
  pdfTemplateConfig?: any;
  createdAt: string;
}

export interface Branch {
  id: string;
  instituteId: string;
  name: string;
  code: string;
  city: string;
  address: string;
  phone: string;
  inchargeName: string;
  isMain?: boolean;
}

export interface AcademicSession {
  id: string;
  instituteId: string;
  name: string; // e.g. "2026-2027"
  isCurrent: boolean;
  startDate: string;
  endDate: string;
}

export interface ClassItem {
  id: string;
  instituteId: string;
  branchId?: string;
  name: string; // e.g. "Class IX", "Class X", "Class XI", "Class XII"
  code: string;
  description?: string;
}

export interface Batch {
  id: string;
  instituteId: string;
  branchId: string;
  classId: string;
  name: string; // e.g. "Morning Batch A"
  timeSlot: string; // e.g. "07:00 AM - 08:30 AM"
  days: string[]; // e.g. ["Mon", "Wed", "Fri"]
  maxSeats: number;
  enrolledSeats?: number;
  teacherId?: string;
  monthlyFee: number;
}

export interface Teacher {
  id: string;
  instituteId: string;
  name: string;
  phone: string;
  email: string;
  subject: string;
  photo?: string;
  branchIds: string[];
  assignedClassIds: string[];
  assignedBatchIds: string[];
  permissions: {
    canViewStudents: boolean;
    canEditStudents: boolean;
    canDeleteStudents: boolean;
    canMarkAttendance: boolean;
    canManageFees: boolean;
    canViewReports: boolean;
    canGeneratePdf: boolean;
  };
}

export type FormFieldType =
  | 'text'
  | 'number'
  | 'email'
  | 'phone'
  | 'date'
  | 'time'
  | 'dropdown'
  | 'radio'
  | 'checkbox'
  | 'textarea'
  | 'image_upload'
  | 'file_upload'
  | 'signature'
  | 'address'
  | 'multi_select'
  | 'yes_no'
  | 'rating'
  | 'custom';

export interface FormCondition {
  dependsOnFieldId: string;
  operator: 'equals' | 'not_equals' | 'contains';
  value: string;
}

export interface FormField {
  id: string;
  type: FormFieldType;
  label: string;
  placeholder?: string;
  helpText?: string;
  required: boolean;
  options?: string[];
  defaultValue?: any;
  order: number;
  sectionId?: string;
  condition?: FormCondition;
  validationRegex?: string;
  errorMessage?: string;
}

export interface FormSection {
  id: string;
  title: string;
  description?: string;
  order: number;
}

export interface RollNumberConfig {
  prefix: string; // e.g. "AKM-2026-" or "XII-A-"
  startingNumber: number; // e.g. 1
  length: number; // e.g. 3 -> "001"
  resetScope: 'institute' | 'branch' | 'class' | 'batch' | 'form';
}

export interface FormPdfConfig {
  template: 'classic' | 'modern' | 'minimal' | 'professional';
  showWatermark: boolean;
  watermarkText?: string;
  accentColor?: string;
  showPhoto: boolean;
  showSignature: boolean;
  headerText?: string;
  footerText?: string;
  showInstituteLogo: boolean;
}

export interface FormSuccessConfig {
  title: string;
  message: string;
  showRollNo: boolean;
  showStudentId: boolean;
  showPdfDownload: boolean;
  showPrint: boolean;
  instructions: string;
}

export interface AdmissionForm {
  id: string;
  instituteId: string;
  branchId: string;
  classId: string;
  batchId?: string;
  title: string;
  slug: string;
  description?: string;
  status: 'draft' | 'published' | 'closed';
  startDate?: string;
  endDate?: string;
  maxSubmissions?: number;
  viewsCount: number;
  submissionsCount: number;
  rollNumberConfig: RollNumberConfig;
  sections: FormSection[];
  fields: FormField[];
  pdfConfig: FormPdfConfig;
  successConfig: FormSuccessConfig;
  allowSaveAndContinue?: boolean;
  duplicateCheckFields: ('phone' | 'email' | 'name_dob')[];
  createdAt: string;
  updatedAt: string;
}

export interface StudentDocument {
  id: string;
  name: string;
  type: string; // "Birth Certificate", "Marksheet", etc.
  url: string;
  uploadDate: string;
  fileSize?: string;
}

export interface StudentNote {
  id: string;
  author: string;
  text: string;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  timestamp: string;
  details?: string;
  user?: string;
}

export interface Student {
  id: string; // Permanent e.g. STU-2026-00001
  instituteId: string;
  branchId: string;
  sessionId: string;
  classId: string;
  batchId: string;
  rollNumber: string; // e.g. "001" or "AKM-2026-001"
  admissionFormId?: string;
  admissionDate: string;

  // Personal Info
  name: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  bloodGroup?: string;
  email?: string;
  phone: string;
  address: string;
  city?: string;
  pincode?: string;

  // Parents Info
  fatherName: string;
  motherName?: string;
  parentPhone: string;
  parentEmail?: string;
  parentOccupation?: string;

  // Academic Info
  previousSchool?: string;
  currentSchool?: string;
  stream?: string; // Science, Commerce, Arts
  subjects?: string[];

  // Media & Signature
  photoUrl?: string;
  signatureUrl?: string;

  // Status
  status: 'active' | 'archived' | 'graduated' | 'suspended';

  // Dynamic submitted custom fields
  customData: Record<string, any>;

  // Sub-records
  documents: StudentDocument[];
  notes: StudentNote[];
  activityLogs: ActivityLog[];

  createdAt: string;
  updatedAt: string;
}

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'leave';

export interface AttendanceRecord {
  id: string;
  instituteId: string;
  branchId: string;
  classId: string;
  batchId: string;
  date: string; // YYYY-MM-DD
  studentId: string;
  status: AttendanceStatus;
  remarks?: string;
  markedBy?: string;
}

export type FeeType = 'monthly' | 'admission' | 'exam' | 'material' | 'other';
export type PaymentStatus = 'paid' | 'partial' | 'due' | 'overdue';

export interface FeeRecord {
  id: string;
  instituteId: string;
  branchId: string;
  studentId: string;
  title: string;
  feeType: FeeType;
  month?: string; // e.g. "September 2026"
  totalAmount: number;
  paidAmount: number;
  dueAmount: number;
  dueDate: string;
  status: PaymentStatus;
  createdAt: string;
}

export interface FeePayment {
  id: string;
  feeRecordId: string;
  studentId: string;
  instituteId: string;
  amount: number;
  paymentDate: string;
  paymentMethod: 'cash' | 'upi' | 'bank_transfer' | 'cheque' | 'card';
  receiptNumber: string;
  transactionRef?: string;
  notes?: string;
  collectedBy: string;
}

export interface NoticeNotification {
  id: string;
  instituteId: string;
  branchId?: string;
  title: string;
  message: string;
  targetType: 'all' | 'class' | 'batch' | 'students' | 'teachers';
  targetId?: string;
  type: 'admission' | 'fee' | 'notice' | 'exam' | 'holiday';
  createdAt: string;
  date: string;
  author: string;
}

export interface SystemAuditLog {
  id: string;
  instituteId: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  timestamp: string;
  ipAddress?: string;
}

export interface DashboardStats {
  totalStudents: number;
  newAdmissionsThisMonth: number;
  activeStudents: number;
  totalClasses: number;
  totalBatches: number;
  totalTeachers: number;
  totalPendingFees: number;
  totalCollectedFees: number;
  todayAttendancePercentage: number;
  monthlyAdmissions: { month: string; count: number }[];
  classDistribution: { className: string; studentCount: number }[];
  branchDistribution: { branchName: string; studentCount: number }[];
  recentAdmissions: Student[];
  recentPayments: FeePayment[];
}
