import { Student, AdmissionForm, Institute, Branch, ClassItem, Batch, Teacher, FeeRecord, FeePayment, AttendanceRecord, NoticeNotification, SystemAuditLog, DashboardStats, AcademicSession, User } from '../types';

let activeInstituteId = 'inst-akashdeep-01';
let activeBranchId = 'all';

export const setApiTenant = (instituteId: string, branchId?: string) => {
  activeInstituteId = instituteId;
  if (branchId !== undefined) {
    activeBranchId = branchId;
  }
};

export const getApiTenant = () => ({
  instituteId: activeInstituteId,
  branchId: activeBranchId,
});

const fetchApi = async <T>(endpoint: string, options: RequestInit = {}): Promise<T> => {
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');
  headers.set('x-institute-id', activeInstituteId);
  if (activeBranchId && activeBranchId !== 'all') {
    headers.set('x-branch-id', activeBranchId);
  }

  const res = await fetch(endpoint, {
    ...options,
    headers,
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(errorData.error || `HTTP error ${res.status}`);
  }

  return res.json();
};

export const api = {
  // Auth
  getCurrentUser: () => fetchApi<{ user: User; institute: Institute; availableUsers: User[] }>('/api/auth/me'),
  switchUser: (userId: string) => fetchApi<{ success: boolean; user: User }>('/api/auth/switch-user', {
    method: 'POST',
    body: JSON.stringify({ userId }),
  }),

  // Institutes
  getInstitutes: () => fetchApi<Institute[]>('/api/institutes'),
  createInstitute: (data: Partial<Institute>) => fetchApi<Institute>('/api/institutes', { method: 'POST', body: JSON.stringify(data) }),
  updateInstitute: (id: string, data: Partial<Institute>) => fetchApi<Institute>(`/api/institutes/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

  // Branches
  getBranches: () => fetchApi<Branch[]>('/api/branches'),
  createBranch: (data: Partial<Branch>) => fetchApi<Branch>('/api/branches', { method: 'POST', body: JSON.stringify(data) }),

  // Academic Sessions
  getAcademicSessions: () => fetchApi<AcademicSession[]>('/api/academic-sessions'),
  createAcademicSession: (data: Partial<AcademicSession>) => fetchApi<AcademicSession>('/api/academic-sessions', { method: 'POST', body: JSON.stringify(data) }),

  // Classes & Batches
  getClasses: () => fetchApi<ClassItem[]>('/api/classes'),
  createClass: (data: Partial<ClassItem>) => fetchApi<ClassItem>('/api/classes', { method: 'POST', body: JSON.stringify(data) }),
  getBatches: () => fetchApi<Batch[]>('/api/batches'),
  createBatch: (data: Partial<Batch>) => fetchApi<Batch>('/api/batches', { method: 'POST', body: JSON.stringify(data) }),

  // Teachers
  getTeachers: () => fetchApi<Teacher[]>('/api/teachers'),
  createTeacher: (data: Partial<Teacher>) => fetchApi<Teacher>('/api/teachers', { method: 'POST', body: JSON.stringify(data) }),
  updateTeacher: (id: string, data: Partial<Teacher>) => fetchApi<Teacher>(`/api/teachers/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

  // Admission Forms
  getForms: () => fetchApi<AdmissionForm[]>('/api/forms'),
  createForm: (data: Partial<AdmissionForm>) => fetchApi<AdmissionForm>('/api/forms', { method: 'POST', body: JSON.stringify(data) }),
  updateForm: (id: string, data: Partial<AdmissionForm>) => fetchApi<AdmissionForm>(`/api/forms/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  duplicateForm: (id: string) => fetchApi<AdmissionForm>(`/api/forms/${id}/duplicate`, { method: 'POST' }),
  deleteForm: (id: string) => fetchApi<{ success: boolean }>(`/api/forms/${id}`, { method: 'DELETE' }),

  // Public Admission Form
  getPublicForm: (slug: string) => fetchApi<{
    form: AdmissionForm;
    institute: Institute;
    branch: Branch;
    classItem: ClassItem;
    batch: Batch;
    availableBatches: Batch[];
  }>(`/api/public/form/${slug}`),

  submitPublicForm: (slug: string, payload: any) => fetchApi<{
    success: boolean;
    student: Student;
    rollNumber: string;
    studentId: string;
    formSuccessConfig: any;
    pdfConfig: any;
    institute: Institute;
    branch: Branch;
    classItem: ClassItem;
    batch: Batch;
  }>(`/api/public/form/${slug}/submit`, {
    method: 'POST',
    body: JSON.stringify(payload),
  }),

  // Students
  getStudents: (params: { search?: string; classId?: string; batchId?: string; status?: string; page?: number; limit?: number } = {}) => {
    const query = new URLSearchParams();
    if (params.search) query.set('search', params.search);
    if (params.classId) query.set('classId', params.classId);
    if (params.batchId) query.set('batchId', params.batchId);
    if (params.status) query.set('status', params.status);
    if (params.page) query.set('page', String(params.page));
    if (params.limit) query.set('limit', String(params.limit));

    return fetchApi<{ students: Student[]; total: number; page: number; limit: number; totalPages: number }>(`/api/students?${query.toString()}`);
  },

  getStudentById: (id: string) => fetchApi<{
    student: Student;
    institute: Institute;
    branch: Branch;
    classItem: ClassItem;
    batch: Batch;
    attendance: AttendanceRecord[];
    fees: FeeRecord[];
    payments: FeePayment[];
  }>(`/api/students/${id}`),

  createStudent: (data: Partial<Student>) => fetchApi<Student>('/api/students', { method: 'POST', body: JSON.stringify(data) }),
  updateStudent: (id: string, data: Partial<Student>) => fetchApi<Student>(`/api/students/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  archiveStudent: (id: string) => fetchApi<{ success: boolean; status: string }>(`/api/students/${id}/archive`, { method: 'POST' }),
  deleteStudent: (id: string) => fetchApi<{ success: boolean }>(`/api/students/${id}`, { method: 'DELETE' }),
  addStudentNote: (id: string, note: { author: string; text: string }) => fetchApi<any>(`/api/students/${id}/notes`, { method: 'POST', body: JSON.stringify(note) }),
  addStudentDocument: (id: string, doc: { name: string; type: string; url: string; fileSize?: string }) => fetchApi<any>(`/api/students/${id}/documents`, { method: 'POST', body: JSON.stringify(doc) }),
  bulkStudentAction: (payload: { action: string; studentIds: string[]; batchId?: string; status?: string }) => fetchApi<{ success: boolean; count: number }>('/api/students/bulk', { method: 'POST', body: JSON.stringify(payload) }),

  // Attendance
  getAttendance: (params: { date?: string; classId?: string; batchId?: string }) => {
    const query = new URLSearchParams();
    if (params.date) query.set('date', params.date);
    if (params.classId) query.set('classId', params.classId);
    if (params.batchId) query.set('batchId', params.batchId);
    return fetchApi<AttendanceRecord[]>(`/api/attendance?${query.toString()}`);
  },
  saveAttendance: (data: { date: string; classId: string; batchId: string; records: { studentId: string; status: string; remarks?: string }[]; markedBy?: string }) =>
    fetchApi<{ success: boolean; count: number }>('/api/attendance', { method: 'POST', body: JSON.stringify(data) }),

  // Fees & Receipts
  getFees: () => fetchApi<{ feeRecords: FeeRecord[]; feePayments: FeePayment[] }>('/api/fees'),
  createFee: (data: Partial<FeeRecord>) => fetchApi<FeeRecord>('/api/fees', { method: 'POST', body: JSON.stringify(data) }),
  recordPayment: (data: { feeRecordId?: string; studentId: string; amount: number; paymentMethod: string; transactionRef?: string; notes?: string; collectedBy?: string }) =>
    fetchApi<{ payment: FeePayment; feeRecord?: FeeRecord }>('/api/fees/payments', { method: 'POST', body: JSON.stringify(data) }),
  createPayment: (data: { studentId: string; amount: number; paymentMethod: string; transactionRef?: string; month?: string; notes?: string; collectedBy?: string }) =>
    fetchApi<{ payment: FeePayment; feeRecord?: FeeRecord }>('/api/fees/payments', { method: 'POST', body: JSON.stringify(data) }),

  setInstituteId: (id: string, branchId?: string) => setApiTenant(id, branchId),

  // Notices
  getNotices: () => fetchApi<NoticeNotification[]>('/api/notices'),
  createNotice: (data: Partial<NoticeNotification>) => fetchApi<NoticeNotification>('/api/notices', { method: 'POST', body: JSON.stringify(data) }),

  // Audit Logs
  getAuditLogs: () => fetchApi<SystemAuditLog[]>('/api/audit-logs'),

  // Dashboard & Analytics
  getDashboardStats: () => fetchApi<DashboardStats>('/api/reports/dashboard'),
};
