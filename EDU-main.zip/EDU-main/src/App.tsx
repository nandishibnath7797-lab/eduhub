import React, { useState, useEffect } from 'react';
import {
  Users,
  CalendarCheck,
  CreditCard,
  Layers,
  FileSpreadsheet,
  BarChart2,
  Settings,
  Sparkles,
  ExternalLink,
  Plus,
} from 'lucide-react';
import {
  Institute,
  Branch,
  ClassItem,
  Batch,
  AdmissionForm,
  Student,
  DashboardStats,
  UserRole,
} from './types';
import { api } from './api/client';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { DashboardView } from './components/DashboardView';
import { StudentsDirectory } from './components/students/StudentsDirectory';
import { StudentProfileModal } from './components/students/StudentProfileModal';
import { AddStudentModal } from './components/students/AddStudentModal';
import { CsvImportModal } from './components/students/CsvImportModal';
import { FormsListView } from './components/forms/FormsListView';
import { FormBuilderModal } from './components/forms/FormBuilderModal';
import { QrShareModal } from './components/forms/QrShareModal';
import { AttendanceView } from './components/attendance/AttendanceView';
import { FeesView } from './components/fees/FeesView';
import { CollectFeeModal } from './components/fees/CollectFeeModal';
import { ClassesBatchesView } from './components/academic/ClassesBatchesView';
import { ReportsView } from './components/analytics/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { PublicAdmissionPortal } from './components/public/PublicAdmissionPortal';

export default function App() {
  // Check if current URL path is a public admission form URL
  const initialPath = window.location.pathname;
  const initialSlugMatch = initialPath.match(/\/admission\/([a-zA-Z0-9_-]+)/);
  const [publicSlug, setPublicSlug] = useState<string | null>(initialSlugMatch ? initialSlugMatch[1] : null);

  // App & Tenant State
  const [institutes, setInstitutes] = useState<Institute[]>([]);
  const [activeInstitute, setActiveInstitute] = useState<Institute | null>(null);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [selectedBranchId, setSelectedBranchId] = useState<string | undefined>();
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('super_admin');

  // Navigation Tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Domain Collections
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [forms, setForms] = useState<AdmissionForm[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [totalStudents, setTotalStudents] = useState(0);

  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [showCsvImportModal, setShowCsvImportModal] = useState(false);
  const [editingForm, setEditingForm] = useState<AdmissionForm | null>(null);
  const [showFormBuilder, setShowFormBuilder] = useState(false);
  const [qrShareForm, setQrShareForm] = useState<AdmissionForm | null>(null);
  const [feeCollectStudent, setFeeCollectStudent] = useState<Student | null>(null);
  const [showCollectFeeModal, setShowCollectFeeModal] = useState(false);

  // Loading indicator
  const [isLoading, setIsLoading] = useState(true);

  // Initial Data Fetching
  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const instRes = await api.getInstitutes();
      setInstitutes(instRes || []);
      const current = instRes?.[0] || null;
      setActiveInstitute(current);

      if (current) {
        api.setInstituteId(current.id);
        await refreshInstituteData(current.id);
      }
    } catch (err) {
      console.error('Failed to initialize app', err);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshInstituteData = async (instId: string) => {
    try {
      const [statsData, branchesData, classesData, batchesData, formsData, studentsData] = await Promise.all([
        api.getDashboardStats(),
        api.getBranches(),
        api.getClasses(),
        api.getBatches(),
        api.getForms(),
        api.getStudents({ limit: 100 }),
      ]);

      setDashboardStats(statsData);
      setBranches(branchesData || []);
      setClasses(classesData || []);
      setBatches(batchesData || []);
      setForms(formsData || []);
      setStudents(studentsData.students || []);
      setTotalStudents(studentsData.total || 0);

      if (branchesData?.length > 0 && !selectedBranchId) {
        setSelectedBranchId(branchesData[0].id);
      }
    } catch (err) {
      console.error('Error refreshing institute data', err);
    }
  };

  const handleSelectInstitute = async (institute: Institute) => {
    setActiveInstitute(institute);
    api.setInstituteId(institute.id);
    setSelectedBranchId(undefined);
    await refreshInstituteData(institute.id);
  };

  const handleCreateInstitute = async (name: string, code: string, teacherName: string) => {
    try {
      const res = await api.createInstitute({
        name,
        code,
        teacherName,
        tagline: 'Premier Coaching Institute',
        address: 'Main Campus',
      });
      setInstitutes([...institutes, res]);
      await handleSelectInstitute(res);
    } catch (err: any) {
      alert(`Failed creating institute: ${err.message}`);
    }
  };

  // Student Operations
  const handleAddStudent = async (studentData: Partial<Student>) => {
    const res = await api.createStudent(studentData);
    setStudents([res, ...students]);
    setTotalStudents(totalStudents + 1);
    if (activeInstitute) refreshInstituteData(activeInstitute.id);
  };

  const handleUpdateStudent = async (id: string, updates: Partial<Student>) => {
    const res = await api.updateStudent(id, updates);
    setStudents(students.map((s) => (s.id === id ? res : s)));
    if (selectedStudent?.id === id) {
      setSelectedStudent(res);
    }
  };

  const handleArchiveStudent = async (id: string) => {
    const target = students.find((s) => s.id === id);
    const newStatus = target?.status === 'archived' ? 'active' : 'archived';
    await handleUpdateStudent(id, { status: newStatus as any });
  };

  const handleDeleteStudent = async (id: string) => {
    if (!window.confirm('Are you sure you want to permanently delete this student record?')) return;
    await api.deleteStudent(id);
    setStudents(students.filter((s) => s.id !== id));
    setTotalStudents(Math.max(0, totalStudents - 1));
    if (selectedStudent?.id === id) setSelectedStudent(null);
  };

  const handleBulkAction = async (action: string, ids: string[]) => {
    if (action === 'delete') {
      if (!window.confirm(`Permanently delete ${ids.length} selected students?`)) return;
      for (const id of ids) {
        await api.deleteStudent(id);
      }
      setStudents(students.filter((s) => !ids.includes(s.id)));
      setTotalStudents(Math.max(0, totalStudents - ids.length));
    } else if (action === 'archive') {
      for (const id of ids) {
        await api.updateStudent(id, { status: 'archived' });
      }
      setStudents(
        students.map((s) => (ids.includes(s.id) ? { ...s, status: 'archived' } : s))
      );
    }
  };

  const handleCsvImport = async (studentsList: Partial<Student>[]) => {
    for (const s of studentsList) {
      await api.createStudent({
        ...s,
        branchId: selectedBranchId || branches[0]?.id,
        classId: classes[0]?.id,
        batchId: batches[0]?.id,
      });
    }
    if (activeInstitute) refreshInstituteData(activeInstitute.id);
  };

  // Form Operations
  const handleSaveForm = async (formData: Partial<AdmissionForm>) => {
    if (editingForm) {
      const res = await api.updateForm(editingForm.id, formData);
      setForms(forms.map((f) => (f.id === editingForm.id ? res : f)));
    } else {
      const res = await api.createForm(formData);
      setForms([res, ...forms]);
    }
    setShowFormBuilder(false);
    setEditingForm(null);
  };

  const handleDuplicateForm = async (formId: string) => {
    try {
      const res = await api.duplicateForm(formId);
      setForms([...forms, res]);
    } catch (err: any) {
      alert(`Duplicate failed: ${err.message}`);
    }
  };

  const handleDeleteForm = async (formId: string) => {
    if (!window.confirm('Are you sure you want to delete this admission form?')) return;
    try {
      await api.deleteForm(formId);
      setForms(forms.filter((f) => f.id !== formId));
    } catch (err: any) {
      alert(`Delete failed: ${err.message}`);
    }
  };

  const handleToggleFormStatus = async (form: AdmissionForm) => {
    const nextStatus = form.status === 'published' ? 'closed' : 'published';
    const res = await api.updateForm(form.id, { status: nextStatus });
    setForms(forms.map((f) => (f.id === form.id ? res : f)));
  };

  // Academic Operations
  const handleAddClass = async (name: string, description: string) => {
    const res = await api.createClass({ name, description });
    setClasses([...classes, res]);
  };

  const handleAddBatch = async (batchData: Partial<Batch>) => {
    const res = await api.createBatch(batchData);
    setBatches([...batches, res]);
  };

  // Settings Operations
  const handleUpdateInstitute = async (updates: Partial<Institute>) => {
    if (!activeInstitute) return;
    const res = await api.updateInstitute(activeInstitute.id, updates);
    setActiveInstitute(res);
    setInstitutes(institutes.map((i) => (i.id === activeInstitute.id ? res : i)));
  };

  // IF RENDERING PUBLIC ADMISSION FORM
  if (publicSlug) {
    return (
      <PublicAdmissionPortal
        slug={publicSlug}
        onClose={() => {
          setPublicSlug(null);
          window.history.pushState({}, '', '/');
        }}
      />
    );
  }

  const selectedBranch = branches.find((b) => b.id === selectedBranchId);

  return (
    <div className="flex h-screen bg-slate-100/60 font-sans text-slate-800 antialiased overflow-hidden">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        instituteName={activeInstitute?.name || 'EduRecord'}
        instituteCode={activeInstitute?.code || 'EDR'}
        userRole={currentUserRole}
        onOpenPublicPortal={() => {
          if (forms.length > 0) {
            setPublicSlug(forms[0].slug);
          } else {
            alert('No admission forms created yet.');
          }
        }}
      />

      {/* Main Content Pane */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top App Navbar */}
        <Navbar
          institutes={institutes}
          activeInstitute={activeInstitute}
          branches={branches}
          selectedBranchId={selectedBranchId}
          currentUserRole={currentUserRole}
          onSelectInstitute={handleSelectInstitute}
          onSelectBranch={setSelectedBranchId}
          onSelectRole={setCurrentUserRole}
          onOpenSearch={() => setIsSearchOpen(true)}
          onCreateInstitute={handleCreateInstitute}
        />

        {/* Scrollable View Container */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="mx-auto max-w-7xl">
            {activeTab === 'dashboard' && (
              <DashboardView
                stats={dashboardStats}
                institute={activeInstitute}
                selectedBranch={selectedBranch}
                onNavigateTab={setActiveTab}
                onSelectStudent={setSelectedStudent}
                onOpenPublicForm={() => {
                  if (forms.length > 0) {
                    setPublicSlug(forms[0].slug);
                  } else {
                    setActiveTab('forms');
                  }
                }}
              />
            )}

            {activeTab === 'students' && (
              <StudentsDirectory
                students={students}
                totalStudents={totalStudents}
                classes={classes}
                batches={batches}
                branches={branches}
                institute={activeInstitute}
                onSelectStudent={setSelectedStudent}
                onAddNewStudent={() => setShowAddStudentModal(true)}
                onArchiveStudent={handleArchiveStudent}
                onDeleteStudent={handleDeleteStudent}
                onBulkAction={handleBulkAction}
                onImportCsv={() => setShowCsvImportModal(true)}
              />
            )}

            {activeTab === 'forms' && (
              <FormsListView
                forms={forms}
                institute={activeInstitute}
                branches={branches}
                classes={classes}
                batches={batches}
                onCreateNewForm={() => {
                  setEditingForm(null);
                  setShowFormBuilder(true);
                }}
                onEditForm={(form) => {
                  setEditingForm(form);
                  setShowFormBuilder(true);
                }}
                onDuplicateForm={handleDuplicateForm}
                onDeleteForm={handleDeleteForm}
                onToggleStatus={handleToggleFormStatus}
                onOpenQrModal={setQrShareForm}
                onOpenPublicForm={(slug) => setPublicSlug(slug)}
              />
            )}

            {activeTab === 'attendance' && (
              <AttendanceView
                students={students}
                classes={classes}
                batches={batches}
              />
            )}

            {activeTab === 'fees' && (
              <FeesView
                students={students}
                institute={activeInstitute}
                branches={branches}
                onOpenCollectFee={(st) => {
                  setFeeCollectStudent(st || null);
                  setShowCollectFeeModal(true);
                }}
              />
            )}

            {activeTab === 'academic' && (
              <ClassesBatchesView
                classes={classes}
                batches={batches}
                branches={branches}
                institute={activeInstitute}
                onAddClass={handleAddClass}
                onAddBatch={handleAddBatch}
              />
            )}

            {activeTab === 'analytics' && (
              <ReportsView
                stats={dashboardStats}
                students={students}
                classes={classes}
                batches={batches}
                institute={activeInstitute}
              />
            )}

            {activeTab === 'settings' && (
              <SettingsView
                institute={activeInstitute}
                selectedBranch={selectedBranch}
                onUpdateInstitute={handleUpdateInstitute}
              />
            )}
          </div>
        </main>
      </div>

      {/* Global Modals */}
      {/* 1. Global Search Modal */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectStudent={setSelectedStudent}
        onNavigate={setActiveTab}
      />

      {/* 2. Student Full Profile Modal */}
      <StudentProfileModal
        isOpen={!!selectedStudent}
        onClose={() => setSelectedStudent(null)}
        student={selectedStudent}
        institute={activeInstitute}
        branches={branches}
        classes={classes}
        batches={batches}
        onUpdateStudent={handleUpdateStudent}
        onCollectFee={(st) => {
          setFeeCollectStudent(st);
          setShowCollectFeeModal(true);
        }}
      />

      {/* 3. Direct Add Student Modal */}
      <AddStudentModal
        isOpen={showAddStudentModal}
        onClose={() => setShowAddStudentModal(false)}
        classes={classes}
        batches={batches}
        branches={branches}
        onAddStudent={handleAddStudent}
      />

      {/* 4. CSV Bulk Student Import Modal */}
      <CsvImportModal
        isOpen={showCsvImportModal}
        onClose={() => setShowCsvImportModal(false)}
        onImport={handleCsvImport}
      />

      {/* 5. Admission Form Builder Modal */}
      <FormBuilderModal
        isOpen={showFormBuilder}
        onClose={() => {
          setShowFormBuilder(false);
          setEditingForm(null);
        }}
        form={editingForm}
        onSave={handleSaveForm}
        branches={branches}
        classes={classes}
        batches={batches}
        instituteCode={activeInstitute?.code || 'EDR'}
      />

      {/* 6. Form QR Code & Social Sharing Modal */}
      <QrShareModal
        isOpen={!!qrShareForm}
        onClose={() => setQrShareForm(null)}
        form={qrShareForm}
        institute={activeInstitute}
        onOpenPublicForm={(slug) => setPublicSlug(slug)}
      />

      {/* 7. Tuition Fee Collection Modal */}
      <CollectFeeModal
        isOpen={showCollectFeeModal}
        onClose={() => setShowCollectFeeModal(false)}
        student={feeCollectStudent}
        institute={activeInstitute}
        branches={branches}
        students={students}
        onPaymentSuccess={() => {
          if (activeInstitute) refreshInstituteData(activeInstitute.id);
        }}
      />
    </div>
  );
}
